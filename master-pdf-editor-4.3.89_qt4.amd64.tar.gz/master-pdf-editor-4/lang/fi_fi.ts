<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fi_FI" sourcelanguage="en">
<context>
    <name>MainOptionsDialog</name>
    <message>
        <source>%</source>
        <translation></translation>
    </message>
    <message>
        <source>pt</source>
        <translation> pistettä</translation>
    </message>
    <message>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <source> ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>Avain</translation>
    </message>
    <message>
        <source>OCR</source>
        <translation>Optinen tekstin lukija (OCR)</translation>
    </message>
    <message>
        <source>SSL</source>
        <translation>SSL</translation>
    </message>
    <message>
        <source>Tag</source>
        <translation>Tagi</translation>
    </message>
    <message>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Automaattinen</translation>
    </message>
    <message>
        <source>Dark</source>
        <translation>Tumma</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Fontti</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Ruudukko</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ohje</translation>
    </message>
    <message>
        <source>Host</source>
        <translation>Isäntä</translation>
    </message>
    <message>
        <source>Link</source>
        <translation>Linkki</translation>
    </message>
    <message>
        <source>NONE</source>
        <translation>EI MITÄÄN</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ei mitään</translation>
    </message>
    <message>
        <source>Port</source>
        <translation>Portti</translation>
    </message>
    <message>
        <source>SMTP</source>
        <translation>SMTP</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Koko</translation>
    </message>
    <message>
        <source>Star</source>
        <translation>Tähti</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Teksti</translation>
    </message>
    <message>
        <source>Thai</source>
        <translation>Thai</translation>
    </message>
    <message>
        <source>Thin</source>
        <translation>Ohut</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tyyppi</translation>
    </message>
    <message>
        <source>User</source>
        <translation>Käyttäjä</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Zoomaus (oletus)</translation>
    </message>
    <message>
        <source>Check</source>
        <translation>Valitse</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Väri</translation>
    </message>
    <message>
        <source>Cross</source>
        <translation>Ruksi</translation>
    </message>
    <message>
        <source>Czech</source>
        <translation>Tsekki</translation>
    </message>
    <message>
        <source>Dutch</source>
        <translation>Hollanti</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Sähköposti</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation>Lomakkeet</translation>
    </message>
    <message>
        <source>Graph</source>
        <translation>Kaavio</translation>
    </message>
    <message>
        <source>Greek</source>
        <translation>Kreikka</translation>
    </message>
    <message>
        <source>Inset</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>Irish</source>
        <translation>Iiri (Irlanti)</translation>
    </message>
    <message>
        <source>Light</source>
        <translation>Vaalea</translation>
    </message>
    <message>
        <source>Pop-up Opacity</source>
        <translation>Pop-up -peittävyys</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Ei koskaan</translation>
    </message>
    <message>
        <source>Solid</source>
        <translation>Jatkuva viiva</translation>
    </message>
    <message>
        <source>Style</source>
        <translation>Tyyli</translation>
    </message>
    <message>
        <source>Theme</source>
        <translation>Teema</translation>
    </message>
    <message>
        <source>Thick</source>
        <translation>Paksu</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>Yksikkö</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation>Sovita sivulle</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>Millimetrit</translation>
    </message>
    <message>
        <source>kmail</source>
        <translation>kmail</translation>
    </message>
    <message>
        <source>Default Layout and Zoom</source>
        <translation>Oletusasettelu ja -zoomaus</translation>
    </message>
    <message>
        <source>Automatically change font when editing text</source>
        <translation>Muuta fontti automaattisesti, kun tekstiä muokataan</translation>
    </message>
    <message>
        <source>Open documents as new tabs in the same window (requires restart)</source>
        <translation>Avaa asiakirjat uusiin välilehtiin samassa ikkunassa (vaatii uudelleen käynnistyksen)</translation>
    </message>
    <message>
        <source>Enable safe reading mode</source>
        <translation>Käytä turvallista lukutilaa</translation>
    </message>
    <message>
        <source>List box</source>
        <translation>Lista</translation>
    </message>
    <message>
        <source>Italian</source>
        <translation>Italia</translation>
    </message>
    <message>
        <source>Subdivision</source>
        <translation>Ruutua osastossa</translation>
    </message>
    <message>
        <source>Highlight Text</source>
        <translation>Korostettu teksti</translation>
    </message>
    <message>
        <source>Last used folder</source>
        <translation>Viimeksi käytetty kansio</translation>
    </message>
    <message>
        <source>Underline Text</source>
        <translation>Alleviivattu teksti</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation>Reunuksen väri</translation>
    </message>
    <message>
        <source>Enable scroll wheel zooming</source>
        <translation>Käytä hiiren rullausta zoomaamiseen</translation>
    </message>
    <message>
        <source>Restore last session when application start</source>
        <translation>Palauta viimeisin istunto käynnistettäessä</translation>
    </message>
    <message>
        <source>Load all objects separately</source>
        <translation>Lataa kaikki objektit erikseen</translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation>Yksi sivu</translation>
    </message>
    <message>
        <source>Up Arrow</source>
        <translation>Nuoli ylös</translation>
    </message>
    <message>
        <source>HTTP Proxy</source>
        <translation>HTTP-Proxy</translation>
    </message>
    <message>
        <source>Latvian</source>
        <translation>Latvia</translation>
    </message>
    <message>
        <source>Valencian</source>
        <translation>Valensia</translation>
    </message>
    <message>
        <source>Bulgarian</source>
        <translation>Bulgaria</translation>
    </message>
    <message>
        <source> Always hide document message bar </source>
        <translation>Piilota asiakirjan viestipalkki aina</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation>Muistilappu</translation>
    </message>
    <message>
        <source>Portuguese-Brazilian</source>
        <translation>Poertugali-Brasilia</translation>
    </message>
    <message>
        <source>Select directory</source>
        <translation>Valitse hakemisto</translation>
    </message>
    <message>
        <source>Radio button</source>
        <translation>Valintanappi</translation>
    </message>
    <message>
        <source>Restore last view settings when reopening</source>
        <translation>Palauta viimeisimmät näkymäasetukset uudelleen avattaessa</translation>
    </message>
    <message>
        <source>Authentication</source>
        <translation>Todennus</translation>
    </message>
    <message>
        <source>Height between lines</source>
        <translation>Viivojen välin korkeus</translation>
    </message>
    <message>
        <source>Combo box</source>
        <translation>Valikko</translation>
    </message>
    <message>
        <source>Exact match only</source>
        <translation>Tarkka hakutulos</translation>
    </message>
    <message>
        <source>Monthly</source>
        <translation>Kuukausittain</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation>Arabia</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Tekijä</translation>
    </message>
    <message>
        <source>Button</source>
        <translation>Painike</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>Ympyrä</translation>
    </message>
    <message>
        <source>Enable JavaScript</source>
        <translation>Ota JavaScriptit käyttöön</translation>
    </message>
    <message>
        <source>Danish</source>
        <translation>Tanska</translation>
    </message>
    <message>
        <source>Dashed</source>
        <translation>Katkoviiva</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Mukauta</translation>
    </message>
    <message>
        <source>Network</source>
        <translation>Verkko</translation>
    </message>
    <message>
        <source>Selected text color</source>
        <translation>Valitse tekstin väri</translation>
    </message>
    <message>
        <source>Hungarian</source>
        <translation>Unkari</translation>
    </message>
    <message>
        <source>French</source>
        <translation>Ranska</translation>
    </message>
    <message>
        <source>German</source>
        <translation>Saksa</translation>
    </message>
    <message>
        <source>Hebrew</source>
        <translation>Hebrea</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>Tuumat</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>Invert</source>
        <translation>Käänteinen</translation>
    </message>
    <message>
        <source>Korean</source>
        <translation>Korea</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Keski</translation>
    </message>
    <message>
        <source>Width between lines</source>
        <translation>Viivojen välin leveys</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>Pisteet</translation>
    </message>
    <message>
        <source>Polish</source>
        <translation>Puola</translation>
    </message>
    <message>
        <source>Slovak</source>
        <translation>Slovakia</translation>
    </message>
    <message>
        <source>Square</source>
        <translation>Neliö</translation>
    </message>
    <message>
        <source>System</source>
        <translation>Järjestelmä</translation>
    </message>
    <message>
        <source>Update</source>
        <translation>Päivitys</translation>
    </message>
    <message>
        <source>Weekly</source>
        <translation>Viikottain</translation>
    </message>
    <message>
        <source>Select item by hovering the mouse</source>
        <translation>Valitse kohde liikuttamalla hiirtä</translation>
    </message>
    <message>
        <source>Right Arrow</source>
        <translation>Nuoli oikealle</translation>
    </message>
    <message>
        <source>Romanian</source>
        <translation>Romania</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Resoluutio</translation>
    </message>
    <message>
        <source>evolution</source>
        <translation>Muutos</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Kommentit</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation>Sovita leveyteen</translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation>Läpinäkyvyys</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>Default path to tesseract ocr data files</source>
        <translation>Oletuspolku tekstintunnistus OCR-tiedostoille</translation>
    </message>
    <message>
        <source>JavaScript</source>
        <translation>JavaScripti</translation>
    </message>
    <message>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>Käynnistä ohjelma uudelleen, että muutokset tulevat voimaan.</translation>
    </message>
    <message>
        <source>OutLine</source>
        <translation>Ääriviiva</translation>
    </message>
    <message>
        <source>Slovenian</source>
        <translation>Slovenia</translation>
    </message>
    <message>
        <source>Left offset</source>
        <translation>Vasen asettelu</translation>
    </message>
    <message>
        <source>Line Width</source>
        <translation>Viivan leveys</translation>
    </message>
    <message>
        <source>Top offset</source>
        <translation>Yläasettelu</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation>Viivatyyppi</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>Liite</translation>
    </message>
    <message>
        <source>Please choose the interface language</source>
        <translation>Valitse käyttöliittymän kieli</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation>Todellinen koko</translation>
    </message>
    <message>
        <source>Use default program</source>
        <translation>Käytä oletusohjelmaa</translation>
    </message>
    <message>
        <source>SMTP server</source>
        <translation>SMTP-palvelin</translation>
    </message>
    <message>
        <source>Default font</source>
        <translation>Oletusfontti</translation>
    </message>
    <message>
        <source>Strikeout Text</source>
        <translation>Yliviivattu teksti</translation>
    </message>
    <message>
        <source>Direct internet connection</source>
        <translation>Suora internetyhteys</translation>
    </message>
    <message>
        <source>Galician</source>
        <translation>Galicia</translation>
    </message>
    <message>
        <source>Language</source>
        <translation>Kieli</translation>
    </message>
    <message>
        <source>Vector Images</source>
        <translation>Vektorikuvat</translation>
    </message>
    <message>
        <source>STARTTLS</source>
        <translation>STARTTLS</translation>
    </message>
    <message>
        <source>Japanese</source>
        <translation>Japani</translation>
    </message>
    <message>
        <source>Paragraph</source>
        <translation>Kappale</translation>
    </message>
    <message>
        <source>Ukrainian</source>
        <translation>Ukraina</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Salasana</translation>
    </message>
    <message>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation>Valitse kansio asiakirjojen &quot;Tallenna nimellä&quot; -toiminnolle</translation>
    </message>
    <message>
        <source>Beveled</source>
        <translation>Viistettyreunus</translation>
    </message>
    <message>
        <source>SMTP port</source>
        <translation>SMTP-portti</translation>
    </message>
    <message>
        <source>Replace Document Colors</source>
        <translation>Korvaa asiakirjan värit</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation>Lisää teksti</translation>
    </message>
    <message>
        <source>Armenian</source>
        <translation>Armenia</translation>
    </message>
    <message>
        <source>Secure connections</source>
        <translation>Lähdeyhteys</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation>Reunukset ja värit</translation>
    </message>
    <message>
        <source>Use SMTP</source>
        <translation>Käytä SMTP:tä</translation>
    </message>
    <message>
        <source>Catalan</source>
        <translation>Katalonia</translation>
    </message>
    <message>
        <source>Serbian</source>
        <translation>Serbia</translation>
    </message>
    <message>
        <source>Russian</source>
        <translation>Venäjä</translation>
    </message>
    <message>
        <source>Check Mark</source>
        <translation>Valintamerkki</translation>
    </message>
    <message>
        <source>Norwegian</source>
        <translation>Norja</translation>
    </message>
    <message>
        <source>Icons in menus</source>
        <translation>Kuvakkeet valikossa</translation>
    </message>
    <message>
        <source>Show errors and  messages in console</source>
        <translation>Näytä virheet ja viestit konsolissa</translation>
    </message>
    <message>
        <source>Icon set</source>
        <translation>Ikonit</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentti</translation>
    </message>
    <message>
        <source>Spanish</source>
        <translation>Espanja</translation>
    </message>
    <message>
        <source>Up Left Arrow</source>
        <translation>Nuoli ylös vasemmalle</translation>
    </message>
    <message>
        <source>Additional tesseract ocr config file</source>
        <translation>Lisä-Tesseract OCR-määritystiedosto</translation>
    </message>
    <message>
        <source>thunderbird</source>
        <translation>Thunderbird</translation>
    </message>
    <message>
        <source>Estonian</source>
        <translation>Viro</translation>
    </message>
    <message>
        <source>System PPI</source>
        <translation>Järjestelmän PPI</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Oletus</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation>Alleviivaus</translation>
    </message>
    <message>
        <source>Swedish</source>
        <translation>Ruotsi</translation>
    </message>
    <message>
        <source>Diamond</source>
        <translation>Timantti</translation>
    </message>
    <message>
        <source>Edit Box</source>
        <translation>Muokkausruutu</translation>
    </message>
    <message>
        <source>Display</source>
        <translation>Näyttö</translation>
    </message>
    <message>
        <source>Saving Documents</source>
        <translation>Asiakirjojen tallennus</translation>
    </message>
    <message>
        <source>Manual proxy configuration</source>
        <translation>Manuaalinen proxy-asetus</translation>
    </message>
    <message>
        <source>Vietnamese</source>
        <translation>Vietnami</translation>
    </message>
    <message>
        <source>Automatic</source>
        <translation>Automaattinen</translation>
    </message>
    <message>
        <source>Drawing</source>
        <translation>Piirros</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Ulkomuoto</translation>
    </message>
    <message>
        <source>Email address</source>
        <translation>Sähköpostiosoite</translation>
    </message>
    <message>
        <source>Highlight color</source>
        <translation>Korostusväri</translation>
    </message>
    <message>
        <source>Check box</source>
        <translation>Valintaruutu</translation>
    </message>
    <message>
        <source>Time before a move or resize starts:</source>
        <translation>Aika ennen kuin siirtyminen tai koon muutos alkaa:</translation>
    </message>
    <message>
        <source>Editing</source>
        <translation>Muokkaus</translation>
    </message>
    <message>
        <source>Portuguese</source>
        <translation>Portugali</translation>
    </message>
    <message>
        <source>Turkish</source>
        <translation>Turkki</translation>
    </message>
    <message>
        <source>Default page layout</source>
        <translation>Sivun asettelu (oletus)</translation>
    </message>
    <message>
        <source>Built-in</source>
        <translation>Tehdasasetus</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Avaa tiedosto</translation>
    </message>
    <message>
        <source>Paper Clip</source>
        <translation>Paperiliitin</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Käyttäjänimi</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Englanti</translation>
    </message>
    <message>
        <source>Install languages</source>
        <translation>Asenna kielet</translation>
    </message>
    <message>
        <source>Page Background</source>
        <translation>Sivun tausta</translation>
    </message>
    <message>
        <source>New Paragraph</source>
        <translation>Uusi kappale</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>Chinese-Simplified</source>
        <translation>Kiina-Simplifield</translation>
    </message>
    <message>
        <source>Typewriter</source>
        <translation>Kirjoituskone-työkalu</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation>Avainsanat</translation>
    </message>
    <message>
        <source>Finnish</source>
        <translation>Suomi</translation>
    </message>
    <message>
        <source>Required field highlight color</source>
        <translation>Pakollisen kentän korostusväri</translation>
    </message>
    <message>
        <source>Facing Pages</source>
        <translation>Sivut vierekkäin</translation>
    </message>
    <message>
        <source>Measurements</source>
        <translation>Mitat</translation>
    </message>
    <message>
        <source>Original documents folder</source>
        <translation>Alkuperäiset asiakirjat kansio</translation>
    </message>
    <message>
        <source>Highlight</source>
        <translation>Korostus</translation>
    </message>
    <message>
        <source>Bitmap Images</source>
        <translation>Bittikarttakuvat</translation>
    </message>
    <message>
        <source>Check for Updates Automatically</source>
        <translation>Tarkista päivitykset automaattisesti</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Allekirjoitus</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation>Täyttöväri</translation>
    </message>
    <message>
        <source>Always show Object Inspector</source>
        <translation>Näytä objektin ominaisuudet-ikkuna aina (Odject Inspector)</translation>
    </message>
    <message>
        <source>Norwegian-Nynorsk</source>
        <translation>Norja-Nynorsk</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Historia</translation>
    </message>
    <message>
        <source>Smooth text and images</source>
        <translation>Pehmennä teksti ja kuvat</translation>
    </message>
    <message>
        <source>Text Note</source>
        <translation>Tekstiviesti</translation>
    </message>
    <message>
        <source>SOCKS 5 Proxy</source>
        <translation>SOCKS 5-Proxy</translation>
    </message>
    <message>
        <source>Chinese-Traditional</source>
        <translation>Kiina-Tradiitional</translation>
    </message>
    <message>
        <source>Application Style</source>
        <translation>Sovelluksen tyyli</translation>
    </message>
    <message>
        <source>Right Pointer</source>
        <translation>Oikea osoitin</translation>
    </message>
    <message>
        <source>Lithuanian</source>
        <translation>Liettua</translation>
    </message>
    <message>
        <source>Forbid files to enable Full Screen mode on opening</source>
        <translation>Estä tiedostoja avaamasta kokonäyttötilaa</translation>
    </message>
    <message>
        <source>Create backup file</source>
        <translation>Luo varmuuskopio</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation>Viivan paksuus</translation>
    </message>
    <message>
        <source>Show Start page</source>
        <translation>Näytä aloitusivu</translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <source>+</source>
        <translation>+</translation>
    </message>
    <message>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>Up</source>
        <translation>Ylöspäin</translation>
    </message>
    <message>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>Key</source>
        <translation>Avain</translation>
    </message>
    <message>
        <source>Tag</source>
        <translation>Tagi</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Ylhäältä</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Automaattinen</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Päiväys</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Alaspäin</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muokkaa</translation>
    </message>
    <message>
        <source>Fill</source>
        <translation>Täyttö</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Fontti</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ohje</translation>
    </message>
    <message>
        <source>Item</source>
        <translation>Nimike</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Vasemmalta</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ei mitään</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Avaa</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Polku</translation>
    </message>
    <message>
        <source>Push</source>
        <translation>Työnnä</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Koko</translation>
    </message>
    <message>
        <source>Star</source>
        <translation>Tähti</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Teksti</translation>
    </message>
    <message>
        <source>Thin</source>
        <translation>Ohut</translation>
    </message>
    <message>
        <source>Time</source>
        <translation>Aika</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Tyyppi</translation>
    </message>
    <message>
        <source>Zip Code</source>
        <translation>Postinumero</translation>
    </message>
    <message>
        <source>Limit to</source>
        <translation>Rajoitettu</translation>
    </message>
    <message>
        <source>Allow Rich Text formatting</source>
        <translation>Salli Rich Text -muotoilu</translation>
    </message>
    <message>
        <source>Check</source>
        <translation>Tarkista</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Tyhjennä</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Väri</translation>
    </message>
    <message>
        <source>Cross</source>
        <translation>Ruksi</translation>
    </message>
    <message>
        <source>Graph</source>
        <translation>Kaavio</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Kuva</translation>
    </message>
    <message>
        <source>Inset</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Nimiö</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Oikea</translation>
    </message>
    <message>
        <source>Solid</source>
        <translation>Kiinteäviiva</translation>
    </message>
    <message>
        <source>State</source>
        <translation>Osavaltio</translation>
    </message>
    <message>
        <source>Style</source>
        <translation>Tyyli</translation>
    </message>
    <message>
        <source>Thick</source>
        <translation>Paksu</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>Yksikkö</translation>
    </message>
    <message>
        <source>Value</source>
        <translation>Arvo</translation>
    </message>
    <message>
        <source>Icon left, label right</source>
        <translation>Kuvake vasemmalla, nimiö oikealla</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Leveys</translation>
    </message>
    <message>
        <source>Split into</source>
        <translation>Jaetaan</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>Millimetriä</translation>
    </message>
    <message>
        <source>cells</source>
        <translation>solua</translation>
    </message>
    <message>
        <source>chars</source>
        <translation>merkkiä</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>Aja JavaScripti</translation>
    </message>
    <message>
        <source>Maintain aspect ratio</source>
        <translation>Pidä kuvasuhde</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation>Reunusväri</translation>
    </message>
    <message>
        <source>Choose Icon...</source>
        <translation>valitse kuvake...</translation>
    </message>
    <message>
        <source>Stroke Text</source>
        <translation>Stroke-teksti</translation>
    </message>
    <message>
        <source>Euro (€)</source>
        <translation>Euro (€)</translation>
    </message>
    <message>
        <source>On Lose Focus</source>
        <translation>Vähennä tarkennusta</translation>
    </message>
    <message>
        <source>Ruble (Руб)</source>
        <translation>Rupla (Руб)</translation>
    </message>
    <message>
        <source>1.234,56</source>
        <translation>1.234,56</translation>
    </message>
    <message>
        <source>Format category</source>
        <translation>Muotoluokka</translation>
    </message>
    <message>
        <source>Background</source>
        <translation>Tausta</translation>
    </message>
    <message>
        <source>Icon top, label bottom</source>
        <translation>Kuvake päällä, nimiö alla</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Allekirjoitus.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Ei käytettävissä olevia vaihtoehtoja&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Phone Number</source>
        <translation>Puhelinnumero</translation>
    </message>
    <message>
        <source>Up Arrow</source>
        <translation>Nuoli ylös</translation>
    </message>
    <message>
        <source>Dollar ($)</source>
        <translation>Dollari ($)</translation>
    </message>
    <message>
        <source>Export Value</source>
        <translation>Vientiarvo</translation>
    </message>
    <message>
        <source>Calculate</source>
        <translation>Laske</translation>
    </message>
    <message>
        <source>Date Options</source>
        <translation>Päiväysasetukset</translation>
    </message>
    <message>
        <source>Stroke Color</source>
        <translation>Stroke-väri</translation>
    </message>
    <message>
        <source>Fill text</source>
        <translation>Täytä teksti</translation>
    </message>
    <message>
        <source>Social Security Number</source>
        <translation>Sosiaaliturvatunnus</translation>
    </message>
    <message>
        <source>Label top, icon bottom</source>
        <translation>Nimiö päällä, kuvake alla</translation>
    </message>
    <message>
        <source>Calculation Script</source>
        <translation>Laskenta-skripti</translation>
    </message>
    <message>
        <source>Time Options</source>
        <translation>Päiväysasetukset</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation>Lisää tapahtuma</translation>
    </message>
    <message>
        <source>1234,56</source>
        <translation>1234,56</translation>
    </message>
    <message>
        <source>1234.56</source>
        <translation>1234.56</translation>
    </message>
    <message>
        <source>Allow user to enter custom text</source>
        <translation>Salli käyttäjän lisätä mukautettua tekstiä</translation>
    </message>
    <message>
        <source>Pound (£)</source>
        <translation>Punta (£)</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Tapahtuma</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation>Fonttityyppi</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Tekijä</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Keski</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>Ympyrä</translation>
    </message>
    <message>
        <source>Zip Code+4</source>
        <translation>Postinumero+4</translation>
    </message>
    <message>
        <source>Dashed</source>
        <translation>Katkoviiva</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Mukauta</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Muoto</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Korkeus</translation>
    </message>
    <message>
        <source>Hidden</source>
        <translation>Piilotettu</translation>
    </message>
    <message>
        <source>Label over icon</source>
        <translation>Nimiö kuvakkeesa</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>Tuumaa</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>Invert</source>
        <translation>Käänteinen</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Asettelu</translation>
    </message>
    <message>
        <source>Locked</source>
        <translation>Lukittu</translation>
    </message>
    <message>
        <source>Matrix</source>
        <translation>Matriisi</translation>
    </message>
    <message>
        <source>Medium</source>
        <translation>Keskivahva</translation>
    </message>
    <message>
        <source>Checked by Default</source>
        <translation>Oletusasetus</translation>
    </message>
    <message>
        <source>Number</source>
        <translation>Numero</translation>
    </message>
    <message>
        <source>Do nothing</source>
        <translation>Älä tee mitään</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>Pistettä</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation>Käännä</translation>
    </message>
    <message>
        <source>Square</source>
        <translation>Neliö</translation>
    </message>
    <message>
        <source>Stroke</source>
        <translation>Stroke (objektin reunus)</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation>Suunta</translation>
    </message>
    <message>
        <source>Icon only</source>
        <translation>Vain kuvake</translation>
    </message>
    <message>
        <source>Right Arrow</source>
        <translation>Oikea nuoli</translation>
    </message>
    <message>
        <source>Rollover</source>
        <translation>Vieritys</translation>
    </message>
    <message>
        <source>Scrollable</source>
        <translation>Vieritettävä</translation>
    </message>
    <message>
        <source>Sort Items</source>
        <translation>Järjetä nimikkeet</translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation>Peittävyys</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Fonttityyppi&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Muuta fonttityyppiä&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Line height</source>
        <translation>Viivankorkeus</translation>
    </message>
    <message>
        <source>OutLine</source>
        <translation>Ääriviiva</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation>Hiiren painike ylös</translation>
    </message>
    <message>
        <source>Outline</source>
        <translation>Ääriviivä</translation>
    </message>
    <message>
        <source>Multiple selection</source>
        <translation>Monivalinta</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Fontin väri&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Muuta täyttöväriä&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Kaikki tiedostot (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>Mouse Enter</source>
        <translation>Hiiri päälle</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>Avaa web-linkki</translation>
    </message>
    <message>
        <source>Visible but doesn&apos;t print</source>
        <translation>Näkyvä, mutta ei tulosteta</translation>
    </message>
    <message>
        <source>Fill and Stroke</source>
        <translation>Täyttö ja stroke</translation>
    </message>
    <message>
        <source>Line Width</source>
        <translation>Viivan leveys</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation>Viivan tyyli</translation>
    </message>
    <message>
        <source>Read Only</source>
        <translation>Vain luku</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>Liite</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation>Tapahtumat</translation>
    </message>
    <message>
        <source>Check spelling</source>
        <translation>Tarkista oikeinkirjoitus</translation>
    </message>
    <message>
        <source>Validate</source>
        <translation>Vahvista</translation>
    </message>
    <message>
        <source>Paragraph</source>
        <translation>Kappale</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Salasana</translation>
    </message>
    <message>
        <source>Beveled</source>
        <translation>Viistetty</translation>
    </message>
    <message>
        <source>Separation Style</source>
        <translation>Erotustyyli</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation>Ylä- ja alatunniste</translation>
    </message>
    <message>
        <source>No Properties
There is no object selections.</source>
        <translation>Ei ominaisuuksia. Yhtäkään objektia ei ole valittuna.</translation>
    </message>
    <message>
        <source>Format Script</source>
        <translation>Muotoilu-skripti</translation>
    </message>
    <message>
        <source>Insert Text</source>
        <translation>Lisää teksti</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation>Reunukset ja värit</translation>
    </message>
    <message>
        <source>Property</source>
        <translation>Omistaa</translation>
    </message>
    <message>
        <source>Mouse Exit</source>
        <translation>Hiiri pois päältä</translation>
    </message>
    <message>
        <source>Mouse Down</source>
        <translation>Hiiren painike alas</translation>
    </message>
    <message>
        <source>Absolute</source>
        <translation>Absoluuttinen</translation>
    </message>
    <message>
        <source>Percentage</source>
        <translation>Prosenttimäärä</translation>
    </message>
    <message>
        <source>Check Mark</source>
        <translation>Valintamerkki</translation>
    </message>
    <message>
        <source>Shading</source>
        <translation>Varjostus</translation>
    </message>
    <message>
        <source>Hidden but printable</source>
        <translation>Piilotettu, mutta tulostetaan</translation>
    </message>
    <message>
        <source>Comment</source>
        <translation>Kommentti</translation>
    </message>
    <message>
        <source>Special</source>
        <translation>Erikois-</translation>
    </message>
    <message>
        <source>Up Left Arrow</source>
        <translation>Nuoli vasemmalle yllös</translation>
    </message>
    <message>
        <source>180 Degrees</source>
        <translation>180 astetta</translation>
    </message>
    <message>
        <source>270 Degrees</source>
        <translation>270 astetta</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Aihe</translation>
    </message>
    <message>
        <source>90 Degrees</source>
        <translation>90 astetta</translation>
    </message>
    <message>
        <source>0 Degrees</source>
        <translation>0 astetta</translation>
    </message>
    <message>
        <source>Multi-line</source>
        <translation>Moni-viiva</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation>Vesileima</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation>Alleviivaus</translation>
    </message>
    <message>
        <source>Coordinates</source>
        <translation>Koordinaatit</translation>
    </message>
    <message>
        <source>Diamond</source>
        <translation>Timantti</translation>
    </message>
    <message>
        <source>Buttons with the same name and value are selected in unison</source>
        <translation>Samannimiset ja -arvoset painikkeet valitaan samanaikaisesti</translation>
    </message>
    <message>
        <source>ToolTip</source>
        <translation>Työkaluvihje</translation>
    </message>
    <message>
        <source>Commit selected value immediately</source>
        <translation>Suorita valittu arvo heti</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Ulkomuoto</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation>Toiminto</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Kehittyneet</translation>
    </message>
    <message>
        <source>Label only</source>
        <translation>Vain nimiö</translation>
    </message>
    <message>
        <source>Behavior</source>
        <translation></translation>
    </message>
    <message>
        <source>Yen (¥)</source>
        <translation>Jeni (¥)</translation>
    </message>
    <message>
        <source>Execute this script</source>
        <translation>Suorita tämä skripti</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>Siirry sivulle</translation>
    </message>
    <message>
        <source>Currency Symbol</source>
        <translation>Valuutan symboli</translation>
    </message>
    <message>
        <source>Relative</source>
        <translation>Suhteellinen</translation>
    </message>
    <message>
        <source>Icon and Label</source>
        <translation>Kuvake ja nimiö</translation>
    </message>
    <message>
        <source>Paper Clip</source>
        <translation>Paperiliitin</translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation>Nollaa lomake</translation>
    </message>
    <message>
        <source>Geometry</source>
        <translation>Geometria</translation>
    </message>
    <message>
        <source>Required</source>
        <translation>Vaadittava</translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation>Lähetä lomake</translation>
    </message>
    <message>
        <source>New Paragraph</source>
        <translation>Uusi kappale</translation>
    </message>
    <message>
        <source>Show parentheses</source>
        <translation>Näytä sulkeet</translation>
    </message>
    <message>
        <source>Default Value</source>
        <translation>Oletusarvo</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation>Näytä/Piilota kentät</translation>
    </message>
    <message>
        <source>Invisible</source>
        <translation>Näkymätön</translation>
    </message>
    <message>
        <source>Visible</source>
        <translation>Näkyvä</translation>
    </message>
    <message>
        <source>Selection change</source>
        <translation>Valinnan muutos</translation>
    </message>
    <message>
        <source>label left, icon right</source>
        <translation>Nimiö vasemmalla, kuvake oikealla</translation>
    </message>
    <message>
        <source>Character spacing</source>
        <translation>Merkkien väli</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Yleiset</translation>
    </message>
    <message>
        <source>Special Options</source>
        <translation>Erikoisasetukset</translation>
    </message>
    <message>
        <source>Highlight</source>
        <translation>Korostus</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation>Täyttöväri</translation>
    </message>
    <message>
        <source>Clipping Path</source>
        <translation>Rajattu reitti (Clipping Path)</translation>
    </message>
    <message>
        <source>Use red text</source>
        <translation>Käytä punaista tekstiä</translation>
    </message>
    <message>
        <source>Decimal Places</source>
        <translation>Desimaalin tarkkuus</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>Avaa/käynnistä tiedosto</translation>
    </message>
    <message>
        <source>KeyStroke Script</source>
        <translation>Näppäin-skripti</translation>
    </message>
    <message>
        <source>Form Field</source>
        <translation>Lomakekenttä</translation>
    </message>
    <message>
        <source>Validation Script</source>
        <translation>Vahvistus-skripti</translation>
    </message>
    <message>
        <source>1,234.56</source>
        <translation>1,234.56</translation>
    </message>
    <message>
        <source>Text Note</source>
        <translation>Tekstiviesti</translation>
    </message>
    <message>
        <source>Word spacing</source>
        <translation>Sanojen väli</translation>
    </message>
    <message>
        <source>Right Pointer</source>
        <translation>Oikea osoitin</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Fontin Stroke-väri (fontin reunusväri)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Muuta stroke-väriä&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation>Suunta</translation>
    </message>
    <message>
        <source>Line Thickness</source>
        <translation>Viivan paksuus</translation>
    </message>
    <message>
        <source>On Receive Focus</source>
        <translation>Tarkenna</translation>
    </message>
</context>
<context>
    <name>AnnotTextInspectorDlg</name>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Teksti</translation>
    </message>
    <message>
        <source>Solid</source>
        <translation>Kiinteäviiva</translation>
    </message>
    <message>
        <source>Border Color</source>
        <translation>Reunuksen väri</translation>
    </message>
    <message>
        <source>Dashed</source>
        <translation>Katkoviiva</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Muoto</translation>
    </message>
    <message>
        <source>Line Width</source>
        <translation>Viivan leveys</translation>
    </message>
    <message>
        <source>Line Style</source>
        <translation>Viivan tyyli</translation>
    </message>
    <message>
        <source>Borders and Colors</source>
        <translation>Reunukset ja värit</translation>
    </message>
    <message>
        <source>Fill Color</source>
        <translation>Täyttöväri</translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <source>of</source>
        <translation>tästä</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Sivu</translation>
    </message>
    <message>
        <source>Your form was successfully submitted!</source>
        <translation>Lomakkeesi on onnistuneesti lähetetty!</translation>
    </message>
    <message>
        <source>There was a problem with your form submission.</source>
        <translation>Ilmeni ongelmia lomakkeen lähettämisen kanssa.</translation>
    </message>
    <message>
        <source>Error!</source>
        <translation>Virhe!</translation>
    </message>
</context>
<context>
    <name>DistanceToolDlg</name>
    <message>
        <source>=</source>
        <translation>=</translation>
    </message>
    <message>
        <source>X:</source>
        <translation>X:</translation>
    </message>
    <message>
        <source>Y:</source>
        <translation>Y:</translation>
    </message>
    <message>
        <source>in</source>
        <translation>tuuma</translation>
    </message>
    <message>
        <source>mm</source>
        <translation>mm</translation>
    </message>
    <message>
        <source>pt</source>
        <translation>piste</translation>
    </message>
    <message>
        <source>°</source>
        <translation>°</translation>
    </message>
    <message>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <source> sq</source>
        <translation> m2</translation>
    </message>
    <message>
        <source>Area</source>
        <translation>Alue</translation>
    </message>
    <message>
        <source>Scale Ratio:</source>
        <translation>Mittakaava:</translation>
    </message>
    <message>
        <source>Distance</source>
        <translation>Etäisyys</translation>
    </message>
    <message>
        <source>Distance Tool</source>
        <translation>Etäisyys-työkalut</translation>
    </message>
    <message>
        <source>Angle:</source>
        <translation>Kulma:</translation>
    </message>
    <message>
        <source>Perimeter</source>
        <translation>Ympyrä</translation>
    </message>
    <message>
        <source>Units and Markup Settings</source>
        <translation>Yksikkö- ja merkintäasetukset</translation>
    </message>
    <message>
        <source>Distance:</source>
        <translation>Etäisyys:</translation>
    </message>
    <message>
        <source>Annotation:</source>
        <translation>Merkinnät:</translation>
    </message>
    <message>
        <source>Cursor Location</source>
        <translation>Kursorin sijainti</translation>
    </message>
    <message>
        <source>Measurement</source>
        <translation>Mitat</translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <source> px</source>
        <translation> pikseliä</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>autom</translation>
    </message>
    <message>
        <source>Enter a web site:</source>
        <translation>Anna web-sivu:</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation>Sovita sivulle</translation>
    </message>
    <message>
        <source>Named Action</source>
        <translation>Nimetty tapahtuma</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Toiminto</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Valitse</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Mukauta</translation>
    </message>
    <message>
        <source>Fit Height</source>
        <translation>Sovita korkeuteen</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation>Sivunumero</translation>
    </message>
    <message>
        <source>Zoom Mode</source>
        <translation>Zoomaustapa</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation>Sovita leveyteen</translation>
    </message>
    <message>
        <source>Zoom (%)</source>
        <translation>Zoomaa (%)</translation>
    </message>
    <message>
        <source>Goto a page</source>
        <translation>Siirry sivulle</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>Avaa web-linkki</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation>Kaikki tiedostot Files (*.*)</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Avaa tiedosto</translation>
    </message>
    <message>
        <source>Fit Visible</source>
        <translation>Sovita näkyvään</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>Avaa/suorita tiedosto</translation>
    </message>
    <message>
        <source>Enter a file:</source>
        <translation>Anna tiedosto:</translation>
    </message>
</context>
<context>
    <name>BackgroundDlg</name>
    <message>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Ylhäältä</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Tiedosto</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Vasemmalta</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ei mitään</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Tallenna</translation>
    </message>
    <message>
        <source>from</source>
        <translation>kohdasta</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Väri</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Oikealta</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation>Skaalaa</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>Yksikkö</translation>
    </message>
    <message>
        <source>Page Range Options...</source>
        <translation>Sivualue-asetukset...</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>Millimetriä</translation>
    </message>
    <message>
        <source>Background</source>
        <translation>Tausta</translation>
    </message>
    <message>
        <source>Scale relative to target page</source>
        <translation>Skaalaa suhteessa kohdesivuun</translation>
    </message>
    <message>
        <source>Saved Settings</source>
        <translation>Tallennetut asetukset</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Alhaalta</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Valitse</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Keskeltä</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>Tuumaa</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation>Sivunumero</translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation>Tallenna asetukset</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation>Oletko varma että haluat poistaa asetuksen </translation>
    </message>
    <message>
        <source>Points</source>
        <translation>Pistettä</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Lähde</translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation>Peittävyys</translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation>Tallenna nykyiset asetukset nimellä:</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Paikka</translation>
    </message>
    <message>
        <source>Rotation</source>
        <translation>Kääntäminen</translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation>Virhe avattaessa asiakirjaa !</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Kaikki tuetut tiedostot (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Samannimiset asetukset on jo olemassa. Haluatko korvata ne tällä?</translation>
    </message>
    <message>
        <source>Horizontal distance</source>
        <translation>Vaakaetäisyys</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Ulkomuoto</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Avaa tiedosto</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation>Sivuja yhteensä: </translation>
    </message>
    <message>
        <source>Vertical distance</source>
        <translation>Pystyetäisyys</translation>
    </message>
</context>
<context>
    <name>HeaderAndFoterDlg</name>
    <message>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Fontti</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ei mitään</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Tallenna</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Koko</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Väri</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation>Alamarginaali</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>Yksikkö</translation>
    </message>
    <message>
        <source>Page Range Options...</source>
        <translation>Sivualue asetukset...</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>Millimetriä</translation>
    </message>
    <message>
        <source>Header &amp; Footer</source>
        <translation>Ylä- ja alatunniste</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation>Marginaalit</translation>
    </message>
    <message>
        <source>Saved Settings</source>
        <translation>Tallennetut asetukset</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation>Fonttityyppi</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation>Oikea marginaali</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>Tuumaa</translation>
    </message>
    <message>
        <source>Page number and date format</source>
        <translation>Sivunumero- ja päiväysmuoto</translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation>Tallenna asetukset</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation>Oletko varma että haluat poistaa asetuksen </translation>
    </message>
    <message>
        <source>Points</source>
        <translation>Pistettä</translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation>Tallenna nykyiset asetukset nimellä:</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation>Ylämarginaali</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation>Vasen marginaali</translation>
    </message>
    <message>
        <source>Insert Page Number</source>
        <translation>Lisää sivunumero</translation>
    </message>
    <message>
        <source>Insert Date</source>
        <translation>Lisäyspäivä</translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Samannimiset asetukset on jo olemassa. Korvataanko ne tällä?</translation>
    </message>
    <message>
        <source>Left Header Text</source>
        <translation>Ylätunnisteen teksti vasemmalla</translation>
    </message>
    <message>
        <source>Left Footer Text</source>
        <translation>Alatunnisteen teksti vasemmalla</translation>
    </message>
    <message>
        <source>Right Footer Text</source>
        <translation>Alatunnisteen teksti oikealla</translation>
    </message>
    <message>
        <source>Right Header Text</source>
        <translation>Ylätunnisteen teksti oikealla</translation>
    </message>
    <message>
        <source>Center Footer Text</source>
        <translation>Alatunnisteen teksti keskellä</translation>
    </message>
    <message>
        <source>Center Header Text</source>
        <translation>Ylätunnisteen teksti keskellä</translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muokkaa</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Tietoa</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ei mitään</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Tallenna</translation>
    </message>
    <message>
        <source>Sign</source>
        <translation>Allekirjoita</translation>
    </message>
    <message>
        <source>Date:</source>
        <translation>Päiväys:</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Avaa kuva</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Sähköposti</translation>
    </message>
    <message>
        <source>Stretch Image</source>
        <translation>Venytä kuva</translation>
    </message>
    <message>
        <source>This certificate is not trusted</source>
        <translation>Tämä allekirjoitus ei ole luotettava</translation>
    </message>
    <message>
        <source>Signature Properties</source>
        <translation>Allekirjoituksen määritykset</translation>
    </message>
    <message>
        <source>A password is required to open certificate:</source>
        <translation>Sertifikaatin avaamiseen tarvitaan salasana:</translation>
    </message>
    <message>
        <source>Saved Settings</source>
        <translation>Tallennetut asetukset</translation>
    </message>
    <message>
        <source>A error occurred during the signature verification!</source>
        <translation>Allekirjoituksen varmistamisen aikana tapahtui virhe!</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Mukauta</translation>
    </message>
    <message>
        <source>Signed by:</source>
        <translation>Allekirjoittanut:</translation>
    </message>
    <message>
        <source>I agree to specified parts of this document</source>
        <translation>Hyväksyn tämän asiakirjan tiettyjä osia</translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation>Tallenna asetukset</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation>Oletko varma että haluat poistaa tämän asetuksen </translation>
    </message>
    <message>
        <source>Reason</source>
        <translation>Syy</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Sijainti</translation>
    </message>
    <message>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation>Todistan tämän asiakirjan tarkkuuden ja eheyden</translation>
    </message>
    <message>
        <source>p12 Files (*.p12)</source>
        <translation>p12-tiedostot (*.p12)</translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation>Tallenna nykyiset asetukset nimellä:</translation>
    </message>
    <message>
        <source>Show Text</source>
        <translation>Näytä teksti</translation>
    </message>
    <message>
        <source>Browse...</source>
        <translation>Valitse...</translation>
    </message>
    <message>
        <source>Error during signature verification.</source>
        <translation>Virhe allekirjoituksen varmistamisessa.</translation>
    </message>
    <message>
        <source>I am approving this document</source>
        <translation>Hyväksyn tämän asiakirjan</translation>
    </message>
    <message>
        <source>Signature validity is UNKNOWN</source>
        <translation>Allekirjoituksen voimassaolo on TUNTEMATON</translation>
    </message>
    <message>
        <source>Validation Summary</source>
        <translation>Yhteenveto vahvistuksesta</translation>
    </message>
    <message>
        <source>I am the author of this document</source>
        <translation>Olen tämän asiakirjan tekijä</translation>
    </message>
    <message>
        <source>Reason:</source>
        <translation>Syy:</translation>
    </message>
    <message>
        <source>Digitally signed by </source>
        <translation>Digitaalisesti allekirjoittanut</translation>
    </message>
    <message>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation>Allekirjoittajien henkilöllisyys on tuntematon, koska ne eivä sisälly luotettujen henkilöllisyyksien luetteloosi. Eikä mistään sen pääsertifikaateista ole luottamustietoja.</translation>
    </message>
    <message>
        <source>Show Image</source>
        <translation>Näytä kuva</translation>
    </message>
    <message>
        <source>Location:</source>
        <translation>Paikkakunta:</translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Samannimiset asetukset on jo olemassa. Haluatko korvata ne tällä?</translation>
    </message>
    <message>
        <source>Sign As</source>
        <translation>Allekirjoita nimellä</translation>
    </message>
    <message>
        <source>Details</source>
        <translation>Tiedot</translation>
    </message>
    <message>
        <source>Signature is VALID</source>
        <translation>Allekirjoitus on VOIMASSA</translation>
    </message>
    <message>
        <source>Signature is INVALID</source>
        <translation>AllekirjoitusEI OLE VOIMASSA</translation>
    </message>
    <message>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation>Kuvatiedostot (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Avaa tiedosto</translation>
    </message>
    <message>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation>Asiakirjaa on muutettu tai se on vioittunut allekirjoitusten jälkeen.</translation>
    </message>
    <message>
        <source>I have reviewed this document</source>
        <translation>Olen tarkastanut tämän asiakirjan</translation>
    </message>
    <message>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation>Asiakirjaa ei ole muutettu allekirjoitusten jälkeen.</translation>
    </message>
    <message>
        <source>Signer&apos;s Contact Information:</source>
        <translation>Allekirjoittaneen yhteystiedot:</translation>
    </message>
    <message>
        <source>Lock document after signing</source>
        <translation>Lukitse asiakirja allekirjoituksen jälkeen</translation>
    </message>
    <message>
        <source>Details: The signature byte range is invalid</source>
        <translation>Tiedot: Allekirjoituksen tavualue on virheellinen</translation>
    </message>
    <message>
        <source>Signature Preview</source>
        <translation>Allekirjoituksen esikatselu</translation>
    </message>
    <message>
        <source>Text For Signing</source>
        <translation>Teksi allekirjoitukselle</translation>
    </message>
</context>
<context>
    <name>WatermarkDlg</name>
    <message>
        <source> ?</source>
        <translation> ?</translation>
    </message>
    <message>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <source>Top</source>
        <translation>Ylhäältä</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Tiedosto</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>Fontti</translation>
    </message>
    <message>
        <source>Left</source>
        <translation>Vasemmalta</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ei mitään</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Tallenna</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Koko</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Teksti</translation>
    </message>
    <message>
        <source>auto</source>
        <translation>autom</translation>
    </message>
    <message>
        <source>from</source>
        <translation> </translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Väri</translation>
    </message>
    <message>
        <source>Right</source>
        <translation>Oikealta</translation>
    </message>
    <message>
        <source>Scale</source>
        <translation>Skaalaa</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>Yksikkö</translation>
    </message>
    <message>
        <source>Page Range Options...</source>
        <translation>Sivualue-asetukset...</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>Millimetriä</translation>
    </message>
    <message>
        <source>Scale relative to target page</source>
        <translation>Skaalaa suhteessa kohdesivuun</translation>
    </message>
    <message>
        <source>Saved Settings</source>
        <translation>Tallennetut asetukset</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation>Fonttityyppi</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation>Alhaalta</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Valitse</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Keskeltä</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>Tuumaa</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation>Sivunumero</translation>
    </message>
    <message>
        <source>Save Settings</source>
        <translation>Tallenna asetukset</translation>
    </message>
    <message>
        <source>Are you sure you want to delete the setting </source>
        <translation>Oletko varma että haluat poistaa asetuksen </translation>
    </message>
    <message>
        <source>Points</source>
        <translation>Pistettä</translation>
    </message>
    <message>
        <source>Source</source>
        <translation>Lähde</translation>
    </message>
    <message>
        <source>Opacity</source>
        <translation>Peittävyys</translation>
    </message>
    <message>
        <source>Save current settings as:</source>
        <translation>Tallenna nykyiset asetukset nimellä:</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Sijainti</translation>
    </message>
    <message>
        <source>Rotation</source>
        <translation>Kääntäminen</translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation>Asiakirjaa avattaessa tapahtui virhe !</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Kaikki tuetut tiedostot (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation>Samannimiset asetukset on jo olemassa. Haluatko korvata ne tällä?</translation>
    </message>
    <message>
        <source>Horizontal distance</source>
        <translation>Vaakaetäisyys</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation>Vesileima</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Ulkomuoto</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Avaa tiedosto</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation>Sivuja yhteensä: </translation>
    </message>
    <message>
        <source>Vertical distance</source>
        <translation>Pystyetäisyys</translation>
    </message>
</context>
<context>
    <name>PageSetupDialog</name>
    <message>
        <source>72</source>
        <translation>72</translation>
    </message>
    <message>
        <source>150</source>
        <translation>150</translation>
    </message>
    <message>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <source>600</source>
        <translation>600</translation>
    </message>
    <message>
        <source>900</source>
        <translation>900</translation>
    </message>
    <message>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <source>1200</source>
        <translation>1200</translation>
    </message>
    <message>
        <source>bottom margin</source>
        <translation>Alamarginaali</translation>
    </message>
    <message>
        <source>Paper</source>
        <translation>Paperi</translation>
    </message>
    <message>
        <source>right margin</source>
        <translation>Oikea marginaali</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation>Marginaalit</translation>
    </message>
    <message>
        <source>Width:</source>
        <translation>Leveys:</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Resoluutio</translation>
    </message>
    <message>
        <source>top margin</source>
        <translation>Ylämarginaali</translation>
    </message>
    <message>
        <source>left margin</source>
        <translation>Vasen marginaali</translation>
    </message>
    <message>
        <source>Page size:</source>
        <translation>Sivun koko:</translation>
    </message>
    <message>
        <source>Printer Settings</source>
        <translation>Tulostimen asetukset</translation>
    </message>
    <message>
        <source>Height:</source>
        <translation>Korkeus:</translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <source>A0</source>
        <translation>A0</translation>
    </message>
    <message>
        <source>A1</source>
        <translation>A1</translation>
    </message>
    <message>
        <source>A2</source>
        <translation>A2</translation>
    </message>
    <message>
        <source>A3</source>
        <translation>A3</translation>
    </message>
    <message>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <source>A5</source>
        <translation>A5</translation>
    </message>
    <message>
        <source>A6</source>
        <translation>A6</translation>
    </message>
    <message>
        <source>A7</source>
        <translation>A7</translation>
    </message>
    <message>
        <source>A8</source>
        <translation>A8</translation>
    </message>
    <message>
        <source>A9</source>
        <translation>A9</translation>
    </message>
    <message>
        <source>B0</source>
        <translation>B0</translation>
    </message>
    <message>
        <source>B1</source>
        <translation>B1</translation>
    </message>
    <message>
        <source>B2</source>
        <translation>B2</translation>
    </message>
    <message>
        <source>B3</source>
        <translation>B3</translation>
    </message>
    <message>
        <source>B4</source>
        <translation>B4</translation>
    </message>
    <message>
        <source>B5</source>
        <translation>B5</translation>
    </message>
    <message>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <source>A10</source>
        <translation>A10</translation>
    </message>
    <message>
        <source>Note</source>
        <translation>Viesti</translation>
    </message>
    <message>
        <source>Folio</source>
        <translation>Kaksitaite</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation>Alamarginaali</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>Yksikkö</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Leveys</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>Millimetriä</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation>Viimeisen sivun jälkeen</translation>
    </message>
    <message>
        <source>Contents Size</source>
        <translation>Sisällön koko</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation>Ennen ensimmäistä sivua</translation>
    </message>
    <message>
        <source>ANSI C</source>
        <translation>ANSI C</translation>
    </message>
    <message>
        <source>ANSI D</source>
        <translation>ANSI D</translation>
    </message>
    <message>
        <source>ANSI E</source>
        <translation>ANSI E</translation>
    </message>
    <message>
        <source>ANSI F</source>
        <translation>ANSI F</translation>
    </message>
    <message>
        <source>Create</source>
        <translation>Luo</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation>Oikea marginaali</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Vaaka</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Korkeus</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>Tuumaa</translation>
    </message>
    <message>
        <source>Letter</source>
        <translation>Kirje</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>Pistettä</translation>
    </message>
    <message>
        <source>Quarto</source>
        <translation>Quarto (10 x 8 tuumaa)</translation>
    </message>
    <message>
        <source>Custom page size</source>
        <translation>Mukautettu sivun koko</translation>
    </message>
    <message>
        <source>Page(s)</source>
        <translation>Sivu(a)</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Pysty</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Sijainti</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation>Ylämarginaali</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation>Vasen marginaali</translation>
    </message>
    <message>
        <source>After current page</source>
        <translation>Nykyisen sivun jälkeen</translation>
    </message>
    <message>
        <source>Statement</source>
        <translation>Selitys</translation>
    </message>
    <message>
        <source>Tabloid</source>
        <translation>Tabloid</translation>
    </message>
    <message>
        <source>Before current page</source>
        <translation>Ennen nykyistä sivua</translation>
    </message>
    <message>
        <source>Executive</source>
        <translation>Käynnistäjä</translation>
    </message>
    <message>
        <source>Number of pages</source>
        <translation>Sivujen määrä</translation>
    </message>
    <message>
        <source>Page Size</source>
        <translation>Sivun koko</translation>
    </message>
</context>
<context>
    <name>QUnitsComboBox</name>
    <message>
        <source>CC</source>
        <translation> CC</translation>
    </message>
    <message>
        <source>DD</source>
        <translation> DD</translation>
    </message>
    <message>
        <source>in</source>
        <translation> in</translation>
    </message>
    <message>
        <source>mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <source>pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <source>PÌ¸</source>
        <translation> PÌ¸</translation>
    </message>
    <message>
        <source>Didot (DD)</source>
        <translation>Didot (DD)</translation>
    </message>
    <message>
        <source>Pica (PÌ¸)</source>
        <translation>Pica (PÌ¸)</translation>
    </message>
    <message>
        <source>Cicero (CC)</source>
        <translation>Cicero (CC)</translation>
    </message>
    <message>
        <source>Millimeters (mm)</source>
        <translation>Millimetriä (mm)</translation>
    </message>
    <message>
        <source>Points (pt)</source>
        <translation>Pistettä (pt)</translation>
    </message>
    <message>
        <source>Inches (in)</source>
        <translation>Tuumaa (in)</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <source>F9</source>
        <translation>F9</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>F11</source>
        <translation>F11</translation>
    </message>
    <message>
        <source>F12</source>
        <translation>F12</translation>
    </message>
    <message>
        <source>Del</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Leikkaa</translation>
    </message>
    <message>
        <source>End</source>
        <translation>Loppu</translation>
    </message>
    <message>
        <source>OCR</source>
        <translation>Optinen tekstin lukija (OCR)</translation>
    </message>
    <message>
        <source>New</source>
        <translation>Uusi</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopioi</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muokkaa</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>Lopeta</translation>
    </message>
    <message>
        <source>File</source>
        <translation>Tiedosto</translation>
    </message>
    <message>
        <source>Find</source>
        <translation>Etsi</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <source>Grid</source>
        <translation>Ruudukko</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>Ohje</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Koti</translation>
    </message>
    <message>
        <source>Send to Back selected object.</source>
        <translation>Vie valitut objektit taakse.</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>Viiva</translation>
    </message>
    <message>
        <source>Link</source>
        <translation>Linkki</translation>
    </message>
    <message>
        <source>Main</source>
        <translation>Pääpalkki</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>Valikko</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Avaa</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Sivu</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Polku</translation>
    </message>
    <message>
        <source>PgUp</source>
        <translation>PgUp</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>Tee uudelleen</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Tallenna</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Teksti</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Kumoa</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Näytä</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Zoomaa</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Kumoa (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Kumoa viimeisin tapahtuma&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Align Right</source>
        <translation>Järjestä oikealle</translation>
    </message>
    <message>
        <source>Align Bottom</source>
        <translation>Järjestä alas</translation>
    </message>
    <message>
        <source>Import Comments Data...</source>
        <translation>Tuo kommenttidata...</translation>
    </message>
    <message>
        <source>Print Preview</source>
        <translation>Tulostuksen esikatselu</translation>
    </message>
    <message>
        <source>Export Comments Data...</source>
        <translation>Vie kommenttidata...</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Tietoa ohjelmasta</translation>
    </message>
    <message>
        <source>Alt+1</source>
        <translation>Alt+1</translation>
    </message>
    <message>
        <source>Alt+2</source>
        <translation>Alt+2</translation>
    </message>
    <message>
        <source>Alt+3</source>
        <translation>Alt+3</translation>
    </message>
    <message>
        <source>Alt+4</source>
        <translation></translation>
    </message>
    <message>
        <source>Alt+5</source>
        <translation>Alt+5</translation>
    </message>
    <message>
        <source>Arrow</source>
        <translation>Nuoli</translation>
    </message>
    <message>
        <source>Brush</source>
        <translation>Sivellin</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Sähköposti</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation>Lomakkeet</translation>
    </message>
    <message>
        <source>Go To</source>
        <translation>Siirry kohtaan</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Kuva</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Liitä</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Tulosta</translation>
    </message>
    <message>
        <source>Stamp</source>
        <translation>Leima</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>Työkalut</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Leveys</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation>Sovita sivulle</translation>
    </message>
    <message>
        <source>Edit Text</source>
        <translation>Muokkaa tekstiä</translation>
    </message>
    <message>
        <source>Page Display</source>
        <translation>Sivun näyttö</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Tallenna (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Tallenna asiakirja&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Send to Back</source>
        <translation>Vie taakse</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Poista objekti(t) (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Poista valitut objektit&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>List Box</source>
        <translation>Lista</translation>
    </message>
    <message>
        <source>List box</source>
        <translation>Lista</translation>
    </message>
    <message>
        <source>Snap to Grid</source>
        <translation>Kohdista ruudukkoon</translation>
    </message>
    <message>
        <source>Highlight Text</source>
        <translation>Korostettu teksti</translation>
    </message>
    <message>
        <source>Perimeter Tool</source>
        <translation>Ympyrä-työkalu</translation>
    </message>
    <message>
        <source>Underline Text</source>
        <translation>Alleviivattu teksti</translation>
    </message>
    <message>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation>Valitse ja muokkaa tekstiä, kuvia ja merkintöjä lomakekentissä...</translation>
    </message>
    <message>
        <source>Radio Button</source>
        <translation>Valintapainike</translation>
    </message>
    <message>
        <source>Check for Updates</source>
        <translation>Tarkista päivitykset</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>Suurenna</translation>
    </message>
    <message>
        <source>Object Inspector</source>
        <translation>Objektin ominaisuudet-ikkuna (Odject Inspector)</translation>
    </message>
    <message>
        <source>Background</source>
        <translation>Tausta</translation>
    </message>
    <message>
        <source>Empty recent files list</source>
        <translation>Tyhjennä viimeisimmät tiedostot-lista</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Formatted Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new formatted text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Lisää muotoiltu teksti&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Lisää uusi muotoiltu teksti nykyiselle sivulle&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Crop Pages</source>
        <translation>Rajaa sivuja</translation>
    </message>
    <message>
        <source>Can&apos;t find :</source>
        <translation>Ei löydy:</translation>
    </message>
    <message>
        <source>Save the document</source>
        <translation>Tallenna asiakirja</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Käännä 90 astetta vastapäivään</translation>
    </message>
    <message>
        <source>Distance Tool</source>
        <translation>Etäisyys työkalu</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Lisää teksti (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Lisää uusi teksti tälle sivulle&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Rotate Pages</source>
        <translation>Käännä sivuja</translation>
    </message>
    <message>
        <source>Export Form Data...</source>
        <translation>Vie lomakedata...</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Lisää kuva (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Lisää uusi kuva tälle sivulle&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Export completed</source>
        <translation>Vienti suoritettu</translation>
    </message>
    <message>
        <source>Radio button</source>
        <translation>Valintapainike</translation>
    </message>
    <message>
        <source>Home page</source>
        <translation>Kotisivu</translation>
    </message>
    <message>
        <source>Combo Box</source>
        <translation>Valikko</translation>
    </message>
    <message>
        <source>Combo box</source>
        <translation>Valikko</translation>
    </message>
    <message>
        <source>Do you want to delete the Watermarks from the document?</source>
        <translation>Haluatko poistaa vesileimat asiakirjasta?</translation>
    </message>
    <message>
        <source>Recent Files</source>
        <translation>Viimeisimmät tiedostot</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation>Poista sivuja</translation>
    </message>
    <message>
        <source>Save Optimized As...</source>
        <translation>Tallenna optimoidut nimellä...</translation>
    </message>
    <message>
        <source>Do you want to delete the Background from the document?</source>
        <translation>Haluatko poistaa taustat asiakirjasta?</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Uusi (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Luo uusi tyhjä PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Find Next</source>
        <translation>Etsi seuraava</translation>
    </message>
    <message>
        <source>Hand Tool</source>
        <translation>Käsityökalu</translation>
    </message>
    <message>
        <source>Open a PDF file</source>
        <translation>Avaa PDF-tiedosto</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Tallenna nimellä (Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Tallenna PDF-asiakirja uudella nimellä&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Save the document with a new name</source>
        <translation>Tallenna asiakirja uudella nimellä</translation>
    </message>
    <message>
        <source>Send file via email</source>
        <translation>Lähetä tiedosto sähköpostilla</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Liitä (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Liitä leikepöydältä&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <source>Button</source>
        <translation>Painike</translation>
    </message>
    <message>
        <source>A error occurred during the signature verification!</source>
        <translation>Allekirjoituksen varmistamisessa tapahtui virhe!</translation>
    </message>
    <message>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <source>Ctrl+1</source>
        <translation>Ctrl+1</translation>
    </message>
    <message>
        <source>Ctrl+2</source>
        <translation>Ctrl+2</translation>
    </message>
    <message>
        <source>Ctrl+3</source>
        <translation>Ctrl+3</translation>
    </message>
    <message>
        <source>Ctrl+6</source>
        <translation>Ctrl+6</translation>
    </message>
    <message>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <source>Ctrl+J</source>
        <translation>Ctrl+J</translation>
    </message>
    <message>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Filter</source>
        <translation>Suodin</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>HøjdeKorkeus</translation>
    </message>
    <message>
        <source>Add Sticky Note</source>
        <translation>Lisää muistilappu</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>Kuvina</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Muistilappu&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Klikkaa sivulla kohtaa mihin haluat liittää muistilapun&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Insert new image to current page</source>
        <translation>Lisää uusi kuva nykyiselle sivulle</translation>
    </message>
    <message>
        <source>Page :</source>
        <translation>Sivu:</translation>
    </message>
    <message>
        <source>Font type</source>
        <translation>Fonttityyppi</translation>
    </message>
    <message>
        <source>PgDown</source>
        <translation>PgDown</translation>
    </message>
    <message>
        <source>Pencil</source>
        <translation>Kynä</translation>
    </message>
    <message>
        <source>Reduce Page Thumbnails</source>
        <translation>Pienennä sivun esikatselukuvia</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Valitse teksti (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Valitse teksti kopioitavaksi ja liitettäväksi&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Open window with document properties</source>
        <translation>Avaa  asiakirjan ominaisuudet ikkuna</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation>Objektit</translation>
    </message>
    <message>
        <source>Undo the last action</source>
        <translation>Kumoa viimeisin tapahtuma</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Etsi</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Tuo eteen&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Tuo valitut objektit eteen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>Asiakirja</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>nimetön</translation>
    </message>
    <message>
        <source>Find Previous</source>
        <translation>Etsi edellinen</translation>
    </message>
    <message>
        <source>Full Screen</source>
        <translation>Koko näyttö</translation>
    </message>
    <message>
        <source>Reset Forms</source>
        <translation>Nollaa lomakkeet</translation>
    </message>
    <message>
        <source>FDF Files (*.fdf)</source>
        <translation>FDF-tiedostot (*.fdf)</translation>
    </message>
    <message>
        <source>Master PDF Editor can&apos;t find any Watermarks in the document.</source>
        <translation>Master PDF Editor ei löydä vesileimaa asiakirjasta.</translation>
    </message>
    <message>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation>Uusi versio on ilmestynyt !
Haluatko ladata sen nyt?</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Kommentit</translation>
    </message>
    <message>
        <source>Text Field</source>
        <translation>Tekstikenttä</translation>
    </message>
    <message>
        <source>Edit Forms</source>
        <translation>Muokkaa lomakkeita</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Muokkaa lomaketta (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Valitse lomake muokattavaksi&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Close Without Saving</source>
        <translation>Sulje tallentamatta</translation>
    </message>
    <message>
        <source>Contents</source>
        <translation>Ohje (Internetissä)</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation>Sovita leveyteen</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>Pienennä</translation>
    </message>
    <message>
        <source>Edit Tools</source>
        <translation>Muokkaustyökalut</translation>
    </message>
    <message>
        <source>Toolbars</source>
        <translation>Työkalupalkit</translation>
    </message>
    <message>
        <source>Enlarge Page Thumbnails</source>
        <translation>Suurenna sivun esikatselukuvia</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF-tiedostot (*.pdf)</translation>
    </message>
    <message>
        <source>Font Not Embedded</source>
        <translation>Fontti ei ole upotettu</translation>
    </message>
    <message>
        <source>Open failed</source>
        <translation>Avausvirhe</translation>
    </message>
    <message>
        <source>Save failed</source>
        <translation>Tallennusvirhe</translation>
    </message>
    <message>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>Ohjelma on käynnistettävä uudelleen, että muutokset tulevat voimaan.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Kopioi (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Kopioi valitut objektit leikepöydälle&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Tee uudelleen (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Tee uudelleen viimeksi kumottu tapahtuma.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Käännä 90 astetta myötäpäivään</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Ominaisuudet</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation>Tätä tiedostoa ei voida tallentaa:</translation>
    </message>
    <message>
        <source>Align Center Vertical</source>
        <translation>Järjestä keskelle pystytasossa</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Avaa tiedosto (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Avaa PDF- tai XPS-tiedosto&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation>Leikkaa valitut objektit ja liitä ne leikepöydälle</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation>Tallenna nimellä...</translation>
    </message>
    <message>
        <source>Move Pages</source>
        <translation>Siirrä sivuja</translation>
    </message>
    <message>
        <source>Export to</source>
        <translation>Vie</translation>
    </message>
    <message>
        <source>Print the document</source>
        <translation>Tulosta asiakirja</translation>
    </message>
    <message>
        <source>Page layout</source>
        <translation>Sivun asettelu</translation>
    </message>
    <message>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation>Haluatko poistaa ylä- ja alatunnisteen asiakirjasta?</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation>Todellinen koko</translation>
    </message>
    <message>
        <source>JavaScript Console</source>
        <translation>JavaScript-konsoli</translation>
    </message>
    <message>
        <source>There was an error opening the document !</source>
        <translation>Asiakirjaa avattaessa tapahtui virhe !</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Email delivery&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send file via email&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sähköposti&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Lähetä sähköpostitse&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Strikeout Text</source>
        <translation>Yliviivattu teksti</translation>
    </message>
    <message>
        <source>Select text for editing</source>
        <translation>Valitse teksti kopioitavaksi</translation>
    </message>
    <message>
        <source>Insert new text to current page</source>
        <translation>Lisää uusi teksti nykyiselle sivulle</translation>
    </message>
    <message>
        <source>Alt+Del</source>
        <translation>Alt+Del</translation>
    </message>
    <message>
        <source>Bring to Front</source>
        <translation>Tuo eteen</translation>
    </message>
    <message>
        <source>Blank PDF</source>
        <translation>Tyhjä PDF-asiakirja</translation>
    </message>
    <message>
        <source>Attach a File as a Comment</source>
        <translation>Liitä tiedosto kommentiksi</translation>
    </message>
    <message>
        <source>Characters</source>
        <translation>Merkistö</translation>
    </message>
    <message>
        <source>Document JavaScript</source>
        <translation>Asiakirjan JavaScriptit</translation>
    </message>
    <message>
        <source>Master PDF Editor</source>
        <translation>Master PDF Editor</translation>
    </message>
    <message>
        <source>Statusbar</source>
        <translation>Tilarivi</translation>
    </message>
    <message>
        <source>Create a new document from files</source>
        <translation>Luo uusi PDF-asiakirja tiedostoista</translation>
    </message>
    <message>
        <source>Header and Footer</source>
        <translation>Ylä- ja alatunniste</translation>
    </message>
    <message>
        <source>Your installed version of Qt</source>
        <translation>Asennettu Qt-versiosi</translation>
    </message>
    <message>
        <source>Replace Document Colors</source>
        <translation>Korvaa asiakirjan värejä</translation>
    </message>
    <message>
        <source>Paste from the Clipboard</source>
        <translation>Liitä leikepöydältä</translation>
    </message>
    <message>
        <source>Redo the previously undone action.</source>
        <translation>Tee uudelleen edellinen tapahtuma.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Käsityökalu (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Käsityökalulla voit liikuttaa sivuja, avata linkkejä ja valita tekstejä.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Callout</source>
        <translation>Huomiotekstit</translation>
    </message>
    <message>
        <source>Delete the currently selected object(s)</source>
        <translation>Poista tällä hetkellä valitut objektit</translation>
    </message>
    <message>
        <source>Create a new document from scanner</source>
        <translation>Luo uusi PDF-asiakirja skannerilta</translation>
    </message>
    <message>
        <source>Select text for copying and pasting</source>
        <translation>Valitse teksti joka kopioidaan ja liitetään</translation>
    </message>
    <message>
        <source>Shading</source>
        <translation>Varjostus</translation>
    </message>
    <message>
        <source>Select Text</source>
        <translation>Valitse teksti</translation>
    </message>
    <message>
        <source>Paste to Multiple Pages</source>
        <translation>Liitä monisivuasiakirjaan</translation>
    </message>
    <message>
        <source>First Page</source>
        <translation>Ensimmäinen sivu</translation>
    </message>
    <message>
        <source>Last Page</source>
        <translation>Viimeinen sivu</translation>
    </message>
    <message>
        <source>Insert new link to current page</source>
        <translation>Lisää uusi linkki nykyiselle sivulle</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>Suorakulmio</translation>
    </message>
    <message>
        <source>Watermark</source>
        <translation>Vesileima</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation>Rekisteröi...</translation>
    </message>
    <message>
        <source>Edit Box</source>
        <translation>Muokkausruutu</translation>
    </message>
    <message>
        <source>Area Tool</source>
        <translation>Alue-työkalu</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps);;All Files (*)</source>
        <translation>Kaikki tuetut tiedostot (*.pdf *.xps);;PDF-tiedostot (*.pdf);;XPS-tiedostot (*.xps);;Kaikki tiedostot (*)</translation>
    </message>
    <message>
        <source>Drawing</source>
        <translation>Piirros</translation>
    </message>
    <message>
        <source>Ctrl+F11</source>
        <translation>Ctrl+F11</translation>
    </message>
    <message>
        <source>Ctrl+F12</source>
        <translation>Ctrl+F12</translation>
    </message>
    <message>
        <source>Check Box</source>
        <translation>Valintaruutu</translation>
    </message>
    <message>
        <source>Check box</source>
        <translation>Valintaruutu</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Valitse kaikki</translation>
    </message>
    <message>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation>Asiakirjaa %s on muokattu. 
Haluatko tallentaa muutokset?</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation>Sivun ominaisuudet</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>Tiedosto voi olla kirjoitussuojattu tai toisen sovelluksen käytössä.</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation>Edellinen sivu</translation>
    </message>
    <message>
        <source>Highlight Fields</source>
        <translation>Korosta kentät</translation>
    </message>
    <message>
        <source>Document Actions</source>
        <translation>Asikirjan tapahtumat</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Avaa tiedosto</translation>
    </message>
    <message>
        <source>Saving in XPS is temporarily not supported.
Choose PDF file name for saving.</source>
        <translation>Tilapäistä tallennusta ei tueta XPS: ssä.
Valitse PDF-tiedostonimi tallennukseen.</translation>
    </message>
    <message>
        <source>Cannot open file :
</source>
        <translation>Tätä tiedostoa ei voi avata :
</translation>
    </message>
    <message>
        <source>Create a new blank PDF</source>
        <translation>Luo uusi tyhjä PDF-asiakirja</translation>
    </message>
    <message>
        <source>Selected</source>
        <translation>Valitut</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation>Ellipsi</translation>
    </message>
    <message>
        <source>Menu Bar</source>
        <translation>Valikkopalkki</translation>
    </message>
    <message>
        <source>Prev/Next</source>
        <translation>Edellinen/seuraava</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Lisää linkki (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Lisää uusi linkki tälle sivulle&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>Typewriter</source>
        <translation>Kirjoituskone-työkalu</translation>
    </message>
    <message>
        <source>Master PDF Editor can&apos;t find any Background in the document.</source>
        <translation>Master PDF Editor ei löydä taustaa asiakirjasta.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Muokkaa asiakirjaa (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Valitse ja muokkaa tekstiä, kuvia ja merkintöjä lomakekentissä ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Ctrl+Shift++</source>
        <translation>Ctrl+Shift++</translation>
    </message>
    <message>
        <source>Ctrl+Shift+-</source>
        <translation>Ctrl+Shift+-</translation>
    </message>
    <message>
        <source>Ctrl+Shift+B</source>
        <translation>Ctrl+Shift+B</translation>
    </message>
    <message>
        <source>Ctrl+Shift+E</source>
        <translation>Ctrl+Shift+E</translation>
    </message>
    <message>
        <source>Ctrl+Shift+H</source>
        <translation>Ctrl+Shift+H</translation>
    </message>
    <message>
        <source>Ctrl+Shift+I</source>
        <translation>Ctrl+Shift+I</translation>
    </message>
    <message>
        <source>Ctrl+Shift+L</source>
        <translation>Ctrl+Shift+L</translation>
    </message>
    <message>
        <source>Ctrl+Shift+N</source>
        <translation>Ctrl+Shift+N</translation>
    </message>
    <message>
        <source>Ctrl+Shift+P</source>
        <translation>Ctrl+Shift+P</translation>
    </message>
    <message>
        <source>Ctrl+Shift+S</source>
        <translation>Ctrl+Shift+S</translation>
    </message>
    <message>
        <source>Ctrl+Shift+U</source>
        <translation>Ctrl+Shift+U</translation>
    </message>
    <message>
        <source>Ctrl+Shift+V</source>
        <translation>Ctrl+Shift+V</translation>
    </message>
    <message>
        <source>Ctrl+Shift+W</source>
        <translation>Ctrl+Shift+W</translation>
    </message>
    <message>
        <source>From Scanner</source>
        <translation>PDF-asiakirja skannerilta</translation>
    </message>
    <message>
        <source>Align Center Horizontal</source>
        <translation>Järjestä keskelle vaakatasossa</translation>
    </message>
    <message>
        <source>Set Fit to Page</source>
        <translation>Aseta sivulle sopivaksi</translation>
    </message>
    <message>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation>Kopioi valitut objektit ja liitä ne leikepöydälle</translation>
    </message>
    <message>
        <source>Facing Pages</source>
        <translation>Sivut vierekkäin</translation>
    </message>
    <message>
        <source>Measurements</source>
        <translation>Mitat</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Tulosta (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Tulosta asiakirja&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Align Objects</source>
        <translation>Järjestä objektit</translation>
    </message>
    <message>
        <source>Open Object Inspector</source>
        <translation>Avaa objektin ominaisuudet-ikkuna (Odject Inspector)</translation>
    </message>
    <message>
        <source>Master PDF Editor can&apos;t find any Headers and Footers in the document.</source>
        <translation>Master PDF Editor ei löydä ylä- eikä alatunnistetta asiakirjasta.</translation>
    </message>
    <message>
        <source>Formatted Text</source>
        <translation>Muotoiltu teksti</translation>
    </message>
    <message>
        <source>Align Left</source>
        <translation>Järjestä vasemmalle</translation>
    </message>
    <message>
        <source>Insert Pages...</source>
        <translation>Lisää sivuja...</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation>Lisää tyhjiä sivuja</translation>
    </message>
    <message>
        <source>Import Form Data...</source>
        <translation>Tuo lomakedata...</translation>
    </message>
    <message>
        <source>Edit Document</source>
        <translation>Muokkaa asiakirjaa</translation>
    </message>
    <message>
        <source>Signature</source>
        <translation>Allekirjoitus</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Ominaisuudet (Ctrl+D)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Avaa asiakirjan ominaisuudet -ikkuna&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Show Cover Page During Facing</source>
        <translation>Kansilehti yksin sivut vierekkäin näkymässä</translation>
    </message>
    <message>
        <source>Font Embedded</source>
        <translation>Upotettu fontti</translation>
    </message>
    <message>
        <source>Ctrl+Alt+S</source>
        <translation>Ctrl+Alt+S</translation>
    </message>
    <message>
        <source>Shift+F3</source>
        <translation>Shift+F3</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Vie taakse&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Vie taakse valitun objektin.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Muokkaa tekstiobjektia (Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Valitse muokattava teksti&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Click the page to add a note at that position</source>
        <translation>Klikkaa sivulla kohtaa mihin haluat liittää muistilapun</translation>
    </message>
    <message>
        <source>From Files</source>
        <translation>PDF-asiakirja tiedostoista</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation>Seuraava sivu</translation>
    </message>
    <message>
        <source>Extract Pages...</source>
        <translation>Erota sivuja...</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Leikkaa (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Leikkaa valittu objekti ja kopioi se leikepöydälle&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>You already have the latest version!</source>
        <translation>Käytössäsi on jo uusin versio!</translation>
    </message>
    <message>
        <source>Bring to Front selected object.</source>
        <translation>Tuo valitut objektit eten.</translation>
    </message>
    <message>
        <source>Align Top</source>
        <translation>Järjestä ylös</translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>Takaisin</translation>
    </message>
    <message>
        <source>Registration Code</source>
        <translation>Rekisteröintikoodi</translation>
    </message>
    <message>
        <source>Registration Info</source>
        <translation>Rekisteröintitiedot</translation>
    </message>
    <message>
        <source>Thanks for registration.</source>
        <translation>Kiitos rekisteröinnistä.</translation>
    </message>
    <message>
        <source>Offline Activation</source>
        <translation>Offline-aktivointi</translation>
    </message>
    <message>
        <source>Registered version</source>
        <translation>Rekisteröityversio</translation>
    </message>
    <message>
        <source>License is deactivated.</source>
        <translation>Lisenssin aktivointi on poistettu.</translation>
    </message>
    <message>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation>Kun tilauksesi on suoritettu, 
saat automaattisesti 
rekisteröintikoodin sähköpostiisi.</translation>
    </message>
    <message>
        <source>Buy Online</source>
        <translation>Osta netin kautta</translation>
    </message>
    <message>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation>Jos haluat rekisteröidä tämän lisenssin toiselle 
tietokoneelle. Klikkaa &quot;Poista aktivointi&quot;-painiketta. 

Tämän jälkeen voit rekisteröidä lisenssin toiselle koneelle.</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Lähetä ID-avain ja rekisteröintikoodi osoitteeseen: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Kun saat koodisi, kirjoita se &amp;quot;Aktivointikoodi&amp;quot; kenttään&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>You have exceeded the number of available activations.</source>
        <translation>Olet ylittänyt käytettävissä olevien aktivointien määrän.</translation>
    </message>
    <message>
        <source>Activate</source>
        <translation>Aktivoi</translation>
    </message>
    <message>
        <source>Deactivate</source>
        <translation>Poista aktivointi</translation>
    </message>
    <message>
        <source>Activation Code</source>
        <translation>Aktivointikoodi</translation>
    </message>
    <message>
        <source>Too many activations!</source>
        <translation>Liian monta aktivointia!</translation>
    </message>
</context>
<context>
    <name>AboutDialog</name>
    <message>
        <source>Ok</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>About</source>
        <translation>Tietoa</translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <source>Ok</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Sivut</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Tämä sivu</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>Tiedostonimi</translation>
    </message>
    <message>
        <source>Export Pages</source>
        <translation>Vie sivut</translation>
    </message>
    <message>
        <source>Extract pages as a single file</source>
        <translation>Erota sivut ja tallenna yhdeksi tiedostoksi</translation>
    </message>
    <message>
        <source>Export Bookmarks</source>
        <translation>Vie kirjanmerkit</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Valitse...</translation>
    </message>
    <message>
        <source>Save As PDF</source>
        <translation>Tallenna PDF-tiedostona</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF-tiedostot (*.pdf)</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation>Ei voida tallentaa tiedostoa:</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Sivualue</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>Esim: 1,6-8,12</translation>
    </message>
    <message>
        <source>Extract Pages</source>
        <translation>Erota sivu(t)</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>Tiedosto voi olla kirjoitussuojattu tai toisen sovelluksen käytössä.</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Kaikki sivut</translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <source>Ok</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Sivut</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation>Viimeisen sivun jälkeen</translation>
    </message>
    <message>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation>Tiedosto on suojattu. Anna asiakirjan avaus-salasana:</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation>Ennen ensimmäistä sivua</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>Tiedostonimi</translation>
    </message>
    <message>
        <source>Insert Pages</source>
        <translation>Lisää sivu(t)</translation>
    </message>
    <message>
        <source>Import Bookmarks</source>
        <translation>Tuo kirjanmerkit</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Valitse</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF-tiedostot (*.pdf)</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Sijainti</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Sivualue</translation>
    </message>
    <message>
        <source>Before page</source>
        <translation>Sivua ennen</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Salasana</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>Esim: 1,6-8,12</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Avaa tiedosto</translation>
    </message>
    <message>
        <source>Read Error: This PDF is protected.</source>
        <translation>Lukuvirhe: Tämä PDF on suojattu.</translation>
    </message>
    <message>
        <source>After page</source>
        <translation>Sivun jälkeen</translation>
    </message>
    <message>
        <source>Total pages :</source>
        <translation>Sivuja yhteensä: </translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Kaikki sivut</translation>
    </message>
</context>
<context>
    <name>QEmailDlg</name>
    <message>
        <source>To</source>
        <translation>tänne</translation>
    </message>
    <message>
        <source>Send</source>
        <translation>Lähetä</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Teksti</translation>
    </message>
    <message>
        <source>Email delivery</source>
        <translation>Sähköpostin lähetys</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Aihe</translation>
    </message>
</context>
<context>
    <name>CombineFilesDlg</name>
    <message>
        <source>Up</source>
        <translation>Ylöspäin</translation>
    </message>
    <message>
        <source>Down</source>
        <translation>Alaspäin</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Avaa</translation>
    </message>
    <message>
        <source>Save</source>
        <translation>Tallenna</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation>Viimeisen sivun jälkeen</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation>Ennen ensimmäistä sivua</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>Tiedostonimi</translation>
    </message>
    <message>
        <source>Select directory</source>
        <translation>Valitse hakemisto</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Valitse</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Add Folder</source>
        <translation>Lisää kansio</translation>
    </message>
    <message>
        <source>Save As PDF</source>
        <translation>Tallenna PDF:nä</translation>
    </message>
    <message>
        <source>Output</source>
        <translation>Ulostulo</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>nimetön</translation>
    </message>
    <message>
        <source>Add Files</source>
        <translation>Lisää tiedostot</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF-tiedostot (*.pdf)</translation>
    </message>
    <message>
        <source>Save failed</source>
        <translation>Tallennusvirhe</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Sijainti</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation>Tätä tiedostoa ei voida tallentaa:</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Sivualue</translation>
    </message>
    <message>
        <source>Append to Current Document </source>
        <translation>Lisää nykyiseen asiakirjaan</translation>
    </message>
    <message>
        <source>After current page</source>
        <translation>Nykyisen sivun jälkeen</translation>
    </message>
    <message>
        <source>Create a new document from files</source>
        <translation>Luo uusi PDF-asiakirja tiedostoista</translation>
    </message>
    <message>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Tuetut tiedostot (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>Create New Document</source>
        <translation>Luo uusi asiakirja</translation>
    </message>
    <message>
        <source>Before current page</source>
        <translation>Ennen nykyistä sivua</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Tiedosto voi olla kirjoitussuojattu tai toisen sovelluksen käytössä.</translation>
    </message>
    <message>
        <source>Total pages</source>
        <translation>Sivuja yhteensä</translation>
    </message>
</context>
<context>
    <name>DlgPageNumberDateFormat</name>
    <message>
        <source>of</source>
        <translation>tästä</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Sivu</translation>
    </message>
    <message>
        <source>Start Page Number</source>
        <translation>Aloita sivunumerointi</translation>
    </message>
    <message>
        <source>Page Number Format</source>
        <translation>Sivunumeromuoto</translation>
    </message>
    <message>
        <source>Date Format</source>
        <translation>Päiväysmuoto</translation>
    </message>
    <message>
        <source>Page Number and Date Format</source>
        <translation>Sivunumero- ja päiväysmuoto</translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <source> in</source>
        <translation> in</translation>
    </message>
    <message>
        <source> mm</source>
        <translation> mm</translation>
    </message>
    <message>
        <source> pt</source>
        <translation> pt</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>tähän:</translation>
    </message>
    <message>
        <source>Bottom margin</source>
        <translation>Alamarginaali</translation>
    </message>
    <message>
        <source>Units</source>
        <translation>Yksikkö</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Leveys</translation>
    </message>
    <message>
        <source>Millimeters</source>
        <translation>Millimetriä</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation>Parilliset sivut</translation>
    </message>
    <message>
        <source>Contents Size</source>
        <translation>Sisällön koko</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Nykyinen sivu</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation>Parilliset ja parittomat sivut</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation>Oikea marginaali</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Korkeus</translation>
    </message>
    <message>
        <source>Inches</source>
        <translation>Tuumaa</translation>
    </message>
    <message>
        <source>Points</source>
        <translation>Pistettä</translation>
    </message>
    <message>
        <source>Page Layout</source>
        <translation>Sivun asettelu</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation>Parittomat sivut</translation>
    </message>
    <message>
        <source>Top margin</source>
        <translation>Ylämarginaali</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Sivualue</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation>Vasen marginaali</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Sivut tästä</translation>
    </message>
    <message>
        <source>Page Size</source>
        <translation>Sivun koko</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Kaikki sivut</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <source>BMP</source>
        <translation>BMP</translation>
    </message>
    <message>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <source>LZW</source>
        <translation>LZW</translation>
    </message>
    <message>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>til:</translation>
    </message>
    <message>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <source>TIFF</source>
        <translation></translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Koko</translation>
    </message>
    <message>
        <source>Width</source>
        <translation>Bredde</translation>
    </message>
    <message>
        <source>TIFF Compression</source>
        <translation>TIFF Pakkaus</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>filnavn</translation>
    </message>
    <message>
        <source>MultiPage</source>
        <translation>Monisivu</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Vie</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <source>Height</source>
        <translation>Højde</translation>
    </message>
    <message>
        <source>Save As TIFF Image</source>
        <translation>Tallenna TIFF-kuvana</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>Asiakirja</translation>
    </message>
    <message>
        <source>CCITT FAX 3</source>
        <translation>CCITT FAX 3</translation>
    </message>
    <message>
        <source>CCITT FAX 4</source>
        <translation>CCITT FAX 4</translation>
    </message>
    <message>
        <source>Export to Image</source>
        <translation>Vie kuvana</translation>
    </message>
    <message>
        <source>Antialiasing</source>
        <translation>Pehmennys</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation>Tähän tiedostoon ei voida tallentaa:</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Sivualue</translation>
    </message>
    <message>
        <source>Transparent</source>
        <translation>Läpinäkyvyys</translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation>Kaikki tiedostot (*)</translation>
    </message>
    <message>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation>TIFF-tiedostot (*.tif *.tiff)</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>Tiedosto voi olla kirjoitussuojattu tai toisen sovelluksen käytössä.</translation>
    </message>
    <message>
        <source>Document and Annotations</source>
        <translation>Asiakija ja merkinnät</translation>
    </message>
    <message>
        <source>JPEG Quality</source>
        <translation>JPEG-laatu</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Selected Pages</translation>
    </message>
    <message>
        <source>Save As Image</source>
        <translation>Tallenna kuvana</translation>
    </message>
    <message>
        <source>Export:</source>
        <translation>Vie:</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Kaikki sivut</translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muokkaa</translation>
    </message>
    <message>
        <source>Zoom</source>
        <translation>Zoomaus</translation>
    </message>
    <message>
        <source>of :</source>
        <translation>Ældre Fra: :</translation>
    </message>
    <message>
        <source>Fonts</source>
        <translation>Fontit</translation>
    </message>
    <message>
        <source>Title</source>
        <translation>Otsikko</translation>
    </message>
    <message>
        <source>Fit Page</source>
        <translation>Sovita sivulle</translation>
    </message>
    <message>
        <source>Layers Panel</source>
        <translation>Tasot-paneeli</translation>
    </message>
    <message>
        <source>Manage Pages and bookmarks</source>
        <translation>Hallinnoida sivuja ja kirjanmerkkejä</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>Aja JavaScripti</translation>
    </message>
    <message>
        <source>Layout and Destination</source>
        <translation>Asettelu ja kode</translation>
    </message>
    <message>
        <source>Center window on screen</source>
        <translation>Keskitä ikkuna ruudulle</translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation>Käyttöoikeudet</translation>
    </message>
    <message>
        <source>PDF Information</source>
        <translation>PDF-tietoja</translation>
    </message>
    <message>
        <source>Fonts used in this document</source>
        <translation>Tässä asiakirjassa käytettävät fontit</translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation>Yksi sivu</translation>
    </message>
    <message>
        <source>Printing the document</source>
        <translation>Tulostaa asiakirja</translation>
    </message>
    <message>
        <source>Windows Options</source>
        <translation>Ikkuna määritykset</translation>
    </message>
    <message>
        <source>Initial View</source>
        <translation>Aloitusnäkymä</translation>
    </message>
    <message>
        <source>Bookmarks Panel</source>
        <translation>Kirjanmerkit-paneeli</translation>
    </message>
    <message>
        <source>Print a high resolution version of the document</source>
        <translation>Tulostaa korkea-resoluutioversio asiakirjasta</translation>
    </message>
    <message>
        <source>Commenting</source>
        <translation>Kommentointi</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation>Lisää toiminto</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Toiminto</translation>
    </message>
    <message>
        <source>Author</source>
        <translation>Tekijä</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Muuta</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Fill in existing form or signature fields</source>
        <translation>Täyttää lomake- tai allekirjoituskentät</translation>
    </message>
    <message>
        <source>Fit Height</source>
        <translation>Sovita korkeuteen</translation>
    </message>
    <message>
        <source>Display document title</source>
        <translation>Näytä asiakirjan otsikko</translation>
    </message>
    <message>
        <source>Pages Panel</source>
        <translation>Sivut-paneeli</translation>
    </message>
    <message>
        <source>Fit Width</source>
        <translation>Sovita leveyteen</translation>
    </message>
    <message>
        <source>Hide menu bar</source>
        <translation>Piilota valikkopalkki</translation>
    </message>
    <message>
        <source>Open to Page:</source>
        <translation>Avaa sivulle:</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>Avaa web-linkki</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation>Alkuperäinen koko</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation>Toiminnot</translation>
    </message>
    <message>
        <source>Page layout:</source>
        <translation>Sivun asettelu:</translation>
    </message>
    <message>
        <source>Document Open Actions</source>
        <translation>Asiakirjan avaustoiminnot</translation>
    </message>
    <message>
        <source>Two-Up Continuous (Facing)</source>
        <translation>Kaksi vierekkäin - jatkuva</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Salasana</translation>
    </message>
    <message>
        <source>Password Encryption</source>
        <translation>Salasanasuojaus</translation>
    </message>
    <message>
        <source>Document Properties</source>
        <translation>Asiakirjan ominaisuudet</translation>
    </message>
    <message>
        <source>Producer</source>
        <translation>Tuottaja</translation>
    </message>
    <message>
        <source>Single Page Continuous</source>
        <translation>Yksi sivu - jatkuva</translation>
    </message>
    <message>
        <source>Creator</source>
        <translation>Luoja</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Aihe</translation>
    </message>
    <message>
        <source>Default</source>
        <translation>Oletus</translation>
    </message>
    <message>
        <source>User Interface Options</source>
        <translation>Käyttäjän käyttöliittymä-asetukset</translation>
    </message>
    <message>
        <source>Navigation Tab:</source>
        <translation>Navigointi:</translation>
    </message>
    <message>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation>Asiakirja on suojattu. Anna käyttöoikeussalasana:</translation>
    </message>
    <message>
        <source>Security</source>
        <translation>Turvallisuus</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>Siirry sivulle</translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation>Nollaa lomake</translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation>Lähetä lomake</translation>
    </message>
    <message>
        <source>Hide tool bar</source>
        <translation>Piilota työkalupalkki</translation>
    </message>
    <message>
        <source>Content copying for accessibility</source>
        <translation>Sisällön kopiointi esteettömästi</translation>
    </message>
    <message>
        <source>Attachments Panel</source>
        <translation>Liitteet-paneeli</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation>Näytä/piilota kentät</translation>
    </message>
    <message>
        <source>Keywords</source>
        <translation>Avainsanat</translation>
    </message>
    <message>
        <source>No Encryption</source>
        <translation>Ei suojausta</translation>
    </message>
    <message>
        <source>Fit Visible</source>
        <translation>Sovita näkyvään</translation>
    </message>
    <message>
        <source>Page Only</source>
        <translation>Vain sivu</translation>
    </message>
    <message>
        <source>Two-Up (Cover Page)</source>
        <translation>Kansilehti + kaksi virekkäin</translation>
    </message>
    <message>
        <source>Document Info</source>
        <translation>Asiakirjan tiedot</translation>
    </message>
    <message>
        <source>Two-Up (Facing)</source>
        <translation>Kaksi vierekkäin</translation>
    </message>
    <message>
        <source>Extract the content of the document</source>
        <translation>Purkaa asiakirjan sisältö</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>Avaa/suorita tiedosto</translation>
    </message>
    <message>
        <source>Incorrect password. Please input the owner password.</source>
        <translation>Väärä salasana. Anna omistajan salasana.</translation>
    </message>
    <message>
        <source>Two-Up Continuous (Cover Page)</source>
        <translation>Kansilehti + kaksi vierekkäin - jatkuva</translation>
    </message>
    <message>
        <source>Open in Full Screen mode</source>
        <translation>Avaa koko näyttö tilassa</translation>
    </message>
    <message>
        <source>Hide Window Controls</source>
        <translation>Piilota ikkunasäätimet</translation>
    </message>
    <message>
        <source>Modifying document</source>
        <translation>Muokata asiakirjaa</translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <source>Add</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation>Lihavoitu</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muokkaa</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Teksti</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Väri</translation>
    </message>
    <message>
        <source>Plain</source>
        <translation>Tavallinen</translation>
    </message>
    <message>
        <source>Style</source>
        <translation>Tyyli</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>Aja JavaScripti</translation>
    </message>
    <message>
        <source>Italic &amp; Bold</source>
        <translation>Kursivoitu ja lihavoitu</translation>
    </message>
    <message>
        <source>Set current position</source>
        <translation>Aseta tämä sijainti</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation>Lisää tapahtuma</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Tapahtuma</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Custom</source>
        <translation>Mukauta</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation>Kursivoitu</translation>
    </message>
    <message>
        <source>Page Number</source>
        <translation>Sivunumero</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>nimetön</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation>Hiiren painike ylös</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>Avaa web-linkki</translation>
    </message>
    <message>
        <source>Bookmark Properties</source>
        <translation>Kirjanmerkin ominaisuudet</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation>Toiminnot</translation>
    </message>
    <message>
        <source>Do you want to set the current position?</source>
        <translation>Haluatko asettaa tämänhetkisen sijainnin?</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Ulkomuoto</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation>Toiminto</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>Siirry sivulle</translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation>Nollaa lomake</translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation>Lähetä lomake</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation>Näytä/Piilota kentät</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>Avaa/suorita tiedosto</translation>
    </message>
</context>
<context>
    <name>JavaScriptDocumentDlg</name>
    <message>
        <source>Add</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muokkaa</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Document JavaScript</source>
        <translation>Asiakirjan JavaScriptit</translation>
    </message>
    <message>
        <source>Function Name</source>
        <translation>Funktion nimi</translation>
    </message>
</context>
<context>
    <name>PagePropertiesDlg</name>
    <message>
        <source>Add</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muokkaa</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>Aja JavaScripti</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Nykyinen sivu</translation>
    </message>
    <message>
        <source>Add an Action</source>
        <translation>Lisää tapahtuma</translation>
    </message>
    <message>
        <source>Tab Order</source>
        <translation>Välilehtijärjestys</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Tapahtuma</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Use Column Order</source>
        <translation>Käytä sarakejärjestystä</translation>
    </message>
    <message>
        <source>Use Row Order</source>
        <translation>Käytä rivijärjestystä</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>Avaa web-linkki</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation>Tapahtumat</translation>
    </message>
    <message>
        <source>Use Document Structure</source>
        <translation>Käytä asiakirjarakennetta</translation>
    </message>
    <message>
        <source>Close Page</source>
        <translation>Sulje sivu</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation>Toiminto</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation>Sivun ominaisuudet</translation>
    </message>
    <message>
        <source>Unspecified</source>
        <translation>Määrittelemätön</translation>
    </message>
    <message>
        <source>Open Page</source>
        <translation>Avaa sivu</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>Siirry sivulle</translation>
    </message>
    <message>
        <source>Reset form</source>
        <translation>Nollaa lomake</translation>
    </message>
    <message>
        <source>Submit a form</source>
        <translation>Lähetä lomake</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation>Näytä/Piilota kentät</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>Avaa/suorita tiedosto</translation>
    </message>
</context>
<context>
    <name>StampManageDlg</name>
    <message>
        <source>Add</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>Muokkaa</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Stamps</source>
        <translation>Leimat</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Esikatselu</translation>
    </message>
    <message>
        <source>Custom Stamps</source>
        <translation>Mukautettu leima</translation>
    </message>
</context>
<context>
    <name>ObjectTreeView</name>
    <message>
        <source>All</source>
        <translation>Kaikki</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Sivu</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Näytä</translation>
    </message>
    <message>
        <source>Links</source>
        <translation>Linkit</translation>
    </message>
    <message>
        <source>Paths</source>
        <translation>Polut</translation>
    </message>
    <message>
        <source>Combo Boxes</source>
        <translation>Valikko</translation>
    </message>
    <message>
        <source>Radio Buttons</source>
        <translation>Valintapainike</translation>
    </message>
    <message>
        <source>Collapse All</source>
        <translation>Supista kaikki</translation>
    </message>
    <message>
        <source>Signatures</source>
        <translation>Allekirjoitukset</translation>
    </message>
    <message>
        <source>Text Fields</source>
        <translation>Tekstikentät</translation>
    </message>
    <message>
        <source>Images</source>
        <translation>Kuvat</translation>
    </message>
    <message>
        <source>List Boxes</source>
        <translation>Lista</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>Object TreeView</source>
        <translation>Objektien ipuunäkymä</translation>
    </message>
    <message>
        <source>Expand All</source>
        <translation>Laajenna kaikki</translation>
    </message>
    <message>
        <source>Buttons</source>
        <translation>Painikkeet</translation>
    </message>
    <message>
        <source>Containers</source>
        <translation>Säiliöt</translation>
    </message>
    <message>
        <source>Check Boxes</source>
        <translation>Valintaruutu</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Kaikki sivut</translation>
    </message>
    <message>
        <source>Shadings</source>
        <translation>Varjostukset</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <source>All</source>
        <translation>Kaikki</translation>
    </message>
    <message>
        <source>of </source>
        <translation>tästä </translation>
    </message>
    <message>
        <source>of:</source>
        <translation>tästä:</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>tähän:</translation>
    </message>
    <message>
        <source>Auto</source>
        <translation>Automaattinen</translation>
    </message>
    <message>
        <source>None</source>
        <translation>Ei mitään</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Sivu</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Sivut</translation>
    </message>
    <message>
        <source>Print</source>
        <translation>Tulosta</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation>Parilliset sivut</translation>
    </message>
    <message>
        <source>Keep aspect ratio</source>
        <translation>Pidä kuvasuhde</translation>
    </message>
    <message>
        <source>Paper Size: </source>
        <translation>Paperin koko: </translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Nykyinen sivu</translation>
    </message>
    <message>
        <source>Aspect Ratio</source>
        <translation>Kuvasuhde</translation>
    </message>
    <message>
        <source>All pages in range</source>
        <translation>Kaikki sivut alueella</translation>
    </message>
    <message>
        <source>Long side</source>
        <translation>Pitkäsivu</translation>
    </message>
    <message>
        <source>Center</source>
        <translation>Keskitä</translation>
    </message>
    <message>
        <source>Landscape</source>
        <translation>Vaaka</translation>
    </message>
    <message>
        <source>Print:</source>
        <translation>Tulosta:</translation>
    </message>
    <message>
        <source>Subset</source>
        <translation>Määrätyt</translation>
    </message>
    <message>
        <source>Document</source>
        <translation>Asiakirja</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation>Suunta</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation>Parittomat sivut</translation>
    </message>
    <message>
        <source>Portrait</source>
        <translation>Pysty</translation>
    </message>
    <message>
        <source>Properties</source>
        <translation>Ominaisuudet</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Sivualue</translation>
    </message>
    <message>
        <source>Printer</source>
        <translation>Tulostin</translation>
    </message>
    <message>
        <source>Actual Size</source>
        <translation>Todellinen koko</translation>
    </message>
    <message>
        <source>Short side</source>
        <translation>Lyhytsivu</translation>
    </message>
    <message>
        <source>Collate</source>
        <translation>Lajittele</translation>
    </message>
    <message>
        <source>Keep aspect ratio by expanding</source>
        <translation>Sovita sivulle kuvasuhteella</translation>
    </message>
    <message>
        <source>Document and Annotations</source>
        <translation>Asiakirja ja merkinnät</translation>
    </message>
    <message>
        <source>Print as Image</source>
        <translation>Tulosta kuvana</translation>
    </message>
    <message>
        <source>Print as Grayscale</source>
        <translation>Tulosta harmaasävynä</translation>
    </message>
    <message>
        <source>Number of copies</source>
        <translation>Kopioiden määrä</translation>
    </message>
    <message>
        <source>Ignore aspect ratio</source>
        <translation>Ei kuvasuhdetta</translation>
    </message>
    <message>
        <source>Duplex Printing</source>
        <translation>Kaksoistulostus</translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <source>JBIG2</source>
        <translation>JBIG2</translation>
    </message>
    <message>
        <source>Save Optimized As...</source>
        <translation>Tallenna optimoidut nimellä...</translation>
    </message>
    <message>
        <source>Color and Grayscale Images</source>
        <translation>Väri- ja harmaasävykuvat</translation>
    </message>
    <message>
        <source>Lossless</source>
        <translation>Häviötön</translation>
    </message>
    <message>
        <source>Compression</source>
        <translation>Pakkaus</translation>
    </message>
    <message>
        <source>Remove unused elements</source>
        <translation>Poista käyttämättömät elementit</translation>
    </message>
    <message>
        <source>Black and White Images</source>
        <translation>Musta/valkokuvat</translation>
    </message>
    <message>
        <source>CCITT Group 4</source>
        <translation>CCITT Ryhmä 4</translation>
    </message>
    <message>
        <source>Flatten form fields</source>
        <translation>Tasaa lomakekentät</translation>
    </message>
    <message>
        <source>JPEG Quality</source>
        <translation>JPEG-laatu</translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <source>FDF</source>
        <translation>FDF</translation>
    </message>
    <message>
        <source>FTP</source>
        <translation>FTP</translation>
    </message>
    <message>
        <source>PDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Hide</source>
        <translation>Piilota</translation>
    </message>
    <message>
        <source>Show</source>
        <translation>Näytä</translation>
    </message>
    <message>
        <source>XFDF</source>
        <translation>XFDF</translation>
    </message>
    <message>
        <source>Need user name and password</source>
        <translation>Vaaditaan käyttäjä nimi ja salasana</translation>
    </message>
    <message>
        <source>Select Field</source>
        <translation>Valitut tiedostot</translation>
    </message>
    <message>
        <source>Action</source>
        <translation>Toiminto</translation>
    </message>
    <message>
        <source>E-mail</source>
        <translation>Sähköposti</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Valitse</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Muoto</translation>
    </message>
    <message>
        <source>Method</source>
        <translation>Menetelmä</translation>
    </message>
    <message>
        <source>Local file</source>
        <translation>Paikallinen tiedosto</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Salasana</translation>
    </message>
    <message>
        <source>Java script editor</source>
        <translation>JavaScript-editori</translation>
    </message>
    <message>
        <source>Use anonymous</source>
        <translation>Käytä nimettömänä</translation>
    </message>
    <message>
        <source>All Files (*.*)</source>
        <translation>Kaikki tiedostot (*.*)</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Valitse kaikki</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Avaa tiedosto</translation>
    </message>
    <message>
        <source>User name</source>
        <translation>Käyttäjänimi</translation>
    </message>
    <message>
        <source>Reset Form</source>
        <translation>Nollaa lomake</translation>
    </message>
    <message>
        <source>Select Fields</source>
        <translation>Valitut tiedostot</translation>
    </message>
    <message>
        <source>Show/Hide Fields</source>
        <translation>Näytä/piilota tiedostot</translation>
    </message>
    <message>
        <source>Deselect All</source>
        <translation>Älä valitse mitään</translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <source>Cut</source>
        <translation>Leikkaa</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopioi</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Liitä</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>Aja JavaScripti</translation>
    </message>
    <message>
        <source>Highlight Text</source>
        <translation>Korostettu teksti</translation>
    </message>
    <message>
        <source>Underline Text</source>
        <translation>Alleviivattu teksti</translation>
    </message>
    <message>
        <source>Add Bookmark</source>
        <translation>Lisää kirjanmerkki</translation>
    </message>
    <message>
        <source>Add Sticky Note</source>
        <translation>Lisää muistilappu</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>Avaa web-linkki</translation>
    </message>
    <message>
        <source>Strikeout Text</source>
        <translation>Yliviivattu teksti</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Valitse kaikki</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Avaa tiedosto</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>Siirry sivulle</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>Avaa/suorita tiedosto</translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <source>Cut</source>
        <translation>Leikkaa</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopioi</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <source>Open Image</source>
        <translation>Avaa kuva</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Liitä</translation>
    </message>
    <message>
        <source>Edit text</source>
        <translation>Muokkaa tekstiä</translation>
    </message>
    <message>
        <source>ERROR Loading Image !</source>
        <translation>VIRHE ladattaessa kuvaa !</translation>
    </message>
    <message>
        <source>Save Image to file</source>
        <translation>Tallenna kuva tiedostoon</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation>Kuvatiedostot (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation>Tallenna nimellä...</translation>
    </message>
    <message>
        <source>Select All</source>
        <translation>Valitse kaikki</translation>
    </message>
    <message>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation>PNG-kuvat (*.png);;BMP Images (*.bmp)</translation>
    </message>
    <message>
        <source>PNG Images (*.png)</source>
        <translation>PNG-kuvat (*.png)</translation>
    </message>
    <message>
        <source>Set Fit to Page</source>
        <translation>Sovita sivulle</translation>
    </message>
    <message>
        <source>Signature options</source>
        <translation>Allekirjoituksen määritykset</translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <source>MD5</source>
        <translation>MD5</translation>
    </message>
    <message>
        <source>Data</source>
        <translation>Data</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Tietoja</translation>
    </message>
    <message>
        <source>Email</source>
        <translation>Sähköposti</translation>
    </message>
    <message>
        <source>Organizational Unit (OU)</source>
        <translation>Organisaatioyksikkö (OU)</translation>
    </message>
    <message>
        <source>Not Before</source>
        <translation>Ei aikaisemmin</translation>
    </message>
    <message>
        <source>Issuer</source>
        <translation>Lähettäjä</translation>
    </message>
    <message>
        <source>SHA-1:</source>
        <translation>SHA-1:</translation>
    </message>
    <message>
        <source>Not After</source>
        <translation>Ei myöhemmin</translation>
    </message>
    <message>
        <source>Common Name (CN)</source>
        <translation>Common Name (CN) (palvelun nimi)</translation>
    </message>
    <message>
        <source>Organization (O)</source>
        <translation>Organisaatio (O)</translation>
    </message>
    <message>
        <source>Validity</source>
        <translation>Voimassaolo</translation>
    </message>
    <message>
        <source>Subject</source>
        <translation>Aihe</translation>
    </message>
    <message>
        <source>Add to Trusted Identities</source>
        <translation>Lisää luotettuihin identiteetteihin</translation>
    </message>
    <message>
        <source>Algorithm</source>
        <translation>Algoritmi</translation>
    </message>
    <message>
        <source>Serial Number</source>
        <translation>Sarjanumero</translation>
    </message>
</context>
<context>
    <name>OCRExe</name>
    <message>
        <source>OCR</source>
        <translation>Optinen tekstin lukija (OCR)</translation>
    </message>
    <message>
        <source>Are you sure you want to stop document recognition?</source>
        <translation>Haluatko varmasti lopettaa asiakirjan tunnistuksen?</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <source>Red</source>
        <translation>Punainen</translation>
    </message>
    <message>
        <source>Blue</source>
        <translation>Sininen</translation>
    </message>
    <message>
        <source>Cyan</source>
        <translation>Syaani</translation>
    </message>
    <message>
        <source>Gray</source>
        <translation>Harmaa</translation>
    </message>
    <message>
        <source>Black</source>
        <translation>Musta</translation>
    </message>
    <message>
        <source>Green</source>
        <translation>Vihreä</translation>
    </message>
    <message>
        <source>White</source>
        <translation>Valkoinen</translation>
    </message>
    <message>
        <source>Magenta</source>
        <translation>Purppura</translation>
    </message>
    <message>
        <source>More...</source>
        <translation>LIsää...</translation>
    </message>
    <message>
        <source>Yellow</source>
        <translation>Keltainen</translation>
    </message>
    <message>
        <source>Dark yellow</source>
        <translation>Tummankeltainen</translation>
    </message>
    <message>
        <source>Dark magenta</source>
        <translation>Tumma purppura</translation>
    </message>
    <message>
        <source>Dark red</source>
        <translation>Tummanpunainen</translation>
    </message>
    <message>
        <source>Dark gray</source>
        <translation>Tummanharmaa</translation>
    </message>
    <message>
        <source>Dark blue</source>
        <translation>Tummansininen</translation>
    </message>
    <message>
        <source>Dark cyan</source>
        <translation>Tumma syaani</translation>
    </message>
    <message>
        <source>Transparent</source>
        <translation>Läpinäkyvä</translation>
    </message>
    <message>
        <source>User Color 99</source>
        <translation>Käyttäjän väri 99</translation>
    </message>
    <message>
        <source>Dark green</source>
        <translation>Tummanvihreä</translation>
    </message>
    <message>
        <source>Light gray</source>
        <translation>Vaaleanharmaa</translation>
    </message>
</context>
<context>
    <name>JavaScriptConsoleDlg</name>
    <message>
        <source>Run</source>
        <translation>Aja</translation>
    </message>
    <message>
        <source>Clear</source>
        <translation>Tyhjennä</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <source>Stays On Top</source>
        <translation>Pidä päällimmäisenä</translation>
    </message>
    <message>
        <source>JavaScript Console</source>
        <translation>JavaScript-konsoli</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Set</source>
        <translation>Aseta</translation>
    </message>
    <message>
        <source>Icon</source>
        <translation>Kuvake</translation>
    </message>
    <message>
        <source>Info</source>
        <translation>Infoa</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Polku</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Teksti</translation>
    </message>
    <message>
        <source>Void</source>
        <translation>Mitätön</translation>
    </message>
    <message>
        <source>Submit Form</source>
        <translation>Lähetä lomake</translation>
    </message>
    <message>
        <source>Build</source>
        <translation>Build</translation>
    </message>
    <message>
        <source>Draft</source>
        <translation>Luonnos</translation>
    </message>
    <message>
        <source>Final</source>
        <translation>Lopullinen</translation>
    </message>
    <message>
        <source>Forms</source>
        <translation>Lomakkeet</translation>
    </message>
    <message>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <source>Image</source>
        <translation>Kuva</translation>
    </message>
    <message>
        <source>Initial</source>
        <translation>Alkuperäinen</translation>
    </message>
    <message>
        <source>Movie</source>
        <translation>Elokuva</translation>
    </message>
    <message>
        <source>Reply</source>
        <translation>Vastaa</translation>
    </message>
    <message>
        <source>Reset</source>
        <translation>Nollaa</translation>
    </message>
    <message>
        <source>Sound</source>
        <translation>Ääni</translation>
    </message>
    <message>
        <source>h:MM tt mmmm dd.yyyy</source>
        <translation>h:MM tt mmmm dd.yyyy</translation>
    </message>
    <message>
        <source>Run a JavaScript</source>
        <translation>Aja JavaScripti</translation>
    </message>
    <message>
        <source>You are not allowed to use this function in the free version</source>
        <translation>Tämä toiminto ei ole sallittu ilmaisversiossa</translation>
    </message>
    <message>
        <source>On Lose Focus</source>
        <translation>Vähennä tarkennusta</translation>
    </message>
    <message>
        <source>Calculate</source>
        <translation>Laske</translation>
    </message>
    <message>
        <source>Sticky Note</source>
        <translation>Muistilappu</translation>
    </message>
    <message>
        <source>32 bit</source>
        <translation>32 bit</translation>
    </message>
    <message>
        <source>Goto 3D View</source>
        <translation>Siirry 3D-näkymään</translation>
    </message>
    <message>
        <source>64 bit</source>
        <translation>64 bit</translation>
    </message>
    <message>
        <source>Document Saved</source>
        <translation>Asiakirjan tallennus</translation>
    </message>
    <message>
        <source>Completed</source>
        <translation>Valmistunut</translation>
    </message>
    <message>
        <source>Rendition</source>
        <translation>Esitys</translation>
    </message>
    <message>
        <source>Error.</source>
        <translation>Virhe.</translation>
    </message>
    <message>
        <source>Format</source>
        <translation>Muoto</translation>
    </message>
    <message>
        <source>Object</source>
        <translation>Objekti</translation>
    </message>
    <message>
        <source>Objects</source>
        <translation>Objektit</translation>
    </message>
    <message>
        <source>Container</source>
        <translation>Säiliö</translation>
    </message>
    <message>
        <source>Thread</source>
        <translation>Säie</translation>
    </message>
    <message>
        <source>All Objects</source>
        <translation>Kaikki objektit</translation>
    </message>
    <message>
        <source>FDF Files (*.fdf)</source>
        <translation>FDF-tiedostot (*.fdf)</translation>
    </message>
    <message>
        <source>Comments</source>
        <translation>Kommentit</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation>Kontrasti</translation>
    </message>
    <message>
        <source>Close Document</source>
        <translation>Sulje asiakirja</translation>
    </message>
    <message>
        <source>Mouse Up</source>
        <translation>Hiiren painike ylös</translation>
    </message>
    <message>
        <source>Mouse Enter</source>
        <translation>Hiiri päälle</translation>
    </message>
    <message>
        <source>Open a web link</source>
        <translation>Avaa web-linkki</translation>
    </message>
    <message>
        <source>Page Close</source>
        <translation>Sivun sulkeminen</translation>
    </message>
    <message>
        <source>Approved</source>
        <translation>Hyväksytty</translation>
    </message>
    <message>
        <source>Validate</source>
        <translation>Vahvista</translation>
    </message>
    <message>
        <source>Based on</source>
        <translation>Based on</translation>
    </message>
    <message>
        <source>Revised</source>
        <translation>Tarkastettu</translation>
    </message>
    <message>
        <source>StrikeOut</source>
        <translation>Yliviivaus</translation>
    </message>
    <message>
        <source>Import Data</source>
        <translation>Tuo Data</translation>
    </message>
    <message>
        <source>Mouse Exit</source>
        <translation>Hiiri pois päältä</translation>
    </message>
    <message>
        <source>Close Page</source>
        <translation>Sulje sivu</translation>
    </message>
    <message>
        <source>Mouse Down</source>
        <translation>Hiiren painike alas</translation>
    </message>
    <message>
        <source>Accepted</source>
        <translation>Hyväksytty</translation>
    </message>
    <message>
        <source>Shading</source>
        <translation>Varjostus</translation>
    </message>
    <message>
        <source>Page Visible</source>
        <translation>Sivu näkyy</translation>
    </message>
    <message>
        <source>Standard</source>
        <translation>Standardi</translation>
    </message>
    <message>
        <source>Underline</source>
        <translation>Alleviivaus</translation>
    </message>
    <message>
        <source>Received</source>
        <translation>Otettu vastaan</translation>
    </message>
    <message>
        <source>Document Printed</source>
        <translation>Asiakirja tulostettu</translation>
    </message>
    <message>
        <source>Dynamic</source>
        <translation>Dynaaminen</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Avaa tiedosto</translation>
    </message>
    <message>
        <source>Open Page</source>
        <translation>Avaa sivu</translation>
    </message>
    <message>
        <source>Open with</source>
        <translation>Avaa tällä</translation>
    </message>
    <message>
        <source>Rejected</source>
        <translation>Hylätty</translation>
    </message>
    <message>
        <source>Goto a Page View</source>
        <translation>Siirry sivulle</translation>
    </message>
    <message>
        <source>The unregistered version will insert a watermark</source>
        <translation>Rekisteröimätön versio lisää vesileiman</translation>
    </message>
    <message>
        <source>Save Document</source>
        <translation>Avaa asiakirja</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Tuntematon</translation>
    </message>
    <message>
        <source>Reset Form</source>
        <translation>Nollaa lomake</translation>
    </message>
    <message>
        <source>Emergency</source>
        <translation>Kiireellinen</translation>
    </message>
    <message>
        <source>Verified</source>
        <translation>Varmistettu</translation>
    </message>
    <message>
        <source>Print Document</source>
        <translation>Tulosta asiakirja</translation>
    </message>
    <message>
        <source>Reviewed</source>
        <translation>Arvosteltu</translation>
    </message>
    <message>
        <source>Page Invisible</source>
        <translation>Sivu on näkymätön</translation>
    </message>
    <message>
        <source>Typewriter</source>
        <translation>Kirjoituskone</translation>
    </message>
    <message>
        <source>Show/Hide fields</source>
        <translation>Näytä/piilota kentät</translation>
    </message>
    <message>
        <source>Text Box</source>
        <translation>Tekstiruutu</translation>
    </message>
    <message>
        <source>Expired</source>
        <translation>Vanhentunut</translation>
    </message>
    <message>
        <source>Page Open</source>
        <translation>Sivun avaaminen</translation>
    </message>
    <message>
        <source>Highlight</source>
        <translation>Korostus</translation>
    </message>
    <message>
        <source>Formatted Text</source>
        <translation>Muotoiltu teksti</translation>
    </message>
    <message>
        <source>Brightness</source>
        <translation>Kirkkaus</translation>
    </message>
    <message>
        <source>Witness</source>
        <translation>Todiste</translation>
    </message>
    <message>
        <source>Confidential</source>
        <translation>Luottamuksellinen</translation>
    </message>
    <message>
        <source>KeyStroke</source>
        <translation>Näppäily</translation>
    </message>
    <message>
        <source>Open/execute a File</source>
        <translation>Avaa/suorita tiedosto</translation>
    </message>
    <message>
        <source>Press Help button to get more info.</source>
        <translation>Saadaksesi lisätietoa klikkaa Ohje-painiketta.</translation>
    </message>
    <message>
        <source>SignHere</source>
        <translation>Allekirjoita tähän</translation>
    </message>
    <message>
        <source>On Receive Focus</source>
        <translation>Tarkenna</translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <source>To:</source>
        <translation>Tähän:</translation>
    </message>
    <message>
        <source>to:</source>
        <translation>tähän:</translation>
    </message>
    <message>
        <source>Destination</source>
        <translation>Siirrettyjen sivujen paikka</translation>
    </message>
    <message>
        <source>Last</source>
        <translation>Viimeiseksi</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Sivu</translation>
    </message>
    <message>
        <source>First</source>
        <translation>Ensimmäiseksi</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Sivut</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Nykyinen sivu</translation>
    </message>
    <message>
        <source>Move Pages</source>
        <translation>Siirrä sivu(t)</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Sivualue</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>Esim: 1,6-8,12</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Sivut tästä</translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <source>to:</source>
        <translation>tähän:</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Sivut</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Nykyinen sivu</translation>
    </message>
    <message>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation>Poistettuja sivuja ei voi palauttaa kumoa-toiminnolla.</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Sivualue</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>Esim: 1,6-8,12</translation>
    </message>
    <message>
        <source>Delete Page(s)</source>
        <translation>Poista sivu(t)</translation>
    </message>
    <message>
        <source>Pages from</source>
        <translation>Sivut tästä</translation>
    </message>
</context>
<context>
    <name>ActionDocummentDlg</name>
    <message>
        <source>Edit</source>
        <translation>Muokkaa</translation>
    </message>
    <message>
        <source>Document Will Print</source>
        <translation>Asiakirja tulostetaan</translation>
    </message>
    <message>
        <source>Document Will Close</source>
        <translation>Asiakirja suljetaan</translation>
    </message>
    <message>
        <source>Document Will Save</source>
        <translation>Asiakirja tallennetaan</translation>
    </message>
    <message>
        <source>Java Script</source>
        <translation>JavaScriptit</translation>
    </message>
    <message>
        <source>Document Did Print</source>
        <translation>Asiakirja tulostettiin</translation>
    </message>
    <message>
        <source>Actions</source>
        <translation>Tapahtumat</translation>
    </message>
    <message>
        <source>Document Did Save</source>
        <translation>Asiakirja tallennettiin</translation>
    </message>
    <message>
        <source>Document Actions</source>
        <translation>Asiakirjan tapahtumat</translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <source>Form</source>
        <translation>Lomake</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Asetukset</translation>
    </message>
</context>
<context>
    <name>ScannerDialog</name>
    <message>
        <source>Mode</source>
        <translation>Tila</translation>
    </message>
    <message>
        <source>Scan</source>
        <translation>Skannaa</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>Väri</translation>
    </message>
    <message>
        <source>Input</source>
        <translation>Syötte (input)</translation>
    </message>
    <message>
        <source>Scan:</source>
        <translation>Skannaa:</translation>
    </message>
    <message>
        <source>After last page</source>
        <translation>Viimeisen sivun jälkeen</translation>
    </message>
    <message>
        <source>Single Page</source>
        <translation>Yksi sivu</translation>
    </message>
    <message>
        <source>Before first page</source>
        <translation>Ennen ensimmäistä sivua</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Valitse</translation>
    </message>
    <message>
        <source>Save As PDF</source>
        <translation>Tallenna PDF-tiedostona</translation>
    </message>
    <message>
        <source>Output</source>
        <translation>Ulostulo</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Lataa uudelleen</translation>
    </message>
    <message>
        <source>Looking for devices. Please wait.</source>
        <translation>Etsitään laitteita. Odota.</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>nimetön</translation>
    </message>
    <message>
        <source>Resolution</source>
        <translation>Resoluutio</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>PDF Files (*.pdf)</source>
        <translation>PDF-tiedostot (*.pdf)</translation>
    </message>
    <message>
        <source>Position</source>
        <translation>Sijainti</translation>
    </message>
    <message>
        <source>Append to Current Document </source>
        <translation>Lisää nykyiseen asiakirjaan</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Esikatselu</translation>
    </message>
    <message>
        <source>After current page</source>
        <translation>Nykyisen sivun jälkeen</translation>
    </message>
    <message>
        <source>Positive Transparency</source>
        <translation>Positiivinen läpinäkyvyys</translation>
    </message>
    <message>
        <source>Scanner</source>
        <translation>Skanneri</translation>
    </message>
    <message>
        <source>Create New Document</source>
        <translation>Luo uusi asiakirja</translation>
    </message>
    <message>
        <source>Before current page</source>
        <translation>Ennen nykyistä sivua</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>Flatbed</source>
        <translation>Tasoskanneri</translation>
    </message>
    <message>
        <source>Document Feeder</source>
        <translation>Syöttölaite</translation>
    </message>
    <message>
        <source>Negative Transparency</source>
        <translation>Negatiivinen läpinäkyvyys</translation>
    </message>
    <message>
        <source>All Pages From Feeder</source>
        <translation>Kaikki sivut syötteestä</translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Avaa</translation>
    </message>
    <message>
        <source>Page</source>
        <translation>Sivu</translation>
    </message>
    <message>
        <source>Size</source>
        <translation>Koko</translation>
    </message>
    <message>
        <source>Attachment Tab</source>
        <translation>Liite-välilehti</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <source>Insert</source>
        <translation>Lisää</translation>
    </message>
    <message>
        <source>Location</source>
        <translation>Sijainti</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation>Tallenna nimellä...</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>Liite</translation>
    </message>
    <message>
        <source>Description</source>
        <translation>Selitys</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Avaa tiedosto</translation>
    </message>
</context>
<context>
    <name>StampSettingsDlg</name>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>Teksti</translation>
    </message>
    <message>
        <source>Edit Stamp</source>
        <translation>Muokkaa leimaa</translation>
    </message>
    <message>
        <source>Template</source>
        <translation>Mallipohja</translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <source>Save</source>
        <translation>Tallenna</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <source>Move to New Window</source>
        <translation>Siirrä uuteen ikkunaan</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>nimetön</translation>
    </message>
    <message>
        <source>Close All</source>
        <translation>Sulje kaikki</translation>
    </message>
    <message>
        <source>Save As...</source>
        <translation>Tallenna nimellä...</translation>
    </message>
    <message>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation>Leikepöytä ei sisällä dataa</translation>
    </message>
</context>
<context>
    <name>ManuallyTextOCRDlg</name>
    <message>
        <source>Text</source>
        <translation>Teksti</translation>
    </message>
    <message>
        <source>Recognized text</source>
        <translation>Tunnista teksti</translation>
    </message>
    <message>
        <source>Not Text</source>
        <translation>Ei tekstiä</translation>
    </message>
    <message>
        <source>Original</source>
        <translation>Alkuperäinen</translation>
    </message>
</context>
<context>
    <name>OCRDialog</name>
    <message>
        <source>auto</source>
        <translation>automaattinen</translation>
    </message>
    <message>
        <source>Pages</source>
        <translation>Sivut</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Nykyinen sivu</translation>
    </message>
    <message>
        <source>Font Family</source>
        <translation>Fonttityyppi</translation>
    </message>
    <message>
        <source>OCR Engine</source>
        <translation>OCR-laite</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>Kielet</translation>
    </message>
    <message>
        <source>Manually edit all recognized text</source>
        <translation>Muokkaa manuaalisesti kaikkia tunnistettuja tekstejä</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Sivualue</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>Esim: 1,6-8,12</translation>
    </message>
    <message>
        <source>Editable Text</source>
        <translation>Muokattava teksti</translation>
    </message>
    <message>
        <source>Searchable Text</source>
        <translation>Etsittävä teksti</translation>
    </message>
    <message>
        <source>Selected</source>
        <translation>Valitut</translation>
    </message>
    <message>
        <source>Install languages</source>
        <translation>Asenna kielet</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Kaikki sivut</translation>
    </message>
</context>
<context>
    <name>DlgIconPlacement</name>
    <message>
        <source>Never</source>
        <translation>Ei koskaan</translation>
    </message>
    <message>
        <source>Non-Proportionally</source>
        <translation>Ei suhdetta</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Aina</translation>
    </message>
    <message>
        <source>Button</source>
        <translation>Painike</translation>
    </message>
    <message>
        <source>Scale:</source>
        <translation>Skaalaa:</translation>
    </message>
    <message>
        <source>Icon is too small</source>
        <translation>Kuvake on liian pieni</translation>
    </message>
    <message>
        <source>Proportionally</source>
        <translation>Suhteellisesti</translation>
    </message>
    <message>
        <source>Use this dialog to change the way the icon is scaled to fit inside the button</source>
        <translation>Käytä tätä valintaikkunaa vaihtaaksesi tapaa, jolla kuvake skaalataan painikkeen sisällä</translation>
    </message>
    <message>
        <source>When to scale:</source>
        <translation>Kun skaalataan:</translation>
    </message>
    <message>
        <source>Fit to bounds</source>
        <translation>Sovita rajoihin</translation>
    </message>
    <message>
        <source>Icon is too big</source>
        <translation>Kuvake on liian suuri</translation>
    </message>
    <message>
        <source>Icon Placement</source>
        <translation>Kuvakkeen sijoittaminen</translation>
    </message>
</context>
<context>
    <name>DlgPageRange</name>
    <message>
        <source>Pages</source>
        <translation>Sivut</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation>Parilliset sivut</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation>Parilliset ja parittomat sivut</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation>Parittomat sivut</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Sivualue</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>Esim: 1,6-8,12</translation>
    </message>
    <message>
        <source>Page Range Options</source>
        <translation>Sivualue-asetukset</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Kaikki sivut</translation>
    </message>
</context>
<context>
    <name>ExportTextDialog</name>
    <message>
        <source>Pages</source>
        <translation>Sivut</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Nykyinen sivu</translation>
    </message>
    <message>
        <source>File Name</source>
        <translation>Tiedostonimi</translation>
    </message>
    <message>
        <source>Extract pages as a single file</source>
        <translation>Erota sivut ja tallenna yhdeksi tiedostoksi</translation>
    </message>
    <message>
        <source>Browse</source>
        <translation>Valitse</translation>
    </message>
    <message>
        <source>Export</source>
        <translation>Vie</translation>
    </message>
    <message>
        <source>Export to text</source>
        <translation>Vie tekstinä</translation>
    </message>
    <message>
        <source>txt files (*.txt)</source>
        <translation>txt-tiedostot (*.txt)</translation>
    </message>
    <message>
        <source>Can&apos;t save to the file:</source>
        <translation>Tätä tiedostoa ei voi tallentaa:</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Sivualue</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>Esim: 1,6-8,12</translation>
    </message>
    <message>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Tiedosto voi olla kirjoitussuojattu tai toisen sovelluksen käytössä.</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Kaikki sivut</translation>
    </message>
</context>
<context>
    <name>PasteDialog</name>
    <message>
        <source>Pages</source>
        <translation>Sivut</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Sivualue</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>Esim: 1,6-8,12</translation>
    </message>
    <message>
        <source>Paste to multiple pages</source>
        <translation>Liitä monisivuasiakirjaan</translation>
    </message>
    <message>
        <source>Except current one</source>
        <translation>Paitsi nykyinen sivu</translation>
    </message>
    <message>
        <source>All pages</source>
        <translation>Kaikki sivut</translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <source>Pages</source>
        <translation>Sivut</translation>
    </message>
    <message>
        <source>Object Inspector</source>
        <translation>Objektin ominaisuudet (Odject Inspector)</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Käännä 90 astetta vastapäivään</translation>
    </message>
    <message>
        <source>Delete Pages</source>
        <translation>Poista sivuja</translation>
    </message>
    <message>
        <source>Change</source>
        <translation>Muuta</translation>
    </message>
    <message>
        <source>Error!</source>
        <translation>Virhe!</translation>
    </message>
    <message>
        <source>Reduce Page Thumbnails</source>
        <translation>Pienennä sivun esikatselukuvat</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Etsi</translation>
    </message>
    <message>
        <source>untitled</source>
        <translation>nimetön</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>Kirjanmerkit</translation>
    </message>
    <message>
        <source>Enlarge Page Thumbnails</source>
        <translation>Suurenna sivun esikatselukuvat</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Käännä 90 astetta myötäpäivään</translation>
    </message>
    <message>
        <source>Attachment</source>
        <translation>Liitteet</translation>
    </message>
    <message>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation>Asiakirja on suojattu. sinulla ei ole oikeuksia muokata sitä</translation>
    </message>
    <message>
        <source>Object TreeView</source>
        <translation>Objektin puunäkymä</translation>
    </message>
    <message>
        <source>This document contains interactive form fields</source>
        <translation>Tämä asiakirja sisältää interaktiivisia lomakekenttiä</translation>
    </message>
    <message>
        <source>Error loading font: </source>
        <translation>Virhe ladattaessa fonttia: </translation>
    </message>
    <message>
        <source>There was an error printing the document</source>
        <translation>Asiakirjan tulostuksessa taphtui virhe</translation>
    </message>
    <message>
        <source>Page Properties</source>
        <translation>Sivun ominaisuudet</translation>
    </message>
    <message>
        <source>Highlight Fields</source>
        <translation>Korosta kentät</translation>
    </message>
    <message>
        <source>Do you want to open?</source>
        <translation>Haluatko avata?</translation>
    </message>
    <message>
        <source>Insert Blank Pages</source>
        <translation>Lisää tyhjiä sivuja</translation>
    </message>
    <message>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation>Haluatko varmasti asettaa valitun kirjanmerkin kohteen tähän sijaintiin?</translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <source>Pages</source>
        <translation>Sivut</translation>
    </message>
    <message>
        <source>Even pages</source>
        <translation>Parilliset sivut</translation>
    </message>
    <message>
        <source>Clockwise 90 degrees</source>
        <translation>Myötäpäivään 90 astetta</translation>
    </message>
    <message>
        <source>Current Page</source>
        <translation>Nykyinen sivu</translation>
    </message>
    <message>
        <source>Even and Odd pages</source>
        <translation>Parilliset ja parittomat sivut</translation>
    </message>
    <message>
        <source>Rotate</source>
        <translation>Käännä</translation>
    </message>
    <message>
        <source>Odd pages</source>
        <translation>Parittomat sivut</translation>
    </message>
    <message>
        <source>Page Range</source>
        <translation>Sivualue</translation>
    </message>
    <message>
        <source>Direction</source>
        <translation>Suunta</translation>
    </message>
    <message>
        <source>Sample: 1,6-8,12</source>
        <translation>Esim: 1,6-8,12</translation>
    </message>
    <message>
        <source>180 degrees</source>
        <translation>180 astetta</translation>
    </message>
    <message>
        <source>Counterclockwise 90 degrees</source>
        <translation>Vastapäivään 90 astetta</translation>
    </message>
    <message>
        <source>All Pages</source>
        <translation>Kaikki sivut</translation>
    </message>
</context>
<context>
    <name>KeyboardShortcutsDlg</name>
    <message>
        <source>Reset</source>
        <translation>Nollaa</translation>
    </message>
    <message>
        <source>Reset All</source>
        <translation>Nollaa kaikki</translation>
    </message>
    <message>
        <source>Command</source>
        <translation>Komento</translation>
    </message>
    <message>
        <source>Keyboard shortcuts</source>
        <translation>Pikanäppäimet</translation>
    </message>
    <message>
        <source>Shortcut</source>
        <translation>Pikakuvake</translation>
    </message>
</context>
<context>
    <name>InstalllanguagesDlg</name>
    <message>
        <source>Install</source>
        <translation>Asenna</translation>
    </message>
    <message>
        <source>Languages</source>
        <translation>Kielet</translation>
    </message>
    <message>
        <source>Install languages</source>
        <translation>Asenna kielet</translation>
    </message>
</context>
<context>
    <name>QImageViewer</name>
    <message>
        <source>Fit Page</source>
        <translation>Sovita sivulle</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>Suurenna</translation>
    </message>
    <message>
        <source>Clear Selections</source>
        <translation>Tyhjennä valinnat</translation>
    </message>
    <message>
        <source>Zoom to Selection</source>
        <translation>Zoomaa valintaan</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>Pienennä</translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <source>Manage Pages and bookmarks</source>
        <translation>Hallinnoida sivuja ja kirjanmerkkejä</translation>
    </message>
    <message>
        <source>Required a password to open the document</source>
        <translation>Asiakirjan avaamiseen vaaditaan salasana</translation>
    </message>
    <message>
        <source>Permissions</source>
        <translation>Käyttöoikeudet</translation>
    </message>
    <message>
        <source>Printing the document</source>
        <translation>Tulostaa asiakirja</translation>
    </message>
    <message>
        <source>Document Open Password</source>
        <translation>Asiakirjan avaussalasana</translation>
    </message>
    <message>
        <source>Print a high resolution version of the document</source>
        <translation>Tulostaa korkea-resoluutioversio asiakirjasta</translation>
    </message>
    <message>
        <source>Commenting</source>
        <translation>Kommentointi</translation>
    </message>
    <message>
        <source>Fill in existing form or signature fields</source>
        <translation>Täyttää lomake- tai allekirjoituskentät</translation>
    </message>
    <message>
        <source>Password Confirm</source>
        <translation>Vahvista salasana</translation>
    </message>
    <message>
        <source>Security PDF</source>
        <translation>Suojattu PDF</translation>
    </message>
    <message>
        <source>128 bit RC4</source>
        <translation>128 bit RC4</translation>
    </message>
    <message>
        <source>256 bit AES</source>
        <translation>256 bit AES</translation>
    </message>
    <message>
        <source>Document Open password does not match.</source>
        <translation>Asiakirjan avaussalasana ei ole oikea.</translation>
    </message>
    <message>
        <source>Document Permission password does not match.</source>
        <translation>Asiakirjan käyttöoikeussalasana ei ole oikea.</translation>
    </message>
    <message>
        <source>Encryption</source>
        <translation>Salaus</translation>
    </message>
    <message>
        <source>Permissions Password</source>
        <translation>Käyttöoikeussalasana</translation>
    </message>
    <message>
        <source>Content copying for accessibility</source>
        <translation>Sisällön kopiointi esteettömästi</translation>
    </message>
    <message>
        <source>Extract the content of the document</source>
        <translation>Purkaa asiakirjan sisältö</translation>
    </message>
    <message>
        <source>Modifying document</source>
        <translation>Muokata asiakirjaa</translation>
    </message>
</context>
<context>
    <name>AppearanceOptionsDlg</name>
    <message>
        <source>Show when printing</source>
        <translation>Näytä kun tulostetaan</translation>
    </message>
    <message>
        <source>Appearance Options</source>
        <translation>Ulkomuoto-asetukset</translation>
    </message>
    <message>
        <source>Keep position and size of watermark text constant when printing on different page sizes</source>
        <translation>Pidä vesileiman tekstin sijaintia ja kokoa vakiona, kun tulostat eri sivukokoja</translation>
    </message>
    <message>
        <source>Show when displaying on screen</source>
        <translation>Näytä kun näyttö on toiminnassa</translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation>Fontti ei sisälly tähän merkistöön. Valitse toinen fontti.</translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <source>Add Bookmark</source>
        <translation>Lisää kirjanmerkki</translation>
    </message>
    <message>
        <source>Bookmark Properties</source>
        <translation>Kirjanmerkin ominaisuudet</translation>
    </message>
    <message>
        <source>Delete Bookmark</source>
        <translation>Poista kirjanmerkki</translation>
    </message>
    <message>
        <source>Set Destination</source>
        <translation>Aseta kohde</translation>
    </message>
</context>
<context>
    <name>ScannerOptionsDialog</name>
    <message>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Käännä 90 astetta vastapäivään</translation>
    </message>
    <message>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Käännä 90 astetta myötäpäivään</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation>Esikatselu</translation>
    </message>
</context>
<context>
    <name>ScannerMsg</name>
    <message>
        <source>Scanning complete</source>
        <translation>Skannaus on valmis</translation>
    </message>
    <message>
        <source>Scan more pages</source>
        <translation>Skannaa lisää sivuja</translation>
    </message>
</context>
<context>
    <name>QStartWidget</name>
    <message>
        <source>Recent Files</source>
        <translation>Viimeisimmät tiedostot</translation>
    </message>
    <message>
        <source>Open Document</source>
        <translation>Avaa PDF-asiakirja</translation>
    </message>
    <message>
        <source>User Guide</source>
        <translation>Käyttöohje (netissä)</translation>
    </message>
    <message>
        <source>Buy Online</source>
        <translation>Osta netin kautta</translation>
    </message>
    <message>
        <source>Blank PDF</source>
        <translation>Tyhjä PDF-asiakirja</translation>
    </message>
    <message>
        <source>Create New Document</source>
        <translation>Luo uusi PDF-asiakirja</translation>
    </message>
    <message>
        <source>Register...</source>
        <translation>Rekisteröi...</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <source>From Scanner</source>
        <translation>PDF-asiakirja skannerilta</translation>
    </message>
    <message>
        <source>From Files</source>
        <translation>PDF-asiakirja tiedostoista</translation>
    </message>
</context>
<context>
    <name>TextEditDlg</name>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font background color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the background color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Fontin taustaväri&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Muuta fontin taustaväriä&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Text Editor</source>
        <translation>Tekstieditori</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Fonttityyppi&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Muuta fonttityyppiä&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Fontin väri&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Muuta fontin väriä&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>ScanExeDlg</name>
    <message>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
    <message>
        <source>Scanning...</source>
        <translation>Skannataan...</translation>
    </message>
</context>
<context>
    <name>StampDlg</name>
    <message>
        <source>Custom</source>
        <translation>Mukauta</translation>
    </message>
    <message>
        <source>Settings</source>
        <translation>Asetukset</translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation>Tiedosto on suojattu. Anna asiakirjan salasana</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Salasana:</translation>
    </message>
    <message>
        <source>Enter Password</source>
        <translation>Anna salasana</translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <source>Search</source>
        <translation>Etsi</translation>
    </message>
    <message>
        <source>0 result</source>
        <translation>0 tulosta</translation>
    </message>
    <message>
        <source> result</source>
        <translation>tulos</translation>
    </message>
    <message>
        <source>Include Comments</source>
        <translation>Sisältää kommentit</translation>
    </message>
    <message>
        <source> results</source>
        <translation>tuloksia</translation>
    </message>
    <message>
        <source>Whole Words Only</source>
        <translation>Vain kokonaisen sanan perusteella</translation>
    </message>
    <message>
        <source> result(s)</source>
        <translation>tulos(ta)</translation>
    </message>
    <message>
        <source>Case Sensitive</source>
        <translation>Sama kirjainkoko</translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <source>Java Script</source>
        <translation>JavaScripti</translation>
    </message>
    <message>
        <source>Java Script Editor</source>
        <translation>JavaScript-editori</translation>
    </message>
    <message>
        <source>Function Name</source>
        <translation>Funktion nimi</translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <source>Include Comments</source>
        <translation>Sisällytä kommentit</translation>
    </message>
    <message>
        <source>Whole Words Only</source>
        <translation>Vain koko sanalla</translation>
    </message>
    <message>
        <source>Case Sensitive</source>
        <translation>Sama kirjainkoko</translation>
    </message>
</context>
<context>
    <name>KeySequenceEdit</name>
    <message>
        <source>Press shortcut</source>
        <translation>Klikkaa kuvaketta</translation>
    </message>
    <message>
        <source>%1, ...</source>
        <translation>%1, ...</translation>
    </message>
</context>
</TS>
