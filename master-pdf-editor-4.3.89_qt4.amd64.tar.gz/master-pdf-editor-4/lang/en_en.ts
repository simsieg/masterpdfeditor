<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../../src/aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/aboutdialog.ui" line="60"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ActionDocummentDlg</name>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="14"/>
        <source>Document Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="86"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="93"/>
        <source>Java Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="20"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="42"/>
        <source>Document Will Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="47"/>
        <source>Document Will Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="52"/>
        <source>Document Did Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="57"/>
        <source>Document Will Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ActionDocumentDlg.ui" line="62"/>
        <source>Document Did Print</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AdvancedPrintDialog</name>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="14"/>
        <source>Advanced Print Setup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="20"/>
        <source>Print as Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/advancedprintdialog.ui" line="40"/>
        <source>Queue In Subset Pages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AnnotTextInspectorDlg</name>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="14"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="20"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="174"/>
        <source>Borders and Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="184"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="189"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="194"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="199"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="204"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="209"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="214"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="219"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="224"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="229"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="234"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="242"/>
        <source>Border Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="249"/>
        <source>Fill Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="257"/>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="262"/>
        <source>Dashed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="270"/>
        <source>Line Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/AnnotTextInspectorDlg.ui" line="277"/>
        <source>Line Width</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AppearanceOptionsDlg</name>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="14"/>
        <source>Appearance Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="20"/>
        <source>Show when printing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="27"/>
        <source>Show when displaying on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/AppearanceOptionsDlg.ui" line="34"/>
        <source>Keep position and size of watermark text constant when printing on different page sizes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BackgroundDlg</name>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="14"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="20"/>
        <source>Saved Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="39"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="53"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="61"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="71"/>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="77"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="91"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="299"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="305"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="384"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="390"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="416"/>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="515"/>
        <source>Total pages :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="98"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="118"/>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="134"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="167"/>
        <source>Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="193"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="199"/>
        <source>Rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="217"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="237"/>
        <source>Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="293"/>
        <source>Scale relative to target page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="303"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="309"/>
        <source>Vertical distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="323"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="382"/>
        <source>from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="337"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="342"/>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="398"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="347"/>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="368"/>
        <source>Horizontal distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="393"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="403"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="411"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="419"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="424"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="429"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.ui" line="461"/>
        <source>Page Range Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="123"/>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="123"/>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="133"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="168"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="168"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="229"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="245"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="263"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="283"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="283"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/BackgroundDlg.cpp" line="309"/>
        <source>There was an error opening the document !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="14"/>
        <source>Bookmark Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="24"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="48"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="83"/>
        <source>Set current position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="93"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="112"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="126"/>
        <source>Plain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="131"/>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="136"/>
        <source>Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="141"/>
        <source>Italic &amp; Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="162"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="69"/>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="176"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="289"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="348"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="329"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="182"/>
        <source>Add an Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="217"/>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="201"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="209"/>
        <source>Mouse Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="60"/>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="225"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="230"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="235"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="240"/>
        <source>Reset form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="245"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="250"/>
        <source>Submit a form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="255"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.ui" line="263"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="66"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="208"/>
        <source>Do you want to set the current position?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="210"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CombineFilesDlg</name>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="14"/>
        <source>Create a new document from files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="154"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="221"/>
        <source>Append to Current Document </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="228"/>
        <source>Create New Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="163"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="169"/>
        <source>Before current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="179"/>
        <source>After last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="186"/>
        <source>After current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="196"/>
        <source>Before first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="23"/>
        <source>Add Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="40"/>
        <source>Add Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="98"/>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="109"/>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="120"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="144"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="61"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="61"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.ui" line="244"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="41"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="56"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="61"/>
        <source>Total pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="299"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="506"/>
        <source>Save As PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="301"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="508"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="331"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="335"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="332"/>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="336"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="363"/>
        <source>Select directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="536"/>
        <source>Save failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="537"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/combinefiles/CombineFilesDlg.cpp" line="537"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="14"/>
        <source>Delete Page(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="26"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="32"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="78"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="88"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="114"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/DeletePagesDlg.ui" line="140"/>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DistanceToolDlg</name>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="14"/>
        <source>Distance Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="36"/>
        <source>Measurement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="71"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="98"/>
        <source>Distance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="91"/>
        <source>Angle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="121"/>
        <source>Cursor Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="140"/>
        <source>X:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="160"/>
        <source>Y:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="183"/>
        <source>Units and Markup Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="270"/>
        <source>Scale Ratio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="190"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="245"/>
        <source>pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="195"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="250"/>
        <source>in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="200"/>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="255"/>
        <source>mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="263"/>
        <source>=</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="277"/>
        <source>Annotation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.ui" line="61"/>
        <source>°</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="24"/>
        <source>Distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="28"/>
        <source>Perimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="35"/>
        <source>Area</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="38"/>
        <source> sq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="198"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="201"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DistanceToolDlg.cpp" line="205"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgIconPlacement</name>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="14"/>
        <source>Icon Placement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="20"/>
        <source>Fit to bounds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="27"/>
        <source>When to scale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="35"/>
        <source>Proportionally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="40"/>
        <source>Non-Proportionally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="103"/>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="204"/>
        <source>Scale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="222"/>
        <source>Always</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="227"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="232"/>
        <source>Icon is too big</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="237"/>
        <source>Icon is too small</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/DlgIconPlacement.ui" line="245"/>
        <source>Use this dialog to change the way the icon is scaled to fit inside the button</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgPageNumberDateFormat</name>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="14"/>
        <source>Page Number and Date Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="26"/>
        <source>Date Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="56"/>
        <source>Page Number Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.ui" line="82"/>
        <source>Start Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="43"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="46"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="45"/>
        <location filename="../../src/document/forms/DlgPageNumberDateFormat.cpp" line="46"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgPageRange</name>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="14"/>
        <source>Page Range Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="23"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="69"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="90"/>
        <source>Even and Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="95"/>
        <source>Even pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="100"/>
        <source>Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="39"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/DlgPageRange.ui" line="29"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="20"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="21"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="22"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="23"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="30"/>
        <source>Add Sticky Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="31"/>
        <source>Highlight Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="32"/>
        <source>Strikeout Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="33"/>
        <source>Underline Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="34"/>
        <source>Add Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1614"/>
        <location filename="../../src/docpage/docpage.cpp" line="1655"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1623"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1633"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="1645"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage.cpp" line="2599"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="104"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="105"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="106"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="107"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="108"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="109"/>
        <source>Edit text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="110"/>
        <source>Signature options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="111"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="112"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="113"/>
        <source>Set Fit to Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="114"/>
        <source>Save Image to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1052"/>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1054"/>
        <source>PNG Images (*.png);;BMP Images (*.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="1064"/>
        <source>PNG Images (*.png)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="2155"/>
        <source>Open Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="2155"/>
        <source>Image Files (*.svg *.svgz *.tif *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/docpage_base.cpp" line="2192"/>
        <source>ERROR Loading Image !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="14"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="49"/>
        <source>Java script editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="165"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="77"/>
        <location filename="../../src/forms/EditActionForm.ui" line="83"/>
        <location filename="../../src/forms/EditActionForm.ui" line="232"/>
        <source>Select Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="126"/>
        <location filename="../../src/forms/EditActionForm.ui" line="258"/>
        <source>Deselect All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="152"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="113"/>
        <location filename="../../src/forms/EditActionForm.ui" line="238"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="323"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="179"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="185"/>
        <source>FDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="195"/>
        <source>HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="202"/>
        <source>XFDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="209"/>
        <source>PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="271"/>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="278"/>
        <source>Local file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="283"/>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="288"/>
        <source>FTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="293"/>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="336"/>
        <source>Use anonymous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="346"/>
        <source>Need user name and password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="356"/>
        <source>User name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.ui" line="383"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="109"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="111"/>
        <source>All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="181"/>
        <source>Show/Hide Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="185"/>
        <source>Select Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionForm.cpp" line="215"/>
        <source>Reset Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="14"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="107"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="27"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="90"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="36"/>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="91"/>
        <source>Enter a file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="49"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="76"/>
        <source>Goto a page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="82"/>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="89"/>
        <source>Zoom Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="96"/>
        <source>Zoom (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="103"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="110"/>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="134"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="139"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="144"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="149"/>
        <source>Fit Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="154"/>
        <source>Fit Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="162"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="178"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="194"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="181"/>
        <location filename="../../src/forms/EditActionSmallForm.ui" line="197"/>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="98"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="99"/>
        <source>Enter a web site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="106"/>
        <source>Named Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="160"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/EditActionSmallForm.cpp" line="162"/>
        <source>All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="14"/>
        <source>Extract Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="26"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="54"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="67"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="73"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="83"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="93"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="123"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="133"/>
        <source>Extract pages as a single file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.ui" line="143"/>
        <source>Export Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="10"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="34"/>
        <location filename="../../src/ExportPageDialog.cpp" line="72"/>
        <source>Export Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="111"/>
        <source>Save As PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="113"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="144"/>
        <location filename="../../src/ExportPageDialog.cpp" line="171"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportPageDialog.cpp" line="144"/>
        <location filename="../../src/ExportPageDialog.cpp" line="171"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportTextDialog</name>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="14"/>
        <location filename="../../src/ExportTextDialog.cpp" line="87"/>
        <source>Export to text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="26"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="54"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="67"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="73"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="83"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="93"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="123"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.ui" line="133"/>
        <source>Extract pages as a single file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="10"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="89"/>
        <source>txt files (*.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="119"/>
        <location filename="../../src/ExportTextDialog.cpp" line="146"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ExportTextDialog.cpp" line="119"/>
        <location filename="../../src/ExportTextDialog.cpp" line="146"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <location filename="../../src/FileSettings.ui" line="14"/>
        <source>Document Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="37"/>
        <source>Document Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="43"/>
        <source>PDF Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="49"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="59"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="69"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="99"/>
        <source>Keywords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="79"/>
        <source>Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="89"/>
        <source>Producer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="113"/>
        <source>Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="197"/>
        <source>Printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="184"/>
        <source>Print a high resolution version of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="249"/>
        <source>Modifying document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="210"/>
        <source>Fill in existing form or signature fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="262"/>
        <source>Manage Pages and bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="123"/>
        <source>No Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="128"/>
        <source>Password Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="136"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="156"/>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="171"/>
        <source>Extract the content of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="223"/>
        <source>Content copying for accessibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="236"/>
        <source>Commenting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="308"/>
        <source>Initial View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="314"/>
        <source>User Interface Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="320"/>
        <source>Hide tool bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="327"/>
        <source>Hide menu bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="334"/>
        <source>Hide Window Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="344"/>
        <source>Windows Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="364"/>
        <source>Center window on screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="350"/>
        <source>Display document title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="357"/>
        <source>Open in Full Screen mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="387"/>
        <source>Layout and Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="493"/>
        <source>Navigation Tab:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="536"/>
        <source>Page layout:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="410"/>
        <location filename="../../src/FileSettings.ui" line="544"/>
        <location filename="../../src/FileSettings.cpp" line="222"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="549"/>
        <source>Single Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="554"/>
        <source>Single Page Continuous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="559"/>
        <source>Two-Up (Facing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="564"/>
        <source>Two-Up Continuous (Facing)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="569"/>
        <source>Two-Up (Cover Page)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="574"/>
        <source>Two-Up Continuous (Cover Page)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="529"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="415"/>
        <location filename="../../src/FileSettings.cpp" line="227"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="420"/>
        <location filename="../../src/FileSettings.cpp" line="232"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="425"/>
        <location filename="../../src/FileSettings.cpp" line="237"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="430"/>
        <location filename="../../src/FileSettings.cpp" line="242"/>
        <source>Fit Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="435"/>
        <location filename="../../src/FileSettings.cpp" line="247"/>
        <source>Fit Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="440"/>
        <source>25%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="445"/>
        <source>50%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="450"/>
        <source>75%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="455"/>
        <source>100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="460"/>
        <source>125%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="465"/>
        <source>150%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="470"/>
        <source>200%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="475"/>
        <source>300%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="480"/>
        <source>400%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="485"/>
        <source>600%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="501"/>
        <source>Page Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="506"/>
        <source>Bookmarks Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="511"/>
        <source>Pages Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="521"/>
        <source>Attachments Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="632"/>
        <location filename="../../src/FileSettings.ui" line="722"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="638"/>
        <source>Document Open Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="644"/>
        <source>Add an Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="664"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="669"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="674"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="679"/>
        <source>Reset form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="684"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="689"/>
        <source>Submit a form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="694"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="702"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="709"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="737"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="778"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="516"/>
        <source>Layers Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="582"/>
        <source>Open to Page:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="589"/>
        <source>of :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="607"/>
        <source>Fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.ui" line="623"/>
        <source>Fonts used in this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="688"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="689"/>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/FileSettings.cpp" line="706"/>
        <source>Incorrect password. Please input the owner password.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HeaderAndFoterDlg</name>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="14"/>
        <source>Header &amp; Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="130"/>
        <source>Top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="94"/>
        <source>Right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="153"/>
        <source>Bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="71"/>
        <source>Left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="32"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="189"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="195"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="215"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="235"/>
        <source>Font Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="352"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="366"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="374"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="288"/>
        <source>Right Footer Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="20"/>
        <source>Margins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="40"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="45"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="50"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="295"/>
        <source>Center Header Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="302"/>
        <source>Left Footer Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="309"/>
        <source>Right Header Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="316"/>
        <source>Center Footer Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="323"/>
        <source>Left Header Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="333"/>
        <source>Saved Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="427"/>
        <source>Insert Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="420"/>
        <source>Insert Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="410"/>
        <source>Page number and date format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.ui" line="392"/>
        <source>Page Range Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="298"/>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="298"/>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="308"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="343"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="343"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="456"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="476"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/HeaderAndFooterDlg.cpp" line="496"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="14"/>
        <source>Insert Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="26"/>
        <source>Before page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="78"/>
        <source>After page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="178"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="184"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="194"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="220"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="230"/>
        <source>Import Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="130"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="165"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="145"/>
        <location filename="../../src/ImportPageDialog.cpp" line="192"/>
        <source>Total pages :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="20"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="107"/>
        <source>After last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.ui" line="58"/>
        <source>Before first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="10"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="116"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="116"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="146"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="147"/>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ImportPageDialog.cpp" line="185"/>
        <source>Read Error: This PDF is protected.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstalllanguagesDlg</name>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="14"/>
        <source>Install languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.ui" line="37"/>
        <source>Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/InstalllanguagesDlg.cpp" line="37"/>
        <source>Install</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptConsoleDlg</name>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="14"/>
        <source>JavaScript Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="36"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="43"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="50"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/JavaScriptConsoleDlg.ui" line="57"/>
        <source>Stays On Top</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptDocumentDlg</name>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="14"/>
        <source>Document JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="20"/>
        <source>Function Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="45"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="52"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/JSDocumentDlg.ui" line="59"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="14"/>
        <source>Java Script Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="20"/>
        <source>Function Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/javascripteditdialog.ui" line="32"/>
        <source>Java Script</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeySequenceEdit</name>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="121"/>
        <source>%1, ...</source>
        <extracomment>This text is an &quot;unfinished&quot; shortcut, expands like &quot;Ctrl+A, ...&quot;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeySequenceEdit.cpp" line="200"/>
        <source>Press shortcut</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyboardShortcutsDlg</name>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="20"/>
        <source>Keyboard shortcuts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="39"/>
        <source>Reset All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="46"/>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="84"/>
        <source>Shortcut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="52"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/KeyboardShortcutsDlg.ui" line="79"/>
        <source>Command</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="743"/>
        <source> ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1703"/>
        <source>Smooth text and images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="759"/>
        <source>Time before a move or resize starts:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="772"/>
        <source>Select item by hovering the mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="122"/>
        <source>Saving Documents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="162"/>
        <source>Create backup file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="148"/>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="135"/>
        <source>Last used folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="140"/>
        <source>Original documents folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="272"/>
        <source>Required field highlight color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="252"/>
        <source>Highlight color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="795"/>
        <source>Default font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2554"/>
        <source>Built-in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2540"/>
        <source>Please choose the interface language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="993"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1013"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1079"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1086"/>
        <source>pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1967"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2575"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1857"/>
        <source>Selected text color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1870"/>
        <source>Icon set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1906"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="729"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1018"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1924"/>
        <source>Application Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1987"/>
        <source>Use default program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2006"/>
        <source>evolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2011"/>
        <source>kmail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2016"/>
        <source>thunderbird</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2024"/>
        <source>Use SMTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2047"/>
        <source>SMTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2135"/>
        <source>Email address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2128"/>
        <source>Secure connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2103"/>
        <source>NONE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2108"/>
        <source>SSL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2113"/>
        <source>STARTTLS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2095"/>
        <source>SMTP server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2085"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2121"/>
        <source>SMTP port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2068"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2465"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="954"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="959"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="964"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1664"/>
        <source>Always show Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1693"/>
        <source>Forbid files to enable Full Screen mode on opening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1911"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="730"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1022"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1916"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="731"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1026"/>
        <source>Dark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2226"/>
        <source>Default path to tesseract ocr data files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2265"/>
        <source>Additional tesseract ocr config file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2327"/>
        <source>Install languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2347"/>
        <source>Direct internet connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2357"/>
        <source>Manual proxy configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2373"/>
        <source>HTTP Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2380"/>
        <source>SOCKS 5 Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2390"/>
        <source>Host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2400"/>
        <source>Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2056"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2443"/>
        <source>Authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2455"/>
        <source>User name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2641"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2646"/>
        <source>Weekly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2651"/>
        <source>Monthly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2627"/>
        <source>Check for Updates Automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="155"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2242"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="2281"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="498"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="856"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1046"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1319"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1382"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="469"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="807"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="172"/>
        <source>History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="184"/>
        <source>Restore last session when application start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="191"/>
        <source>Restore last view settings when reopening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1106"/>
        <source>Enable JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="308"/>
        <source> Always hide document message bar </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1567"/>
        <source>Default Layout and Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1580"/>
        <source>Default page layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1591"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1675"/>
        <source>Automatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1680"/>
        <source>Single Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1685"/>
        <source>Facing Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1573"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="54"/>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="59"/>
        <source>JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="79"/>
        <source>Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="84"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="89"/>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="94"/>
        <source>Network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="201"/>
        <source>Open documents as new tabs in the same window (requires restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="208"/>
        <source>Enable scroll wheel zooming</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="215"/>
        <source>Show Start page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="235"/>
        <source>Load all objects separately</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="316"/>
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="321"/>
        <source>Edit Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="326"/>
        <source>Check box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="331"/>
        <source>Radio button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="336"/>
        <source>Combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="341"/>
        <source>List box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="346"/>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="351"/>
        <source>Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="372"/>
        <source>Borders and Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="379"/>
        <source>Thin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="384"/>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="389"/>
        <source>Thick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="397"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="611"/>
        <source>Border Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="404"/>
        <source>Fill Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="412"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="626"/>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="417"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="631"/>
        <source>Dashed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="422"/>
        <source>Beveled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="427"/>
        <source>Inset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="432"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="636"/>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="440"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="618"/>
        <source>Line Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="447"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="597"/>
        <source>Line Thickness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="482"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="511"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="527"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="538"/>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="553"/>
        <source>Diamond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="558"/>
        <source>Square</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="591"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="644"/>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="655"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="660"/>
        <source>Invert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="665"/>
        <source>OutLine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="670"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="914"/>
        <source>Automatically change font when editing text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="926"/>
        <source>Exact match only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="946"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="972"/>
        <source>Width between lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="979"/>
        <source>Height between lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="986"/>
        <source>Left offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1006"/>
        <source>Top offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1026"/>
        <source>Subdivision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1118"/>
        <source>Show errors and  messages in console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1128"/>
        <source>Enable safe reading mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1211"/>
        <source>Measurements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1216"/>
        <source>Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1221"/>
        <source>Typewriter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1596"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1601"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1606"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1611"/>
        <source>25%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1616"/>
        <source>50%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1621"/>
        <source>75%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1626"/>
        <source>100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1631"/>
        <source>125%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1636"/>
        <source>150%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1641"/>
        <source>200%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1646"/>
        <source>300%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1651"/>
        <source>400%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1656"/>
        <source>600%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="457"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1709"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1810"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1716"/>
        <source>Bitmap Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1723"/>
        <source>Vector Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1752"/>
        <source>System PPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1798"/>
        <source>Replace Document Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1817"/>
        <source>Page Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="64"/>
        <source>Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="74"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="366"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1864"/>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1746"/>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1762"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1485"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1183"/>
        <source>Pop-up Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1290"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1408"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1527"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1191"/>
        <source>Sticky Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1273"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1306"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1369"/>
        <source>Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1196"/>
        <source>Highlight Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1201"/>
        <source>Strikeout Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1206"/>
        <source>Underline Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1395"/>
        <source>Line Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="1931"/>
        <source>Icons in menus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="39"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="99"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="104"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="44"/>
        <source>Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="49"/>
        <source>Editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="69"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="348"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="363"/>
        <source>Select directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="377"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="648"/>
        <source>Arabic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="649"/>
        <source>Armenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="650"/>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="651"/>
        <source>Catalan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="652"/>
        <source>Chinese-Simplified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="653"/>
        <source>Chinese-Traditional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="654"/>
        <source>Czech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="655"/>
        <source>Danish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="656"/>
        <source>Dutch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="657"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="658"/>
        <source>Estonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="659"/>
        <source>Finnish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="660"/>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="661"/>
        <source>Galician</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="662"/>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="663"/>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="664"/>
        <source>Hebrew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="665"/>
        <source>Hungarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="666"/>
        <source>Irish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="667"/>
        <source>Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="668"/>
        <source>Japanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="669"/>
        <source>Korean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="670"/>
        <source>Latvian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="671"/>
        <source>Lithuanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="672"/>
        <source>Norwegian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="673"/>
        <source>Norwegian-Nynorsk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="674"/>
        <source>Polish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="675"/>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="676"/>
        <source>Portuguese-Brazilian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="677"/>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="678"/>
        <source>Russian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="679"/>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="680"/>
        <source>Slovak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="681"/>
        <source>Slovenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="682"/>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="683"/>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="684"/>
        <source>Thai</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="685"/>
        <source>Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="686"/>
        <source>Ukrainian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="687"/>
        <source>Valencian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="688"/>
        <source>Vietnamese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="700"/>
        <source>Check Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1744"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1764"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="1784"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="543"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="701"/>
        <source>Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="702"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="548"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="703"/>
        <source>Cross</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="704"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="705"/>
        <source>Insert Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="706"/>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="707"/>
        <source>New Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="708"/>
        <source>Text Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="709"/>
        <source>Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="710"/>
        <source>Right Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="711"/>
        <source>Right Pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.ui" line="563"/>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="712"/>
        <source>Star</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="713"/>
        <source>Up Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="714"/>
        <source>Up Left Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="715"/>
        <source>Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="716"/>
        <source>Paper Clip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="717"/>
        <source>Attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainoptions/mainoptionsdialog.cpp" line="718"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../src/mainwindow.ui" line="36"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="46"/>
        <source>Export to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="177"/>
        <location filename="../../src/mainwindow.ui" line="1354"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="481"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="181"/>
        <source>Align Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="78"/>
        <location filename="../../src/mainwindow.ui" line="1346"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="507"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="208"/>
        <source>Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="135"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="293"/>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="114"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="256"/>
        <location filename="../../src/mainwindow.ui" line="1370"/>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="103"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="585"/>
        <source>Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="145"/>
        <location filename="../../src/mainwindow.ui" line="1362"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="553"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="53"/>
        <location filename="../../src/mainwindow.ui" line="1813"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="764"/>
        <location filename="../../src/mainwindow.cpp" line="2961"/>
        <source>Create a new blank PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="767"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="315"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="462"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="648"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="649"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="650"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="712"/>
        <source>Stamp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="324"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="371"/>
        <source>Select text for copying and pasting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="374"/>
        <source>Alt+5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="408"/>
        <source>PgUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="423"/>
        <source>PgDown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="464"/>
        <source>Ctrl+0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="493"/>
        <source>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="519"/>
        <source>Ctrl+1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="537"/>
        <source>Ctrl+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="546"/>
        <location filename="../../src/mainwindow.cpp" line="2296"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="552"/>
        <source>Save the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="555"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="564"/>
        <location filename="../../src/mainwindow.cpp" line="715"/>
        <location filename="../../src/mainwindow.cpp" line="4910"/>
        <location filename="../../src/mainwindow.cpp" line="4973"/>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="570"/>
        <source>Save the document with a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="573"/>
        <source>Ctrl+Shift+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="582"/>
        <location filename="../../src/mainwindow.ui" line="780"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="585"/>
        <location filename="../../src/mainwindow.ui" line="783"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="588"/>
        <source>Print the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="591"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="596"/>
        <location filename="../../src/mainwindow.ui" line="599"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="602"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="607"/>
        <location filename="../../src/mainwindow.ui" line="610"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="631"/>
        <source>Ctrl+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="662"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="665"/>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="686"/>
        <source>Select text for editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="689"/>
        <source>Alt+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="698"/>
        <location filename="../../src/mainwindow.ui" line="1533"/>
        <location filename="../../src/mainwindow.ui" line="1579"/>
        <location filename="../../src/mainwindow.ui" line="1592"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="704"/>
        <source>Delete the currently selected object(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="758"/>
        <source>Blank PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="789"/>
        <source>Ctrl+Shift+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="804"/>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="822"/>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="840"/>
        <source>Paste from the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="873"/>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="888"/>
        <source>Undo the last action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="906"/>
        <source>Redo the previously undone action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="924"/>
        <source>Send to Back selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="933"/>
        <source>Bring to Front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="936"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="939"/>
        <source>Bring to Front selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="974"/>
        <source>Ctrl+Shift+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="993"/>
        <source>Ctrl+Shift+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1004"/>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1009"/>
        <location filename="../../src/mainwindow.ui" line="1012"/>
        <source>Extract Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1015"/>
        <source>Ctrl+Shift+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1020"/>
        <location filename="../../src/mainwindow.ui" line="1023"/>
        <source>Insert Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1026"/>
        <source>Ctrl+Shift+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1045"/>
        <source>Open window with document properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1063"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1066"/>
        <source>Click the page to add a note at that position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1069"/>
        <source>Ctrl+6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1114"/>
        <location filename="../../src/mainwindow.ui" line="1621"/>
        <location filename="../../src/mainwindow.cpp" line="4199"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1120"/>
        <source>Insert new text to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1123"/>
        <source>Ctrl+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1132"/>
        <location filename="../../src/mainwindow.cpp" line="4208"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1138"/>
        <source>Insert new image to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1141"/>
        <source>Ctrl+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1204"/>
        <source>Insert new link to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1216"/>
        <source>Text Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1231"/>
        <source>Check Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1243"/>
        <source>Radio Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1255"/>
        <source>Combo Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1267"/>
        <source>List Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1319"/>
        <source>Check for Updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1390"/>
        <location filename="../../src/mainwindow.ui" line="1393"/>
        <source>Open Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1398"/>
        <location filename="../../src/mainwindow.ui" line="1401"/>
        <source>Crop Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1404"/>
        <source>Ctrl+K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1413"/>
        <location filename="../../src/mainwindow.ui" line="1416"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1425"/>
        <location filename="../../src/mainwindow.ui" line="1428"/>
        <location filename="../../src/mainwindow.ui" line="1431"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1436"/>
        <source>Export Form Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1441"/>
        <source>Import Form Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1446"/>
        <source>Export Comments Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1451"/>
        <source>Import Comments Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1456"/>
        <source>Save Optimized As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1459"/>
        <source>Ctrl+Alt+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1470"/>
        <source>F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1483"/>
        <source>Document JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1488"/>
        <source>Document Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1496"/>
        <source>Replace Document Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1501"/>
        <source>Paste to Multiple Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1504"/>
        <source>Ctrl+Shift+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1509"/>
        <source>JavaScript Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1512"/>
        <source>Ctrl+J</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1517"/>
        <source>Page Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1525"/>
        <location filename="../../src/mainwindow.ui" line="1571"/>
        <location filename="../../src/mainwindow.ui" line="1584"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1528"/>
        <source>Ctrl+Shift+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1544"/>
        <source>Menu Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1547"/>
        <source>F9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1555"/>
        <source>Show Cover Page During Facing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1563"/>
        <source>Full Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1566"/>
        <source>F11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1574"/>
        <source>Ctrl+Shift+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1587"/>
        <source>Ctrl+Shift+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1597"/>
        <location filename="../../src/mainwindow.ui" line="1600"/>
        <source>Align Center Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1605"/>
        <location filename="../../src/mainwindow.ui" line="1608"/>
        <source>Align Center Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1613"/>
        <source>Find Previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1616"/>
        <source>Shift+F3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1640"/>
        <source>Send file via email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1827"/>
        <source>F12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1832"/>
        <source>Typewriter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1837"/>
        <source>Callout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1846"/>
        <source>Formatted Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1849"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Formatted Text&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new formatted text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1626"/>
        <location filename="../../src/mainwindow.ui" line="1629"/>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1634"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1637"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Email delivery&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send file via email&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1648"/>
        <location filename="../../src/mainwindow.ui" line="1651"/>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1654"/>
        <source>Ctrl+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1662"/>
        <location filename="../../src/mainwindow.ui" line="1665"/>
        <source>Snap to Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1668"/>
        <source>Ctrl+Shift+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1676"/>
        <location filename="../../src/mainwindow.ui" line="1679"/>
        <source>Distance Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1687"/>
        <location filename="../../src/mainwindow.ui" line="1690"/>
        <source>Perimeter Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1698"/>
        <location filename="../../src/mainwindow.ui" line="1701"/>
        <source>Area Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1720"/>
        <location filename="../../src/mainwindow.ui" line="1723"/>
        <source>Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1764"/>
        <location filename="../../src/mainwindow.ui" line="1767"/>
        <source>Attach a File as a Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1772"/>
        <source>From Scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1775"/>
        <location filename="../../src/mainwindow.ui" line="1778"/>
        <source>Create a new document from scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1783"/>
        <source>From Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1786"/>
        <location filename="../../src/mainwindow.ui" line="1789"/>
        <source>Create a new document from files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1805"/>
        <location filename="../../src/mainwindow.ui" line="1808"/>
        <source>Brush</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1824"/>
        <source>Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="918"/>
        <source>Send to Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="921"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="707"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1330"/>
        <source>Statusbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="387"/>
        <location filename="../../src/mainwindow.ui" line="390"/>
        <source>First Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="402"/>
        <location filename="../../src/mainwindow.ui" line="405"/>
        <source>Previous Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="417"/>
        <location filename="../../src/mainwindow.ui" line="420"/>
        <source>Next Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="428"/>
        <location filename="../../src/mainwindow.ui" line="431"/>
        <source>Last Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="718"/>
        <source>Alt+Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1234"/>
        <source>Check box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1219"/>
        <source>Edit Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1246"/>
        <source>Radio button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1270"/>
        <source>List box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1258"/>
        <source>Combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1338"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="444"/>
        <source>Main</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1291"/>
        <location filename="../../src/mainwindow.ui" line="1294"/>
        <source>Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="837"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="859"/>
        <location filename="../../src/mainwindow.ui" line="862"/>
        <source>Set Fit to Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1150"/>
        <location filename="../../src/mainwindow.ui" line="1153"/>
        <location filename="../../src/mainwindow.ui" line="1709"/>
        <location filename="../../src/mainwindow.ui" line="1712"/>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1162"/>
        <location filename="../../src/mainwindow.ui" line="1165"/>
        <location filename="../../src/mainwindow.ui" line="1731"/>
        <location filename="../../src/mainwindow.ui" line="1734"/>
        <source>Rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1174"/>
        <location filename="../../src/mainwindow.ui" line="1177"/>
        <location filename="../../src/mainwindow.ui" line="1742"/>
        <location filename="../../src/mainwindow.ui" line="1745"/>
        <source>Ellipse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="786"/>
        <source>Print Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="944"/>
        <location filename="../../src/mainwindow.ui" line="947"/>
        <source>Align Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="952"/>
        <location filename="../../src/mainwindow.ui" line="955"/>
        <source>Align Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="960"/>
        <location filename="../../src/mainwindow.ui" line="963"/>
        <source>Align Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1031"/>
        <location filename="../../src/mainwindow.ui" line="1034"/>
        <source>Align Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="644"/>
        <location filename="../../src/mainwindow.ui" line="647"/>
        <source>Reduce Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="636"/>
        <location filename="../../src/mainwindow.ui" line="639"/>
        <source>Enlarge Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="772"/>
        <location filename="../../src/mainwindow.ui" line="775"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="968"/>
        <location filename="../../src/mainwindow.ui" line="971"/>
        <source>Insert Blank Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1039"/>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1042"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open window with document properties&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1051"/>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1117"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new text to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1135"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new image to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1201"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Insert new link to current page&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1207"/>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1222"/>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1309"/>
        <source>Home page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1314"/>
        <source>Register...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="882"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="885"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="891"/>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1186"/>
        <location filename="../../src/mainwindow.ui" line="1189"/>
        <location filename="../../src/mainwindow.ui" line="1753"/>
        <location filename="../../src/mainwindow.ui" line="1756"/>
        <source>Pencil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1279"/>
        <location filename="../../src/mainwindow.ui" line="1282"/>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="443"/>
        <location filename="../../src/mainwindow.ui" line="446"/>
        <source>Zoom In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="449"/>
        <source>Ctrl++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="473"/>
        <location filename="../../src/mainwindow.ui" line="476"/>
        <source>Zoom Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="479"/>
        <source>Ctrl+-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="458"/>
        <location filename="../../src/mainwindow.ui" line="461"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="379"/>
        <location filename="../../src/mainwindow.ui" line="382"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1304"/>
        <source>Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="487"/>
        <location filename="../../src/mainwindow.ui" line="490"/>
        <source>Highlight Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="344"/>
        <location filename="../../src/mainwindow.ui" line="350"/>
        <source>Hand Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="680"/>
        <source>Edit Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="987"/>
        <location filename="../../src/mainwindow.ui" line="990"/>
        <source>Page layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="900"/>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="903"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="909"/>
        <source>Ctrl+Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="798"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="20"/>
        <source>Master PDF Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="90"/>
        <source>Page Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="99"/>
        <source>Go To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="108"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="157"/>
        <location filename="../../src/mainwindow.ui" line="1378"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="569"/>
        <source>Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="212"/>
        <source>Header and Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="219"/>
        <source>Watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="226"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="260"/>
        <source>Measurements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="268"/>
        <source>Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="318"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Open a PDF or XPS file&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="329"/>
        <location filename="../../src/mainwindow.ui" line="332"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="347"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Use the hand tool for moving pages, open links and selecting text.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="368"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="393"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="434"/>
        <source>End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="498"/>
        <location filename="../../src/mainwindow.ui" line="501"/>
        <source>Reset Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="513"/>
        <location filename="../../src/mainwindow.ui" line="516"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="531"/>
        <location filename="../../src/mainwindow.ui" line="534"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="549"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="567"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Save the document with a new name&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="613"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="625"/>
        <location filename="../../src/mainwindow.ui" line="628"/>
        <source>Facing Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="683"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="701"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Delete the currently selected object(s)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="712"/>
        <location filename="../../src/mainwindow.ui" line="715"/>
        <source>Delete Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="730"/>
        <location filename="../../src/mainwindow.ui" line="736"/>
        <location filename="../../src/mainwindow.ui" line="1797"/>
        <source>Edit Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="733"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Form (Alt+3)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select form for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="753"/>
        <source>Ctrl+F11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="761"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Create a new blank PDF&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="801"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="807"/>
        <source>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="816"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="819"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="825"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="834"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="843"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="848"/>
        <location filename="../../src/mainwindow.ui" line="851"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="854"/>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="659"/>
        <source>Edit Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="668"/>
        <source>Alt+1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1198"/>
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1078"/>
        <location filename="../../src/mainwindow.ui" line="1081"/>
        <source>Highlight Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1060"/>
        <source>Add Sticky Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1090"/>
        <location filename="../../src/mainwindow.ui" line="1093"/>
        <source>Strikeout Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1102"/>
        <location filename="../../src/mainwindow.ui" line="1105"/>
        <source>Underline Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="365"/>
        <source>Select Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="739"/>
        <source>Alt+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1299"/>
        <source>HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="867"/>
        <location filename="../../src/mainwindow.ui" line="870"/>
        <location filename="../../src/mainwindow.ui" line="1478"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="542"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="1467"/>
        <source>Find Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="998"/>
        <location filename="../../src/mainwindow.ui" line="1001"/>
        <source>Rotate Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="979"/>
        <location filename="../../src/mainwindow.ui" line="982"/>
        <source>Move Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="353"/>
        <source>Alt+4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2072"/>
        <source>Open failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2073"/>
        <source>Cannot open file :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="39"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="429"/>
        <source>Empty recent files list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="68"/>
        <source>Prev/Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="91"/>
        <source>Edit Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="147"/>
        <source>Page :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="321"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="464"/>
        <source>Open a PDF file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="688"/>
        <location filename="../../src/mainwindow.cpp" line="4901"/>
        <location filename="../../src/mainwindow.cpp" line="4964"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="725"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="35"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="425"/>
        <source>Recent Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="295"/>
        <location filename="../../src/mainwindow.cpp" line="361"/>
        <source>There was an error opening the document !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="517"/>
        <location filename="../../src/mainwindow.cpp" line="531"/>
        <source>All Supported Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps);;All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="644"/>
        <source>Saving in XPS is temporarily not supported.
Choose PDF file name for saving.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="886"/>
        <source>Export completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1249"/>
        <location filename="../../src/mainwindow.cpp" line="1265"/>
        <source>Can&apos;t find :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="1320"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2290"/>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2297"/>
        <source>Close Without Saving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2298"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2585"/>
        <source>Master PDF Editor can&apos;t find any Headers and Footers in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2598"/>
        <source>Do you want to delete the Headers and Footers from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2620"/>
        <source>Master PDF Editor can&apos;t find any Watermarks in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2633"/>
        <source>Do you want to delete the Watermarks from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2655"/>
        <source>Master PDF Editor can&apos;t find any Background in the document.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2668"/>
        <source>Do you want to delete the Background from the document?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="3878"/>
        <source>Your installed version of Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4193"/>
        <source>Characters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4194"/>
        <source>Font type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4196"/>
        <source>Font Embedded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4198"/>
        <source>Font Not Embedded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4204"/>
        <location filename="../../src/mainwindow.cpp" line="4289"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4205"/>
        <location filename="../../src/mainwindow.cpp" line="4290"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4206"/>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4212"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4216"/>
        <source>Shading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4228"/>
        <location filename="../../src/mainwindow.cpp" line="4286"/>
        <source>Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4228"/>
        <location filename="../../src/mainwindow.cpp" line="4299"/>
        <source>Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4303"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="4910"/>
        <location filename="../../src/mainwindow.cpp" line="4931"/>
        <location filename="../../src/mainwindow.cpp" line="4934"/>
        <location filename="../../src/mainwindow.cpp" line="4973"/>
        <location filename="../../src/mainwindow.cpp" line="4993"/>
        <location filename="../../src/mainwindow.cpp" line="4996"/>
        <source>FDF Files (*.fdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="2408"/>
        <source>A error occurred during the signature verification!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="657"/>
        <location filename="../../src/mainwindow.cpp" line="757"/>
        <location filename="../../src/mainwindow.cpp" line="3064"/>
        <location filename="../../src/mainwindow.cpp" line="3174"/>
        <location filename="../../src/mainwindow.cpp" line="3283"/>
        <source>Save failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="69"/>
        <source>Ctrl+Shift++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="45"/>
        <source>Ctrl+F12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="70"/>
        <source>Ctrl+Shift+-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="658"/>
        <location filename="../../src/mainwindow.cpp" line="758"/>
        <location filename="../../src/mainwindow.cpp" line="3065"/>
        <location filename="../../src/mainwindow.cpp" line="3175"/>
        <location filename="../../src/mainwindow.cpp" line="3284"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="658"/>
        <location filename="../../src/mainwindow.cpp" line="758"/>
        <location filename="../../src/mainwindow.cpp" line="3065"/>
        <location filename="../../src/mainwindow.cpp" line="3175"/>
        <location filename="../../src/mainwindow.cpp" line="3284"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="30"/>
        <source>You already have the latest version!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_update.cpp" line="38"/>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="517"/>
        <location filename="../../src/mainwindow.cpp" line="519"/>
        <location filename="../../src/mainwindow.cpp" line="4931"/>
        <location filename="../../src/mainwindow.cpp" line="4934"/>
        <location filename="../../src/mainwindow.cpp" line="4993"/>
        <location filename="../../src/mainwindow.cpp" line="4996"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="747"/>
        <location filename="../../src/mainwindow.ui" line="750"/>
        <location filename="../../src/mainwindow.ui" line="1387"/>
        <source>Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="660"/>
        <source>Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.ui" line="82"/>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="77"/>
        <location filename="../../src/mac/mainwindow_mac_tool_bars.cpp" line="133"/>
        <location filename="../../src/mainwindow_tool_bars.cpp" line="526"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ManuallyTextOCRDlg</name>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="14"/>
        <source>Recognized text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="20"/>
        <source>Original</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.ui" line="55"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/ManuallyTextOCRDlg.cpp" line="17"/>
        <source>Not Text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="14"/>
        <source>Move Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="26"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="32"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="78"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="88"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="114"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="140"/>
        <source>Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="152"/>
        <source>To:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="162"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="211"/>
        <source>First</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/MovePagesDialog.ui" line="218"/>
        <source>Last</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="20"/>
        <source>Page Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="194"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="231"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="33"/>
        <source>A0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="38"/>
        <source>A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="43"/>
        <source>A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="48"/>
        <source>A3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="53"/>
        <source>A4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="58"/>
        <source>A5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="63"/>
        <source>A6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="68"/>
        <source>A7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="73"/>
        <source>A8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="78"/>
        <source>A9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="83"/>
        <source>A10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="88"/>
        <source>Letter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="93"/>
        <source>Tabloid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="98"/>
        <source>B0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="103"/>
        <source>B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="108"/>
        <source>B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="113"/>
        <source>B3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="118"/>
        <source>B4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="123"/>
        <source>B5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="128"/>
        <source>Statement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="133"/>
        <source>Executive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="138"/>
        <source>Folio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="143"/>
        <source>Quarto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="148"/>
        <source>Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="153"/>
        <source>ANSI C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="158"/>
        <source>ANSI D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="163"/>
        <source>ANSI E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="168"/>
        <source>ANSI F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="173"/>
        <source>Custom page size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="218"/>
        <source>Portrait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="223"/>
        <source>Landscape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="267"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="296"/>
        <source>Contents Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="308"/>
        <source>Left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="348"/>
        <source>Top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="328"/>
        <source>Right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="275"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="280"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="285"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="368"/>
        <source>Bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="391"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="397"/>
        <source>Before current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="414"/>
        <source>After current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="421"/>
        <source>After last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="407"/>
        <source>Before first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="431"/>
        <source>Number of pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="457"/>
        <source>Page(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.ui" line="437"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.cpp" line="182"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.cpp" line="209"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/NewPageDialog.cpp" line="231"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OCRDialog</name>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="14"/>
        <source>OCR Engine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="29"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="35"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="42"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="72"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="82"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="95"/>
        <source>Languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="125"/>
        <location filename="../../src/ocr/OCRDialog.cpp" line="187"/>
        <source>Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="151"/>
        <source>Install languages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="170"/>
        <source>Searchable Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="180"/>
        <source>Editable Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="200"/>
        <source>Font Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.ui" line="220"/>
        <source>Manually edit all recognized text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRDialog.cpp" line="60"/>
        <location filename="../../src/ocr/OCRDialog.cpp" line="284"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OCRExe</name>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="14"/>
        <source>OCR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.ui" line="27"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/ocr/OCRExe.cpp" line="54"/>
        <source>Are you sure you want to stop document recognition?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="57"/>
        <source>No Properties
There is no object selections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="331"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3166"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3385"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2020"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="142"/>
        <source>Property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="147"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="913"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="466"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="797"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="476"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2748"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="498"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1869"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1903"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1975"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2031"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2867"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="508"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="784"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="574"/>
        <source>Behavior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="728"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1309"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1455"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1610"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="733"/>
        <source>Push</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="738"/>
        <source>Outline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="743"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1314"/>
        <source>Invert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="777"/>
        <source>Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="810"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1085"/>
        <source>Export Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="650"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="852"/>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="655"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="836"/>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="880"/>
        <source>Sort Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="859"/>
        <source>Commit selected value immediately</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="873"/>
        <source>Multiple selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="866"/>
        <source>Allow user to enter custom text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="960"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="967"/>
        <source>Scrollable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="974"/>
        <source>Check spelling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="981"/>
        <source>Limit to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="995"/>
        <source>chars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1002"/>
        <source>Split into</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="946"/>
        <source>Allow Rich Text formatting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="953"/>
        <source>Multi-line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1016"/>
        <source>cells</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="928"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2496"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="933"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="938"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1026"/>
        <source>Default Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="920"/>
        <source>Alignment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1098"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2634"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1109"/>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1114"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="238"/>
        <source>Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1119"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="240"/>
        <source>Cross</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1124"/>
        <source>Diamond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1129"/>
        <source>Square</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1134"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="249"/>
        <source>Star</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1062"/>
        <source>Checked by Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="581"/>
        <source>Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="592"/>
        <source>Label only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="597"/>
        <source>Icon only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="602"/>
        <source>Icon top, label bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="607"/>
        <source>Label top, icon bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="612"/>
        <source>Icon left, label right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="617"/>
        <source>label left, icon right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="622"/>
        <source>Label over icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="637"/>
        <source>Icon and Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="660"/>
        <source>Rollover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="677"/>
        <source>State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="684"/>
        <source>Choose Icon...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="707"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="714"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1186"/>
        <source>Buttons with the same name and value are selected in unison</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1251"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3156"/>
        <source>Line Thickness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1265"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3106"/>
        <source>Border Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1272"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3149"/>
        <source>Line Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1280"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3121"/>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1285"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3126"/>
        <source>Dashed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1290"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3141"/>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1298"/>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1319"/>
        <source>OutLine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1324"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1342"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1401"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2767"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2886"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1441"/>
        <source>Format category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1460"/>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1465"/>
        <source>Percentage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1470"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1475"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1480"/>
        <source>Special</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1485"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1640"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="224"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="228"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1504"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1509"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1514"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1519"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1524"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1529"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1534"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1539"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1544"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1549"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1554"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1563"/>
        <source>1,234.56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1568"/>
        <source>1234.56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1573"/>
        <source>1.234,56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1578"/>
        <source>1234,56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1592"/>
        <source>Currency Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1615"/>
        <source>Dollar ($)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1620"/>
        <source>Euro (€)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1625"/>
        <source>Pound (£)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1630"/>
        <source>Yen (¥)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1635"/>
        <source>Ruble (Руб)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1661"/>
        <source>Show parentheses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1681"/>
        <source>Decimal Places</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1688"/>
        <source>Separation Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1695"/>
        <source>Use red text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1712"/>
        <source>Date Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1751"/>
        <source>Time Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1784"/>
        <source>Special Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1842"/>
        <source>Format Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1876"/>
        <source>KeyStroke Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1927"/>
        <source>Validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1948"/>
        <source>Validation Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="1983"/>
        <source>Calculate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2004"/>
        <source>Calculation Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2133"/>
        <source>Fill text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2138"/>
        <source>Stroke Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2143"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2946"/>
        <source>Fill and Stroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2148"/>
        <source>Invisible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2162"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3113"/>
        <source>Fill Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2188"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3014"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3437"/>
        <source>Line Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2217"/>
        <source>Character spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2224"/>
        <source>Word spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2231"/>
        <source>Line height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2274"/>
        <source>+</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2293"/>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2343"/>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2369"/>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2379"/>
        <source>E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2389"/>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2399"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2409"/>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2476"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2524"/>
        <source>Maintain aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2453"/>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="630"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2552"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2672"/>
        <source>Clipping Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2805"/>
        <source>Selection change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2833"/>
        <source>Do nothing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2840"/>
        <source>Execute this script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2936"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2954"/>
        <source>Fill</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3131"/>
        <source>Beveled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3136"/>
        <source>Inset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3191"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3255"/>
        <source>ToolTip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3271"/>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3279"/>
        <source>0 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3284"/>
        <source>90 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3289"/>
        <source>180 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3294"/>
        <source>270 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3315"/>
        <source>Read Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3330"/>
        <source>Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3335"/>
        <source>Hidden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3340"/>
        <source>Visible but doesn&apos;t print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3345"/>
        <source>Hidden but printable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3353"/>
        <source>Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3363"/>
        <source>Locked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3392"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3447"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2068"/>
        <source>Font Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2097"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3178"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2113"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2916"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3467"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2503"/>
        <source>Coordinates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2511"/>
        <source>Absolute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2516"/>
        <source>Relative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2560"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2565"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2570"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2593"/>
        <source>Geometry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2615"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3220"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2653"/>
        <source>Matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2691"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2710"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2729"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2786"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2941"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2989"/>
        <source>Stroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2979"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3001"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3207"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3417"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3081"/>
        <source>Borders and Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3088"/>
        <source>Thin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3093"/>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3098"/>
        <source>Thick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2175"/>
        <source>Stroke Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2201"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2966"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3027"/>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3430"/>
        <source>Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="231"/>
        <source>Zip Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="231"/>
        <source>Zip Code+4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="231"/>
        <source>Phone Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="231"/>
        <source>Social Security Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="237"/>
        <source>Check Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="239"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="241"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="242"/>
        <source>Insert Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="243"/>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="244"/>
        <source>New Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="245"/>
        <source>Text Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="246"/>
        <source>Paragraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="247"/>
        <source>Right Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="248"/>
        <source>Right Pointer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="250"/>
        <source>Up Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="251"/>
        <source>Up Left Arrow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="252"/>
        <source>Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="253"/>
        <source>Paper Clip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="254"/>
        <source>Attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="255"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1069"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1069"/>
        <source>All Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1542"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1549"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1562"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1569"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1615"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1621"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1797"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="3768"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1802"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="3788"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1806"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="3808"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2044"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2086"/>
        <source>Shading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2110"/>
        <source>Header and Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2112"/>
        <source>Watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2114"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2466"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="2486"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="2065"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3322"/>
        <source>Form Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3245"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1554"/>
        <location filename="../../src/objectinspector/ObjectInspector.cpp" line="1603"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="3062"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="422"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="354"/>
        <source>Add an Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="360"/>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="368"/>
        <source>Mouse Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="373"/>
        <source>Mouse Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="378"/>
        <source>Mouse Enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="383"/>
        <source>Mouse Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="388"/>
        <source>On Receive Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="393"/>
        <source>On Lose Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="414"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="427"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="432"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="437"/>
        <source>Reset form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="442"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="447"/>
        <source>Submit a form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/objectinspector/ObjectInspector.ui" line="452"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObjectTreeView</name>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="14"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="33"/>
        <source>Object TreeView</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="20"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="40"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.ui" line="69"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="208"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="229"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="20"/>
        <source>Expand All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="21"/>
        <source>Collapse All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="64"/>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="107"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="75"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="80"/>
        <source>Paths</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="85"/>
        <source>Shadings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="90"/>
        <source>Containers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="113"/>
        <source>Text Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="118"/>
        <source>List Boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="123"/>
        <source>Combo Boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="128"/>
        <source>Check Boxes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="133"/>
        <source>Radio Buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="138"/>
        <source>Buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="143"/>
        <source>Links</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="148"/>
        <source>Signatures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/object_treeview/ObjectTreeView.cpp" line="212"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="14"/>
        <source>Page Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="69"/>
        <location filename="../../src/PageLayoutDialog.ui" line="89"/>
        <location filename="../../src/PageLayoutDialog.ui" line="121"/>
        <location filename="../../src/PageLayoutDialog.ui" line="138"/>
        <location filename="../../src/PageLayoutDialog.ui" line="155"/>
        <location filename="../../src/PageLayoutDialog.ui" line="172"/>
        <location filename="../../src/PageLayoutDialog.cpp" line="257"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="102"/>
        <source>Contents Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="114"/>
        <source>Left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="131"/>
        <source>Top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="148"/>
        <source>Right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="165"/>
        <source>Bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="53"/>
        <source>Page Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="59"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.cpp" line="284"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.cpp" line="306"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="79"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="185"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="214"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="276"/>
        <source>Even and Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="281"/>
        <source>Even pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="286"/>
        <source>Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="304"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="294"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="196"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="201"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="206"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="220"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/PageLayoutDialog.ui" line="252"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PagePropertiesDlg</name>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="14"/>
        <source>Page Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="50"/>
        <source>Tab Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="69"/>
        <source>Use Row Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="76"/>
        <source>Use Column Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="62"/>
        <source>Use Document Structure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="83"/>
        <source>Unspecified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="120"/>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="126"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="201"/>
        <source>Add an Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="214"/>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="245"/>
        <source>Open Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="250"/>
        <source>Close Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="207"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="259"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="264"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="269"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="274"/>
        <source>Reset form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="279"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="284"/>
        <source>Submit a form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="289"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="221"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="327"/>
        <location filename="../../src/forms/PagePropertiesDlg.cpp" line="50"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="141"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/PagePropertiesDlg.ui" line="160"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageSetupDialog</name>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="14"/>
        <source>Printer Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="20"/>
        <source>Paper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="26"/>
        <source>Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="58"/>
        <source>Height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="77"/>
        <source>Page size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="87"/>
        <source>Margins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="95"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="98"/>
        <source>bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="111"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="114"/>
        <source>top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="174"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="177"/>
        <source>left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="206"/>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="209"/>
        <source>right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="264"/>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="271"/>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="285"/>
        <source>72</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="290"/>
        <source>150</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="295"/>
        <source>300</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="300"/>
        <source>600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="305"/>
        <source>900</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="310"/>
        <source>1200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/pagesetupdialog.ui" line="404"/>
        <source>Paper Source</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <location filename="../../src/passwordopendialog.ui" line="14"/>
        <source>Enter Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/passwordopendialog.ui" line="66"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/passwordopendialog.ui" line="56"/>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasteDialog</name>
    <message>
        <location filename="../../src/pastedialog.ui" line="14"/>
        <source>Paste to multiple pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="26"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="32"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="78"/>
        <source>All pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/pastedialog.ui" line="88"/>
        <source>Except current one</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <location filename="../../src/docpage/texteditor/plaintextedit.cpp" line="235"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="263"/>
        <source>Printer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="281"/>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="53"/>
        <source>Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="58"/>
        <source>Document and Annotations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="42"/>
        <source>Print:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="484"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="530"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="562"/>
        <source>Even pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="567"/>
        <source>Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="398"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="384"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="391"/>
        <source>Print as Grayscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="432"/>
        <source>Aspect Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="440"/>
        <source>Ignore aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="445"/>
        <source>Keep aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="450"/>
        <source>Keep aspect ratio by expanding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="609"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="297"/>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="359"/>
        <source>Portrait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="364"/>
        <source>Landscape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="575"/>
        <source>Subset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="557"/>
        <source>All pages in range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="304"/>
        <source>Duplex Printing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="313"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="323"/>
        <source>Long side</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="330"/>
        <location filename="../../src/printdialog/printdialog.ui" line="354"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="337"/>
        <source>Short side</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="220"/>
        <source>Number of copies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="247"/>
        <source>Collate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="130"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="140"/>
        <source>of:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="470"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="520"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="633"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="497"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.cpp" line="92"/>
        <source>of </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/printdialog/printdialog.ui" line="14"/>
        <location filename="../../src/printdialog/printdialog.cpp" line="140"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="17"/>
        <source>Attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="22"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="22"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="22"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="22"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="37"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="38"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="39"/>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="479"/>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="40"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="109"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="113"/>
        <source>Attachment Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/attachment/qattachment.cpp" line="459"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="17"/>
        <source>Add Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="18"/>
        <source>Delete Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="19"/>
        <source>Bookmark Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/bookmark/qbookmarks.cpp" line="20"/>
        <source>Set Destination</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="36"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="40"/>
        <source>Close All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="44"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="48"/>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="52"/>
        <source>Move to New Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="153"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qdoctab.cpp" line="921"/>
        <location filename="../../src/document/qdoctab.cpp" line="944"/>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QEmailDlg</name>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="14"/>
        <source>Email delivery</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="29"/>
        <source>To</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="39"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.ui" line="49"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/email/QEmailDlg.cpp" line="9"/>
        <source>Send</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QImageViewer</name>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="96"/>
        <source>Zoom In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="100"/>
        <source>Zoom Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="104"/>
        <source>Zoom to Selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="108"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/qimageviewer.cpp" line="112"/>
        <source>Clear Selections</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/app_config.cpp" line="8"/>
        <source>You are not allowed to use this function in the free version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="12"/>
        <source>The unregistered version will insert a watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="17"/>
        <source>Open with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="23"/>
        <location filename="../../src/app_config.cpp" line="28"/>
        <location filename="../../src/app_config.cpp" line="30"/>
        <location filename="../../src/app_config.cpp" line="35"/>
        <location filename="../../src/app_config.cpp" line="39"/>
        <location filename="../../src/app_config.cpp" line="43"/>
        <source>Build</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="23"/>
        <location filename="../../src/app_config.cpp" line="28"/>
        <location filename="../../src/app_config.cpp" line="30"/>
        <source>Based on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="23"/>
        <location filename="../../src/app_config.cpp" line="39"/>
        <source>32 bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="28"/>
        <location filename="../../src/app_config.cpp" line="30"/>
        <location filename="../../src/app_config.cpp" line="35"/>
        <location filename="../../src/app_config.cpp" line="43"/>
        <source>64 bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="50"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="55"/>
        <source>Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="60"/>
        <source>Brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="65"/>
        <source>Contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="70"/>
        <source>Gamma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="75"/>
        <source>Approved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="80"/>
        <source>Confidential</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="85"/>
        <source>Received</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="90"/>
        <source>Reviewed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="95"/>
        <source>Revised</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="100"/>
        <source>Completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="105"/>
        <source>Draft</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="110"/>
        <source>Emergency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="115"/>
        <source>Expired</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="120"/>
        <source>Final</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="125"/>
        <source>Verified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="130"/>
        <source>Void</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="135"/>
        <source>Accepted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="140"/>
        <source>Initial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="145"/>
        <source>Rejected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="150"/>
        <source>SignHere</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="155"/>
        <source>Witness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="160"/>
        <source>Dynamic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="165"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="170"/>
        <source>h:MM tt mmmm dd.yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="183"/>
        <source>Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="188"/>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="193"/>
        <source>Press Help button to get more info.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="198"/>
        <source>Error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="203"/>
        <source>Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="208"/>
        <source>Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="213"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="218"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="223"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="228"/>
        <source>Shading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="233"/>
        <source>All Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="238"/>
        <source>Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="243"/>
        <source>Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="248"/>
        <source>Container</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="253"/>
        <source>Sticky Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="258"/>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="263"/>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="268"/>
        <source>StrikeOut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="273"/>
        <source>Reply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="278"/>
        <source>Typewriter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="283"/>
        <source>Text Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/app_config.cpp" line="288"/>
        <source>Formatted Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="13"/>
        <source>Mouse Enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="15"/>
        <source>Mouse Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="17"/>
        <source>Mouse Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="19"/>
        <source>Mouse Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="21"/>
        <source>On Receive Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="23"/>
        <source>On Lose Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="25"/>
        <source>Page Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="27"/>
        <source>Page Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="29"/>
        <source>Page Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="31"/>
        <source>Page Invisible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="33"/>
        <source>Open Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="35"/>
        <source>Close Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="37"/>
        <source>KeyStroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="39"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="41"/>
        <source>Validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="43"/>
        <source>Calculate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="45"/>
        <source>Close Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="47"/>
        <source>Save Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="49"/>
        <source>Document Saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="51"/>
        <source>Print Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="53"/>
        <source>Document Printed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="68"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="70"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="72"/>
        <location filename="../../src/utils/fpdf_utils.cpp" line="74"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="76"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="78"/>
        <source>Thread</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="80"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="82"/>
        <source>Sound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="84"/>
        <source>Movie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="86"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="90"/>
        <source>Submit Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="92"/>
        <source>Reset Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="94"/>
        <source>Import Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="96"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="100"/>
        <source>Rendition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/utils/fpdf_utils.cpp" line="104"/>
        <source>Goto 3D View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="53"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="56"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="53"/>
        <location filename="../../src/document/qpdfdocument_callbacks.cpp" line="56"/>
        <source>FDF Files (*.fdf)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="583"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="585"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="587"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="589"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="599"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="601"/>
        <source>of</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="595"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="597"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="599"/>
        <location filename="../../src/document/qpdfdocument.cpp" line="601"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="2340"/>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="2816"/>
        <source>There was a problem with your form submission.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/qpdfdocument.cpp" line="2818"/>
        <source>Your form was successfully submitted!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QStartWidget</name>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="26"/>
        <source>Open Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="31"/>
        <source>Blank PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="36"/>
        <source>From Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="41"/>
        <source>From Scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="48"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="54"/>
        <source>User Guide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="64"/>
        <source>Register...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="70"/>
        <source>Buy Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="250"/>
        <source>Create New Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/startwidget/QStartWidget.cpp" line="253"/>
        <source>Recent Files</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="119"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="124"/>
        <source>Enlarge Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="127"/>
        <source>Reduce Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="144"/>
        <source>Page Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="132"/>
        <source>Delete Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="136"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="139"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="161"/>
        <source>Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="173"/>
        <source>Attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="183"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="187"/>
        <source>Object TreeView</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="207"/>
        <source>Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="547"/>
        <source>This document contains interactive form fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="548"/>
        <source>Highlight Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="566"/>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="567"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1096"/>
        <location filename="../../src/docpage/qtabpage.cpp" line="1193"/>
        <location filename="../../src/docpage/qtabpage_win.cpp" line="17"/>
        <source>There was an error printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1436"/>
        <source>Error loading font: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1475"/>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="1952"/>
        <source>Insert Blank Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="2889"/>
        <source>Do you want to open?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3653"/>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/docpage/qtabpage.cpp" line="3719"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QUnitsComboBox</name>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="8"/>
        <source>Millimeters (mm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="9"/>
        <source>Inches (in)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="10"/>
        <source>Points (pt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="11"/>
        <source>Pica (P̸)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="12"/>
        <source>Didot (DD)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="13"/>
        <source>Cicero (CC)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="35"/>
        <source>mm</source>
        <extracomment>Unit &apos;Millimeter&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="39"/>
        <source>pt</source>
        <extracomment>Unit &apos;Points&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="43"/>
        <source>in</source>
        <extracomment>Unit &apos;Inch&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="47"/>
        <source>P̸</source>
        <extracomment>Unit &apos;Pica&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="51"/>
        <source>DD</source>
        <extracomment>Unit &apos;Didot&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/QUnitsComboBox.cpp" line="55"/>
        <source>CC</source>
        <extracomment>Unit &apos;Cicero&apos;</extracomment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="132"/>
        <source>More...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="321"/>
        <source>User Color 99</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="335"/>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="336"/>
        <source>White</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="337"/>
        <source>Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="338"/>
        <source>Dark red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="339"/>
        <source>Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="340"/>
        <source>Dark green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="341"/>
        <source>Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="342"/>
        <source>Dark blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="343"/>
        <source>Cyan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="344"/>
        <source>Dark cyan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="345"/>
        <source>Magenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="346"/>
        <source>Dark magenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="347"/>
        <source>Yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="348"/>
        <source>Dark yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="349"/>
        <source>Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="350"/>
        <source>Dark gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="351"/>
        <source>Light gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/qtcolorcombobox.cpp" line="353"/>
        <source>Transparent</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <location filename="../../src/regdialog.ui" line="14"/>
        <source>Registration Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="132"/>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="116"/>
        <source>Buy Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="39"/>
        <location filename="../../src/regdialog.ui" line="248"/>
        <source>Registration Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="46"/>
        <location filename="../../src/regdialog.ui" line="268"/>
        <source>Activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="69"/>
        <source>Offline Activation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="176"/>
        <source>Registered version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="183"/>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="209"/>
        <source>Deactivate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="288"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="309"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="258"/>
        <source>Activation Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.ui" line="295"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="22"/>
        <source>Thanks for registration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="23"/>
        <source>License is deactivated.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="24"/>
        <source>You have exceeded the number of available activations.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/regdialog.cpp" line="25"/>
        <source>Too many activations!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="14"/>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="20"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="52"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="62"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="72"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="83"/>
        <source>Even and Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="88"/>
        <source>Even pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="93"/>
        <source>Odd pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="101"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="111"/>
        <source>Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="118"/>
        <source>Clockwise 90 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="123"/>
        <source>180 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/RotatePagesDlg.ui" line="128"/>
        <source>Counterclockwise 90 degrees</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="14"/>
        <source>Export to Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="318"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="327"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="250"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="262"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="278"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="295"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="20"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="61"/>
        <location filename="../../src/SaveImageDialog.ui" line="130"/>
        <source>JPEG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="26"/>
        <source>BMP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="33"/>
        <source>PNG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="71"/>
        <source>TIFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="40"/>
        <source>JPEG Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="110"/>
        <source>LZW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="115"/>
        <source>ZIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="120"/>
        <source>CCITT FAX 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="125"/>
        <source>CCITT FAX 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="47"/>
        <source>TIFF Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="54"/>
        <source>Transparent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="138"/>
        <source>MultiPage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="148"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="154"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="183"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="337"/>
        <source>Antialiasing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="379"/>
        <source>Export:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="387"/>
        <source>Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="392"/>
        <source>Document and Annotations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.ui" line="212"/>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="13"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="14"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="77"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="77"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="439"/>
        <source>Save As TIFF Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="439"/>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="458"/>
        <source>Save As Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveImageDialog.cpp" line="458"/>
        <source>All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveOptimizedDialog</name>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="14"/>
        <source>Save Optimized As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="39"/>
        <source>Remove unused elements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="49"/>
        <source>Flatten form fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="78"/>
        <source>Color and Grayscale Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="90"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="233"/>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="123"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="266"/>
        <source>Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="143"/>
        <location filename="../../src/SaveOptimizedDialog.ui" line="286"/>
        <source>ZIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="148"/>
        <source>JPEG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="156"/>
        <source>Lossless</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="176"/>
        <source>JPEG Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="221"/>
        <source>Black and White Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="291"/>
        <source>CCITT Group 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SaveOptimizedDialog.ui" line="296"/>
        <source>JBIG2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScanExeDlg</name>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="14"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="14"/>
        <source>Scanning...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/mac/ScanExeDlg.ui" line="40"/>
        <location filename="../../src/scanner/win/ScanExeDlg.ui" line="40"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerDialog</name>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="14"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="12"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="12"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="10"/>
        <source>Scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="37"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="62"/>
        <source>Single Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="67"/>
        <source>All Pages From Feeder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="101"/>
        <source>Scan:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="143"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="84"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="74"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="152"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="93"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="83"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="158"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="99"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="89"/>
        <source>Before current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="168"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="109"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="99"/>
        <source>After last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="175"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="116"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="106"/>
        <source>After current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="185"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="126"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="116"/>
        <source>Before first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="220"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="161"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="141"/>
        <source>Append to Current Document </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="210"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="151"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="148"/>
        <source>Create New Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="49"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="20"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="36"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="132"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="42"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="64"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="81"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="35"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="48"/>
        <source>Scanner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="121"/>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="233"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="174"/>
        <location filename="../../src/scanner/win/ScannerDialog.ui" line="164"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="263"/>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="302"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.ui" line="322"/>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="219"/>
        <source>Looking for devices. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="48"/>
        <source>Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="58"/>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.ui" line="68"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="259"/>
        <source>Flatbed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="261"/>
        <source>Positive Transparency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="263"/>
        <source>Negative Transparency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="265"/>
        <source>Document Feeder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="55"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="41"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="33"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="123"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="344"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="287"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="318"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="164"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="201"/>
        <source>Save As PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="125"/>
        <location filename="../../src/scanner/linux/ScannerDialog.cpp" line="346"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="289"/>
        <location filename="../../src/scanner/mac/ScannerDialog.cpp" line="320"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="166"/>
        <location filename="../../src/scanner/win/ScannerDialog.cpp" line="203"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerMsg</name>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="26"/>
        <source>Scan more pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerMsg.ui" line="33"/>
        <source>Scanning complete</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScannerOptionsDialog</name>
    <message>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="14"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="30"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="33"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="36"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="39"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="59"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="62"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="65"/>
        <location filename="../../src/scanner/ScannerOptionsDialog.ui" line="68"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="14"/>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="20"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.ui" line="46"/>
        <source>0 result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="11"/>
        <source>Case Sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="15"/>
        <source>Include Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="19"/>
        <source>Whole Words Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="55"/>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="63"/>
        <source> result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="65"/>
        <source> result(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchformtab.cpp" line="67"/>
        <source> results</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="126"/>
        <source>Case Sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="127"/>
        <source>Include Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/leftTab/search/searchlineedit.cpp" line="128"/>
        <source>Whole Words Only</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="14"/>
        <source>Security PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="36"/>
        <source>Required a password to open the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="51"/>
        <source>Document Open Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="71"/>
        <location filename="../../src/SecurityDialog.ui" line="132"/>
        <source>Password Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="94"/>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="122"/>
        <source>Commenting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="142"/>
        <source>Modifying document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="155"/>
        <source>Content copying for accessibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="168"/>
        <source>Printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="181"/>
        <source>Extract the content of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="194"/>
        <source>Print a high resolution version of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="207"/>
        <source>Fill in existing form or signature fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="223"/>
        <source>Permissions Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="233"/>
        <source>Manage Pages and bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="275"/>
        <source>Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="281"/>
        <source>128 bit RC4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.ui" line="291"/>
        <source>256 bit AES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.cpp" line="94"/>
        <source>Document Open password does not match.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/SecurityDialog.cpp" line="106"/>
        <source>Document Permission password does not match.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="14"/>
        <source>Signature Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="52"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="27"/>
        <source>Signature is VALID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="72"/>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="129"/>
        <source>Signed by:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="78"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="395"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="448"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="497"/>
        <source>Reason:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="92"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="402"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="504"/>
        <source>Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="115"/>
        <source>Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="169"/>
        <source>Validation Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="185"/>
        <source>Signer&apos;s Contact Information:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="405"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="432"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="448"/>
        <source>Show Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="477"/>
        <source>Stretch Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="333"/>
        <source>Saved Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="352"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="366"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="374"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="470"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="396"/>
        <source>Show Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="136"/>
        <location filename="../../src/signature/SignatureDialog.ui" line="258"/>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="277"/>
        <source>Sign As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="206"/>
        <source>Text For Signing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="219"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="226"/>
        <source>Reason</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="326"/>
        <source>Lock document after signing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.ui" line="496"/>
        <source>Signature Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="45"/>
        <source>I have reviewed this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="46"/>
        <source>I am approving this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="47"/>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="48"/>
        <source>I agree to specified parts of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="24"/>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="25"/>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="26"/>
        <source>Signature is INVALID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="28"/>
        <source>Signature validity is UNKNOWN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="29"/>
        <source>This certificate is not trusted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="30"/>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="31"/>
        <source>Error during signature verification.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="32"/>
        <source>Details: The signature byte range is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="33"/>
        <source>I am the author of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="91"/>
        <source>Open Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="91"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="379"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="482"/>
        <source>Digitally signed by </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="387"/>
        <location filename="../../src/signature/SignatureDialog.cpp" line="488"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="429"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="429"/>
        <source>p12 Files (*.p12)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="722"/>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="722"/>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="732"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="794"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="794"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="414"/>
        <source>A error occurred during the signature verification!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="242"/>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="319"/>
        <source>A password is required to open certificate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureDialog.cpp" line="191"/>
        <source>Sign</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="14"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="34"/>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="40"/>
        <source>Issuer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="46"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="132"/>
        <source>Common Name (CN)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="60"/>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="139"/>
        <source>Organization (O)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="74"/>
        <source>Organizational Unit (OU)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="88"/>
        <source>Serial Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="102"/>
        <source>Algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="119"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="153"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="166"/>
        <source>Validity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="172"/>
        <source>Not Before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="179"/>
        <source>Not After</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="209"/>
        <source>SHA-1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="229"/>
        <source>MD5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="278"/>
        <source>Add to Trusted Identities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/signature/SignatureInfoDialog.ui" line="286"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StampDlg</name>
    <message>
        <location filename="../../src/stamps/StampDlg.cpp" line="99"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampDlg.cpp" line="82"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StampManageDlg</name>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="14"/>
        <source>Custom Stamps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="23"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="30"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="43"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="63"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampManageDlg.ui" line="79"/>
        <source>Stamps</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StampSettingsDlg</name>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="14"/>
        <source>Edit Stamp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="26"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="36"/>
        <source>Template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/stamps/StampSettingsDlg.ui" line="53"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.ui" line="17"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/forms/StickyNoteDlg.cpp" line="22"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TextEditDlg</name>
    <message>
        <location filename="../../src/widgets/TextEditDlg.ui" line="14"/>
        <source>Text Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/TextEditDlg.cpp" line="29"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/TextEditDlg.cpp" line="35"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/widgets/TextEditDlg.cpp" line="44"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font background color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the background color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WatermarkDlg</name>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="14"/>
        <source>Watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="20"/>
        <source>Saved Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="39"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="53"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="61"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="71"/>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="77"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="107"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="114"/>
        <source>Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="124"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="362"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="368"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="463"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="588"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="594"/>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="625"/>
        <source>Total pages :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="131"/>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="148"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="154"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="174"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="181"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="197"/>
        <source>Font Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="230"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="260"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="266"/>
        <source>Rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="284"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="304"/>
        <source>Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="360"/>
        <source>Scale relative to target page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="370"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="376"/>
        <source>Vertical distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="390"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="449"/>
        <source>from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="404"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="409"/>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="465"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="414"/>
        <source>Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="435"/>
        <source>Horizontal distance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="460"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="470"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="478"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="486"/>
        <source>Points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="491"/>
        <source>Inches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="496"/>
        <source>Millimeters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.ui" line="528"/>
        <source>Page Range Options...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="169"/>
        <source>Save Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="169"/>
        <source>Save current settings as:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="179"/>
        <source>Settings with this name already exist. Do you want to replace the old settings?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="215"/>
        <source>Are you sure you want to delete the setting </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="215"/>
        <source> ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="290"/>
        <source> pt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="306"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="324"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="346"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="346"/>
        <source>All Supported Files (*.pdf *.svg *.svgz *.tif *.tiff *.png *.jpg *.jpeg *.bmp *.ppm)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/document/forms/WatermarkDlg.cpp" line="372"/>
        <source>There was an error opening the document !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
