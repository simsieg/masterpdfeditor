<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pl_PL">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../src/aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation>O Programie</translation>
    </message>
    <message>
        <location filename="../src/aboutdialog.ui" line="83"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="14"/>
        <source>Bookmark Properties</source>
        <translation>Właściwości Zakładek</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="24"/>
        <source>Options</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="48"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="83"/>
        <source>Set current position</source>
        <translation>Ustaw bieżącą pozycję</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="93"/>
        <source>Appearance</source>
        <translation>Wygląd</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="112"/>
        <source>Style</source>
        <translation>Styl</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="126"/>
        <source>Plain</source>
        <translation>Zwykły</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="131"/>
        <source>Italic</source>
        <translation>Kursywa</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="136"/>
        <source>Bold</source>
        <translation>Pogrubienie</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="141"/>
        <source>Italic &amp; Bold</source>
        <translation>Pogrubienie i Kursywa</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="162"/>
        <source>Color</source>
        <translation>Kolor</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="69"/>
        <source>Page Number</source>
        <translation>Numer Strony</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="176"/>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="276"/>
        <source>Actions</source>
        <translation>Akcje</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="323"/>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="310"/>
        <source>Edit</source>
        <translation>Edytuj</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="182"/>
        <source>Add an Action</source>
        <translation>Dodaj Akcję</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="188"/>
        <source>Trigger</source>
        <translation>Wyzwalacz</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="217"/>
        <source>Action</source>
        <translation>Akcja</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="196"/>
        <source>Mouse Up</source>
        <translation>Kliknięcie</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="60"/>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="225"/>
        <source>Goto a Page View</source>
        <translation>Przejdź do Widoku Strony</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="230"/>
        <source>Open/execute a File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="235"/>
        <source>Open a web link</source>
        <translation>Otwórz link</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="240"/>
        <source>Reset form</source>
        <translation>Zresetuj formularz</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="245"/>
        <source>Show/Hide fields</source>
        <translation>Pokaż/Ukryj pola</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="250"/>
        <source>Submit a form</source>
        <translation>Prześlij formularz</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="255"/>
        <source>Run a JavaScript</source>
        <translation>Uruchom JavaScript</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="263"/>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="64"/>
        <source>untitled</source>
        <translation>bez nazwy</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="206"/>
        <source>Do you want to set the current position?</source>
        <translation>Chcesz ustawić bieżącą pozycję?</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="208"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="14"/>
        <source>Delete Page(s)</source>
        <translation>Usuń Stronę(y)</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="26"/>
        <source>Page Range</source>
        <translation>Zakres Stron</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="32"/>
        <source>Pages</source>
        <translation>Strony</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Przykład: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="78"/>
        <source>Current Page</source>
        <translation>Bieżąca Strona</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="88"/>
        <source>Pages from</source>
        <translation>Od strony</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="114"/>
        <source>to:</source>
        <translation>do:</translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="140"/>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation>Usunięte strony nie mogą być odzyskane za pomocą operacji cofania.</translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="14"/>
        <source>Copy</source>
        <translation>Kopiuj</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="15"/>
        <source>Select All</source>
        <translation>Zaznacz Wszystkie</translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="62"/>
        <source>Copy</source>
        <translation>Kopiuj</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="63"/>
        <source>Cut</source>
        <translation>Wytnij</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="64"/>
        <source>Paste</source>
        <translation>Wklej</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="65"/>
        <source>Select All</source>
        <translation>Zaznacz Wszystkie</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="66"/>
        <source>Options</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="67"/>
        <source>Edit text</source>
        <translation>Edytuj tekst</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="68"/>
        <source>Signature options</source>
        <translation>Opcje podpisu</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="69"/>
        <source>Undo</source>
        <translation>Cofnij</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="70"/>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="71"/>
        <source>Set Fit to Page</source>
        <translation>Ustaw Dopasowanie do Strony</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="1324"/>
        <source>Open Image</source>
        <translation>Otwórz Obraz</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="1324"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation>Pliki Obrazu (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="1357"/>
        <source>ERORR Load Image !</source>
        <translation>BŁĄD Wczytywania Obrazu!</translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="14"/>
        <source>Action</source>
        <translation>Akcja</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="49"/>
        <source>Java script editor</source>
        <translation>Edytor JavaScript</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="80"/>
        <source>Goto a page</source>
        <translation>Idź do strony</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="99"/>
        <location filename="../src/forms/EditActionForm.ui" line="154"/>
        <location filename="../src/forms/EditActionForm.ui" line="243"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="272"/>
        <source>Top</source>
        <translation>Góra</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="236"/>
        <source>Left</source>
        <translation>Lewa</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="92"/>
        <source>Page Number</source>
        <translation>Numer Strony</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="279"/>
        <source>Zoom (%)</source>
        <translation>Powiększenie (%)</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="319"/>
        <location filename="../src/forms/EditActionForm.cpp" line="153"/>
        <source>Open/execute a File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="325"/>
        <source>Edit a file</source>
        <translation>Edytuj plik</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="450"/>
        <source>Show</source>
        <translation>Pokaż</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="362"/>
        <location filename="../src/forms/EditActionForm.ui" line="368"/>
        <location filename="../src/forms/EditActionForm.ui" line="517"/>
        <source>Select Fields</source>
        <translation>Zaznacz Pola</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="411"/>
        <location filename="../src/forms/EditActionForm.ui" line="543"/>
        <source>Deselect All</source>
        <translation>Odznacz Wszystkie</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="437"/>
        <source>Hide</source>
        <translation>Ukryj</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="398"/>
        <location filename="../src/forms/EditActionForm.ui" line="523"/>
        <source>Select All</source>
        <translation>Zaznacz Wszystkie</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="86"/>
        <source>Options</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="157"/>
        <location filename="../src/forms/EditActionForm.ui" line="246"/>
        <source> px</source>
        <translation>px</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="229"/>
        <source>Zoom Mode</source>
        <translation>Tryb Powiększenia</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="181"/>
        <source>Custom</source>
        <translation>Niestandardowy</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="186"/>
        <source>Inherit Zoom</source>
        <translation>Dziedziczenie Powiększenia</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="191"/>
        <source>Fit Page</source>
        <translation>Dopasuj do Strony</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="196"/>
        <source>Fit Width</source>
        <translation>Dopasuj Do Szerokości</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="201"/>
        <source>FitV</source>
        <translation>Dopasuj do Widoku</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="206"/>
        <source>FitR</source>
        <translation>FitR</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="211"/>
        <source>FitB</source>
        <translation>FitB</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="216"/>
        <source>FitBH</source>
        <translation>FitBH</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="221"/>
        <source>FitBV</source>
        <translation>FitBV</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="335"/>
        <location filename="../src/forms/EditActionForm.ui" line="608"/>
        <source>Browse</source>
        <translation>Przeglądaj</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="464"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="470"/>
        <source>FDF</source>
        <translation>FDF</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="480"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="487"/>
        <source>XFDF</source>
        <translation>XFDF</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="494"/>
        <source>PDF</source>
        <translation>PDF</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="556"/>
        <source>Method</source>
        <translation>Metoda</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="563"/>
        <source>Local file</source>
        <translation>Plik lokalny</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="568"/>
        <source>E-mail</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="573"/>
        <source>FTP</source>
        <translation>FTP</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="578"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="621"/>
        <source>Use anonymous</source>
        <translation>Anominowo</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="628"/>
        <source>Need user name and password</source>
        <translation>Nazwa użytkownika i hasło</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="638"/>
        <source>User name</source>
        <translation>Nazwa użytkownika</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="661"/>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="112"/>
        <location filename="../src/forms/EditActionForm.cpp" line="126"/>
        <source>Open File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="114"/>
        <location filename="../src/forms/EditActionForm.cpp" line="128"/>
        <source>All Files (*.*)</source>
        <translation>Wszystkie Pliki (*.*)</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="154"/>
        <source>Enter a file:</source>
        <translation>Wybierz plik:</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="161"/>
        <source>Open a web link</source>
        <translation>Otwórz link</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="163"/>
        <source>Enter a web site:</source>
        <translation>Wpisz stronę sieciową:</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="214"/>
        <source>Show/Hide Fields</source>
        <translation>Pokaż/Ukryj Pola</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="218"/>
        <source>Select Field</source>
        <translation>Zaznacz Pole</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="247"/>
        <source>Reset Form</source>
        <translation>Zresetuj Formularz</translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="14"/>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="116"/>
        <source>Action</source>
        <translation>Akcja</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="27"/>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="99"/>
        <source>Open/execute a File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="36"/>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="100"/>
        <source>Enter a file:</source>
        <translation>Wybierz plik:</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="49"/>
        <source>Browse</source>
        <translation>Przeglądaj</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="76"/>
        <source>Goto a page</source>
        <translation>Idź do strony</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="82"/>
        <source>Page Number</source>
        <translation>Numer Strony</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="89"/>
        <source>Zoom Mode</source>
        <translation>Tryb Powiększenia</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="96"/>
        <source>Zoom (%)</source>
        <translation>Powiększenie (%)</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="103"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="110"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="134"/>
        <source>XYZ</source>
        <translation>XYZ</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="139"/>
        <source>Fit</source>
        <translation>Dopasuj</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="144"/>
        <source>FitH</source>
        <translation>Dopasuj do wysokości</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="149"/>
        <source>FitV</source>
        <translation>Dopasuj do widoku</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="154"/>
        <source>FitR</source>
        <translation>FitR</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="159"/>
        <source>FitB</source>
        <translation>FitB</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="164"/>
        <source>FitBH</source>
        <translation>FitBH</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="169"/>
        <source>FitBV</source>
        <translation>FitBV</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="177"/>
        <location filename="../src/forms/EditActionSmallForm.ui" line="193"/>
        <location filename="../src/forms/EditActionSmallForm.ui" line="209"/>
        <source>auto</source>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="196"/>
        <location filename="../src/forms/EditActionSmallForm.ui" line="212"/>
        <source> px</source>
        <translation> px</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="107"/>
        <source>Open a web link</source>
        <translation>Otwórz link</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="108"/>
        <source>Enter a web site:</source>
        <translation>Wpisz adres strony internetowej:</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="115"/>
        <source>Named Action</source>
        <translation>Nazwana Akcja</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="164"/>
        <source>Open File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="166"/>
        <source>All Files (*.*)</source>
        <translation>Wszystkie Pliki (*.*)</translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="14"/>
        <source>Extract Pages</source>
        <translation>Wyodrębnij Strony</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="26"/>
        <source>File Name</source>
        <translation>Nazwa Pliku</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="54"/>
        <source>Browse</source>
        <translation>Przeglądaj</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="70"/>
        <source>Page Range</source>
        <translation>Zakres Stron</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="82"/>
        <source>Current Page</source>
        <translation>Bieżąca Strona</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="98"/>
        <source>Pages from</source>
        <translation>Od strony</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="115"/>
        <source>to:</source>
        <translation>do:</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="138"/>
        <source>Extract pages as a single file</source>
        <translation>Wyodrębnij strony jako pojedyncze pliki</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="145"/>
        <source>Export Bookmarks</source>
        <translation>Eksportuj Zakładki</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="10"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="36"/>
        <source>Export Pages</source>
        <translation>Eksportuj Strony</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="76"/>
        <source>Export Pages </source>
        <translation>Eksportuj Strony </translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="109"/>
        <source>Save As PDF</source>
        <translation>Zapisz Jako PDF</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="111"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Pliki PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="141"/>
        <location filename="../src/ExportPageDialog.cpp" line="168"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Nie można zapisać do pliku:</translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="141"/>
        <location filename="../src/ExportPageDialog.cpp" line="168"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>Plik może być tylko do odczytu lub używany przez inną aplikację.</translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <location filename="../src/FileSettings.ui" line="14"/>
        <source>Document Properties</source>
        <translation>Właściwości Dokumentu</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="37"/>
        <source>Document Info</source>
        <translation>Informacja o Dokumencie</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="43"/>
        <source>PDF Information</source>
        <translation>Informacje o PDF</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="49"/>
        <source>Title</source>
        <translation>Tytuł</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="59"/>
        <source>Subject</source>
        <translation>Temat</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="69"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="99"/>
        <source>Keywords</source>
        <translation>Słowa Kluczowe</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="79"/>
        <source>Creator</source>
        <translation>Kreator</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="89"/>
        <source>Producer</source>
        <translation>Producent</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="113"/>
        <source>Security</source>
        <translation>Bezpieczeństwo</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="225"/>
        <source>Printing the document</source>
        <translation>Drukowanie dokumentu</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="212"/>
        <source>Print a high resolution version of the document</source>
        <translation>Drukuj wysokiej jakości wersję dokumentu</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="290"/>
        <source>Modifying document</source>
        <translation>Modyfikowanie dokumentu</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="238"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Wypełnij isniejące pola formularzy i podpisów</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="303"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Zarządzaj Stronami i Zakładkami</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="145"/>
        <source>No Encryption</source>
        <translation>Brak Szyfrowania</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="150"/>
        <source>Password Encryption</source>
        <translation>Szyfrowanie Hasła</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="158"/>
        <source>Change</source>
        <translation>Zmień</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="184"/>
        <source>Permissions</source>
        <translation>Uprawnienia</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="199"/>
        <source>Extract the content of the document</source>
        <translation>Wyodrębnij treść dokumentu</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="251"/>
        <source>Content copying for accessibility</source>
        <translation>Kopiowanie treści dla ułatwienia dostępu</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="277"/>
        <source>Commenting</source>
        <translation>Komentowanie</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="320"/>
        <source>Initial View</source>
        <translation>Widok Początkowy</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="342"/>
        <source>Page Mode:</source>
        <translation>Tryb Strony:</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="350"/>
        <source>Page Only</source>
        <translation>Tylko Strona</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="355"/>
        <source>Bookmarks Panel</source>
        <translation>Panel Zakładek</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="360"/>
        <source>Pages Panel</source>
        <translation>Panel Stron</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="375"/>
        <source>Attachments Panel</source>
        <translation>Panel Załączników</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="417"/>
        <source>Run JavaScript on Document Open</source>
        <translation>Uruchom JavaScript przy Otwarciu Dokumentu</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="442"/>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="449"/>
        <source>Edit</source>
        <translation>Edytuj</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="456"/>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="370"/>
        <source>Layers Panel</source>
        <translation>Panel Warstw</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="365"/>
        <source>Full Screen</source>
        <translation>Pełny Ekran</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="396"/>
        <source>Open to Page:</source>
        <translation>Otwórz na Stronie:</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="410"/>
        <source>of :</source>
        <translation>z:</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="483"/>
        <source>Fonts</source>
        <translation>Czcionki</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="499"/>
        <source>Fonts used in this document</source>
        <translation>Czcionki w tym dokumencie</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.cpp" line="420"/>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.cpp" line="421"/>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation>Dokument jest chroniony. Proszę wpisać hasło uprawnień:</translation>
    </message>
    <message>
        <location filename="../src/FileSettings.cpp" line="438"/>
        <source>Incorrect password. Please input the owner password.</source>
        <translation>Nieprawidłowe hasło.Proszę wpisać hasło właściciela.</translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="14"/>
        <source>Insert Pages</source>
        <translation>Wstaw Strony</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="26"/>
        <source>Before page</source>
        <translation>Przed stroną</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="78"/>
        <source>After page</source>
        <translation>Po stronie</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="178"/>
        <source>Page Range</source>
        <translation>Zakres Stron</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="184"/>
        <source>All Pages</source>
        <translation>Wszystkie Strony</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="194"/>
        <source>Pages</source>
        <translation>Strony</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="220"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Przykład: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="230"/>
        <source>Import Bookmarks</source>
        <translation>Importuj Zakładki</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="130"/>
        <source>File Name</source>
        <translation>Nazwa Pliku</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="165"/>
        <source>Browse</source>
        <translation>Przeglądaj</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="145"/>
        <location filename="../src/ImportPageDialog.cpp" line="181"/>
        <source>Total pages :</source>
        <translation>Liczba stron:</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="20"/>
        <source>Position</source>
        <translation>Pozycja</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="107"/>
        <source>After last page</source>
        <translation>Po ostatniej stronie</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="58"/>
        <source>Before first page</source>
        <translation>Przed pierwszą stroną</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="10"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="105"/>
        <source>Open File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="105"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Pliki PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="135"/>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="136"/>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation>Dokument jest chroniony. Proszę wpisać Hasło Otwarcia Dokumentu:</translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="174"/>
        <source>Error read: This PDF is protected.</source>
        <translation>Błąd wczytywania: PDF jest chroniony.</translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <location filename="../src/forms/javascripteditdialog.ui" line="14"/>
        <source>Java Script Editor</source>
        <translation>Edytor JavaScript</translation>
    </message>
    <message>
        <location filename="../src/forms/javascripteditdialog.ui" line="20"/>
        <source>Function Name</source>
        <translation>Nazwa Funkcji</translation>
    </message>
    <message>
        <location filename="../src/forms/javascripteditdialog.ui" line="32"/>
        <source>Java Script</source>
        <translation>JavaScript</translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <source>Options</source>
        <translation type="vanished">Opcje</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="250"/>
        <source> ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="567"/>
        <source>Smooth text and images</source>
        <translation>Płynny tekst i obrazy</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="266"/>
        <source>Time before a move or resize starts:</source>
        <translation>Rozpoczęcie ruchu i zmiany rozmiaru po:</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="279"/>
        <source>Select item by hovering the mouse</source>
        <translation>Zaznacz element przenosząc myszkę</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="46"/>
        <source>Saving Documents</source>
        <translation>Zapisywanie Dokumentów</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="86"/>
        <source>Create backup file</source>
        <translation>Utwórz kopię pliku</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="72"/>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation>Wybierz folder dokumentów dla &quot;Zapisz Jako&quot;</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="59"/>
        <source>Last used folder</source>
        <translation>Ostatnio używany folder</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="64"/>
        <source>Original documents folder</source>
        <translation>Folder oryginalnych dokumentów</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="195"/>
        <source>Required field highlight color</source>
        <translation>Kolor wyróżnienia wymaganych pól</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="181"/>
        <source>Highlight color</source>
        <translation>Kolor wyróżnienia</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="318"/>
        <source>Default font</source>
        <translation>Domyślna czcionka</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="673"/>
        <source>Built-in</source>
        <translation>Wbudowany</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="659"/>
        <source>Please choose the interface language</source>
        <translation>Proszę wybrać język interfejsu</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="623"/>
        <location filename="../src/mainoptionsdialog.ui" line="694"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation>Wymagane jest ponowne uruchomienie programu, aby wprowadzić zmiany.</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="760"/>
        <source>Never</source>
        <translation>Nigdy</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="765"/>
        <source>Weekly</source>
        <translation>Co Tydzień</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="770"/>
        <source>Monthly</source>
        <translation>Co Miesiąc</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="746"/>
        <source>Check for Updates Automatically</source>
        <translation>Sprawdź Aktualizacje Automatycznie</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="79"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="379"/>
        <source>Color</source>
        <translation>Kolor</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="330"/>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="17"/>
        <source>Settings</source>
        <translation>Ustawienia</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="96"/>
        <source>History</source>
        <translation>Historia</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="108"/>
        <source>Restore last session when application start</source>
        <translation>Przywróć ostatnią sesję po uruchomieniu aplikacji</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="115"/>
        <source>Restore last view settings when reopening</source>
        <translation>Przywróć ustawienia ostatniego widoku po ponownym otwarciu</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="125"/>
        <source>Enable JavaScript</source>
        <translation>Włącz JavaScript</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="188"/>
        <source> Always hide document message bar </source>
        <translation> Zawsze ukrywaj pasek wiadomości dokumentu</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="438"/>
        <source>Default Layout and Zoom</source>
        <translation>Domyślny Układ i Powiększenie</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="444"/>
        <source>Default page layout</source>
        <translation>Domyślny układ strony</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="462"/>
        <location filename="../src/mainoptionsdialog.ui" line="539"/>
        <source>Automatic</source>
        <translation>Automatyczny</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="544"/>
        <source>Single Page</source>
        <translation>Pojedyncza Strona</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="549"/>
        <source>Facing Pages</source>
        <translation>Strony Przeciwległe</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="451"/>
        <source>Zoom</source>
        <translation>Powiększenie</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="467"/>
        <source>Actual Size</source>
        <translation>Rzeczywisty Rozmiar</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="472"/>
        <source>Fit Page</source>
        <translation>Dopasuj do Strony</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="477"/>
        <source>Fit Width</source>
        <translation>Dopasuj do Szerokości</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="482"/>
        <source>25%</source>
        <translation>25%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="487"/>
        <source>50%</source>
        <translation>50%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="492"/>
        <source>75%</source>
        <translation>75%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="497"/>
        <source>100%</source>
        <translation>100%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="502"/>
        <source>125%</source>
        <translation>125%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="507"/>
        <source>150%</source>
        <translation>150%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="512"/>
        <source>200%</source>
        <translation>200%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="517"/>
        <source>300%</source>
        <translation>300%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="522"/>
        <source>400%</source>
        <translation>400%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="527"/>
        <source>600%</source>
        <translation>600%</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="421"/>
        <location filename="../src/mainoptionsdialog.ui" line="573"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="580"/>
        <source>Bitmap Images</source>
        <translation>Obrazy Map Bitowych</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="587"/>
        <source>Vector Images</source>
        <translation>Obrazy Wektorowe</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="409"/>
        <source>Replace Document Colors</source>
        <translation>Zamień Kolory Dokumentu</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="428"/>
        <source>Page Background</source>
        <translation>Tło Strony</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="557"/>
        <source> Always show Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="610"/>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="616"/>
        <source>Fusion Dark Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="835"/>
        <source>toolBar</source>
        <translation>Pasek Narzędzi</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="877"/>
        <location filename="../src/mainoptionsdialog.ui" line="880"/>
        <source>System</source>
        <translation>System</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="892"/>
        <source>Language</source>
        <translation>Język</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="904"/>
        <source>Update</source>
        <translation>Aktualizacja</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="916"/>
        <source>Forms</source>
        <translation>Formularze</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="928"/>
        <source>Editing</source>
        <translation>Edytowanie</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="940"/>
        <source>Display</source>
        <translation>Wyświetlanie</translation>
    </message>
    <message>
        <source>T_Select directory</source>
        <translation type="vanished">Wybierz katalog</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="293"/>
        <source>Select directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="584"/>
        <source>Arabic</source>
        <translation>Arabski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="585"/>
        <source>Armenian</source>
        <translation>Armeński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="586"/>
        <source>Bulgarian</source>
        <translation>Bułgarski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="587"/>
        <source>Catalan</source>
        <translation>Kataloński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="588"/>
        <source>Chinese-Simplified</source>
        <translation>Chiński-Uproszczony</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="589"/>
        <source>Chinese-Traditional</source>
        <translation>Chiński-Tradycyjny</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="590"/>
        <source>Czech</source>
        <translation>Czeski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="591"/>
        <source>Danish</source>
        <translation>Duński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="592"/>
        <source>Dutch</source>
        <translation>Holenderski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="593"/>
        <source>English</source>
        <translation>Angielski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="594"/>
        <source>Estonian</source>
        <translation>Estoński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="595"/>
        <source>Finnish</source>
        <translation>Fiński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="596"/>
        <source>French</source>
        <translation>Francuski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="597"/>
        <source>Galician</source>
        <translation>Galicyjski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="598"/>
        <source>German</source>
        <translation>Niemiecki</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="599"/>
        <source>Greek</source>
        <translation>Grecki</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="600"/>
        <source>Hebrew</source>
        <translation>Hebrajski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="601"/>
        <source>Hungarian</source>
        <translation>Węgierski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="602"/>
        <source>Irish</source>
        <translation>Irlandzki</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="603"/>
        <source>Italian</source>
        <translation>Włoski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="604"/>
        <source>Japanese</source>
        <translation>Japoński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="605"/>
        <source>Korean</source>
        <translation>Koreański</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="606"/>
        <source>Latvian</source>
        <translation>Łotewski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="607"/>
        <source>Lithuanian</source>
        <translation>Litewski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="608"/>
        <source>Norwegian</source>
        <translation>Norweski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="609"/>
        <source>Norwegian-Nynorsk</source>
        <translation>Norweski-Nynorsk</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="610"/>
        <source>Polish</source>
        <translation>Polski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="611"/>
        <source>Portuguese</source>
        <translation>Portugalski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="612"/>
        <source>Portuguese-Brazilian</source>
        <translation>Portugalski-Brazylijski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="613"/>
        <source>Romanian</source>
        <translation>Rumuński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="614"/>
        <source>Russian</source>
        <translation>Rosyjski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="615"/>
        <source>Serbian</source>
        <translation>Serbski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="616"/>
        <source>Slovak</source>
        <translation>Słowacki</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="617"/>
        <source>Slovenian</source>
        <translation>Słoweński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="618"/>
        <source>Spanish</source>
        <translation>Hiszpański</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="619"/>
        <source>Swedish</source>
        <translation>Szwedzki</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="620"/>
        <source>Thai</source>
        <translation>Tajski</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="621"/>
        <source>Turkish</source>
        <translation>Turecki</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="622"/>
        <source>Ukrainian</source>
        <translation>Ukraiński</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="623"/>
        <source>Valencian</source>
        <translation>Walencki</translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="624"/>
        <source>Vietnamese</source>
        <translation>Wietnamski</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="36"/>
        <source>File</source>
        <translation>Plik</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="46"/>
        <source>Export to</source>
        <translation>Eksportuj do</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="135"/>
        <location filename="../src/mainwindow.ui" line="1297"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="308"/>
        <source>Edit</source>
        <translation>Edytuj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="139"/>
        <source>Align Objects</source>
        <translation>Wyrównaj Obiekty</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="67"/>
        <location filename="../src/mainwindow.ui" line="1289"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="332"/>
        <source>View</source>
        <translation>Widok</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="163"/>
        <source>Document</source>
        <translation>Dokument</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="191"/>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="112"/>
        <source>Insert</source>
        <translation>Wstaw</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="178"/>
        <location filename="../src/mainwindow.ui" line="1313"/>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="101"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="398"/>
        <source>Comments</source>
        <translation>Komentarze</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="103"/>
        <location filename="../src/mainwindow.ui" line="1305"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="366"/>
        <source>Tools</source>
        <translation>Narzędzia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="672"/>
        <source>New</source>
        <translation>Nowy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="678"/>
        <location filename="../src/mainwindow.cpp" line="1701"/>
        <source>Create a new blank PDF</source>
        <translation>Utwórz pusty plik PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="681"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="217"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="292"/>
        <source>Open</source>
        <translation>Otwórz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="220"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Open a PDF or XPS file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="255"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="279"/>
        <source>Select text for copying and pasting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="282"/>
        <source>Alt+5</source>
        <translation>Alt+5</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="316"/>
        <source>PgUp</source>
        <translation>PgUp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="331"/>
        <source>PgDown</source>
        <translation>PgDown</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="398"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="445"/>
        <location filename="../src/mainwindow.cpp" line="1415"/>
        <source>Save</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="448"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="457"/>
        <source>Save the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="460"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="469"/>
        <location filename="../src/mainwindow.cpp" line="374"/>
        <location filename="../src/mainwindow.cpp" line="2713"/>
        <location filename="../src/mainwindow.cpp" line="2770"/>
        <source>Save As...</source>
        <translation>Zapisz Jako...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="472"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document with a new name&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <source>Save the document with a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="492"/>
        <source>Print</source>
        <translation>Drukuj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="495"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Drukuj (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Drukuj dokument&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="498"/>
        <source>Print the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="501"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="506"/>
        <location filename="../src/mainwindow.ui" line="509"/>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="512"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="520"/>
        <source>Exit</source>
        <translation>Wyjdź</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="569"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="572"/>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="590"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="593"/>
        <source>Select text for editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="596"/>
        <source>Alt+2</source>
        <translation>Alt+2</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="605"/>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="608"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Delete the currently selected object(s)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="617"/>
        <source>Delete the currently selected object(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="675"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <source>Ctrl+Shift+P</source>
        <translation>Ctrl+Shift+P</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="715"/>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="733"/>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="751"/>
        <source>Paste from the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="784"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="807"/>
        <source>Undo the last action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="825"/>
        <source>Redo the previously undone action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="843"/>
        <source>Send to Back selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="852"/>
        <source>Bring to Front</source>
        <translation>Przesuń na Wierzch</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="855"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Przesuń na Wierzch&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Przesuń na Wierzch zaznaczony obiekt.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="858"/>
        <source>Bring to Front selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="921"/>
        <source>Ctrl+Shift+L</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="932"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="937"/>
        <location filename="../src/mainwindow.ui" line="940"/>
        <source>Extract Pages...</source>
        <translation>Wyodrębnij Strony...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="945"/>
        <location filename="../src/mainwindow.ui" line="948"/>
        <source>Insert Pages...</source>
        <translation>Wstaw Strony...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="968"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Open window with document properties&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="976"/>
        <source>Open window with document properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="994"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="997"/>
        <source>Click the page to add a note at that position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1042"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1045"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new text to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1053"/>
        <source>Insert new text to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1056"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1065"/>
        <source>Image</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1068"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new image to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1076"/>
        <source>Insert new image to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1079"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1139"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new link to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1147"/>
        <source>Insert new link to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1333"/>
        <location filename="../src/mainwindow.ui" line="1336"/>
        <source>Open Object Inspector</source>
        <translation>Otwórz Inspektora Obiektów</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1341"/>
        <location filename="../src/mainwindow.ui" line="1344"/>
        <source>Crop Pages</source>
        <translation>Przytnij Strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1347"/>
        <source>Ctrl+K</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1356"/>
        <location filename="../src/mainwindow.ui" line="1359"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation>Obróć o 90 stopni Zgodnie z Zegarem</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1368"/>
        <location filename="../src/mainwindow.ui" line="1371"/>
        <location filename="../src/mainwindow.ui" line="1374"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation>Obróć o 90 stopni Przeciwnie do Zegara</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1379"/>
        <source>Export Form Data...</source>
        <translation type="unfinished">Eksportuj dane formularza...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1384"/>
        <source>Import Form Data...</source>
        <translation type="unfinished">Importuj dane formularza...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1389"/>
        <source>Export Comments Data...</source>
        <translation type="unfinished">Eksportuj dane...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1394"/>
        <source>Import Comments Data...</source>
        <translation type="unfinished">Importuj dane...</translation>
    </message>
    <message>
        <source>FDF</source>
        <translation type="vanished">FDF</translation>
    </message>
    <message>
        <source>Export Data...</source>
        <translation type="vanished">Eksportuj dane formularza...</translation>
    </message>
    <message>
        <source>Import Data...</source>
        <translation type="vanished">Importuj dane formularza...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="837"/>
        <source>Send to Back</source>
        <translation>Przesuń pod Spód</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="840"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Przesuń pod Spód&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Przesuń pod Spód zaznaczony obiekt.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="620"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1273"/>
        <source>Statusbar</source>
        <translation>Pasek Stanu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="295"/>
        <location filename="../src/mainwindow.ui" line="298"/>
        <source>First Page</source>
        <translation>Pierwsza Strona</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="310"/>
        <location filename="../src/mainwindow.ui" line="313"/>
        <source>Previous Page</source>
        <translation>Poprzednia Strona</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="325"/>
        <location filename="../src/mainwindow.ui" line="328"/>
        <source>Next Page</source>
        <translation>Następna Strona</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="336"/>
        <location filename="../src/mainwindow.ui" line="339"/>
        <source>Last Page</source>
        <translation>Ostatnia Strona</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="631"/>
        <source>Alt+Del</source>
        <translation>Alt+Del</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1174"/>
        <location filename="../src/mainwindow.ui" line="1177"/>
        <source>Check box</source>
        <translation>Pole wyboru</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1159"/>
        <location filename="../src/mainwindow.ui" line="1162"/>
        <source>Edit Box</source>
        <translation>Pole Edycji</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1186"/>
        <location filename="../src/mainwindow.ui" line="1189"/>
        <source>Radio button</source>
        <translation>Przycisk Radiowy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1210"/>
        <location filename="../src/mainwindow.ui" line="1213"/>
        <source>List box</source>
        <translation>Pole listy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1198"/>
        <location filename="../src/mainwindow.ui" line="1201"/>
        <source>Combo box</source>
        <translation>Pole kombi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1281"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="284"/>
        <source>Main</source>
        <translation>Główny</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1234"/>
        <location filename="../src/mainwindow.ui" line="1237"/>
        <source>Signature</source>
        <translation>Podpis</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="748"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Wklej (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Wklej ze Schowka&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="770"/>
        <location filename="../src/mainwindow.ui" line="773"/>
        <source>Set Fit to Page</source>
        <translation>Ustaw Dopasowanie do Strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1088"/>
        <location filename="../src/mainwindow.ui" line="1091"/>
        <source>Line</source>
        <translation>Linia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1100"/>
        <location filename="../src/mainwindow.ui" line="1103"/>
        <source>Rectangle</source>
        <translation>Prostokąt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1112"/>
        <location filename="../src/mainwindow.ui" line="1115"/>
        <source>Ellipse</source>
        <translation>Elipsa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="694"/>
        <location filename="../src/mainwindow.ui" line="697"/>
        <source>Print Preview</source>
        <translation>Podgląd Wydruku</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="867"/>
        <location filename="../src/mainwindow.ui" line="870"/>
        <source>Align Left</source>
        <translation>Wyrównaj do Lewej</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="879"/>
        <location filename="../src/mainwindow.ui" line="882"/>
        <source>Align Right</source>
        <translation>Wyrównaj do Prawej</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="891"/>
        <location filename="../src/mainwindow.ui" line="894"/>
        <source>Align Top</source>
        <translation>Wyrównaj do Góry</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="957"/>
        <location filename="../src/mainwindow.ui" line="960"/>
        <source>Align Bottom</source>
        <translation>Wyrównaj do Dołu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="551"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <source>Reduce Page Thumbnails</source>
        <translation>Zmniejsz Miniatury Stron</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="543"/>
        <location filename="../src/mainwindow.ui" line="546"/>
        <source>Enlarge Page Thumbnails</source>
        <translation>Powiększ Miniatury Stron</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <location filename="../src/mainwindow.ui" line="689"/>
        <source>Images</source>
        <translation>Obrazy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="899"/>
        <location filename="../src/mainwindow.ui" line="902"/>
        <source>Insert Blank Pages</source>
        <translation>Wstaw Puste Strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="965"/>
        <source>Properties</source>
        <translation>Właściwości</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="982"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1150"/>
        <source>Ctrl+L</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1165"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1252"/>
        <source>Home page</source>
        <translation>Strona domowa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1257"/>
        <source>Register...</source>
        <translation>Zarejestruj...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1262"/>
        <source>Check for Update</source>
        <translation>Sprawdź Aktualizacje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="801"/>
        <source>Undo</source>
        <translation>Cofnij</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="804"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cofnij (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cofnij ostatnią akcję&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="810"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1124"/>
        <location filename="../src/mainwindow.ui" line="1127"/>
        <source>Pencil</source>
        <translation>Ołówek</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1222"/>
        <location filename="../src/mainwindow.ui" line="1225"/>
        <source>Button</source>
        <translation>Przycisk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="351"/>
        <location filename="../src/mainwindow.ui" line="354"/>
        <source>Zoom In</source>
        <translation>Powiększ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="357"/>
        <source>Ctrl++</source>
        <translation>Ctrl++</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="378"/>
        <location filename="../src/mainwindow.ui" line="381"/>
        <source>Zoom Out</source>
        <translation>Pomniejsz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="384"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="366"/>
        <location filename="../src/mainwindow.ui" line="369"/>
        <source>Actual Size</source>
        <translation>Rzeczywisty Rozmiar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="287"/>
        <location filename="../src/mainwindow.ui" line="290"/>
        <source>Settings</source>
        <translation>Ustawienia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <source>Contents</source>
        <translation>Spis Treści</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <location filename="../src/mainwindow.ui" line="395"/>
        <source>Highlight Fields</source>
        <translation>Wyróżnione Pola</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="252"/>
        <location filename="../src/mainwindow.ui" line="258"/>
        <source>Hand Tool</source>
        <translation>Narzędzie Dłoni</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="587"/>
        <source>Edit Text</source>
        <translation>Edytuj Tekst</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="915"/>
        <location filename="../src/mainwindow.ui" line="918"/>
        <source>Page layout</source>
        <translation>Układ strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="819"/>
        <source>Redo</source>
        <translation>Przywróć</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="822"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Przywróć (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Przywróć poprzednio cofniętą akcję.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="828"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="709"/>
        <source>Cut</source>
        <translation>Wytnij</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <source>Master PDF Editor</source>
        <translation>Master PDF Editor</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <location filename="../src/mainwindow.ui" line="1321"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="382"/>
        <source>Forms</source>
        <translation>Formularze</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="237"/>
        <location filename="../src/mainwindow.ui" line="240"/>
        <source>About</source>
        <translation>O Programie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="276"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="301"/>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>End</source>
        <translation>End</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="403"/>
        <location filename="../src/mainwindow.ui" line="406"/>
        <source>Reset Forms</source>
        <translation>Zresetuj Formularze</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="418"/>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Fit Page</source>
        <translation>Dopasuj do Strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Fit Width</source>
        <translation>Dopasuj do Szerokości</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="523"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="535"/>
        <location filename="../src/mainwindow.ui" line="538"/>
        <source>Facing Pages</source>
        <translation>Strony Przeciwległe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="625"/>
        <location filename="../src/mainwindow.ui" line="628"/>
        <source>Delete Pages</source>
        <translation>Usuń Strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="643"/>
        <location filename="../src/mainwindow.ui" line="646"/>
        <source>Edit Forms</source>
        <translation>Edytuj Formularze</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="663"/>
        <source>Ctrl+F11</source>
        <translation>Ctrl+F11</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Nowy (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Utwórz pusty plik PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="712"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Wytnij (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Wytnij zaznaczone Obiekty i umieść w Schowku&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="718"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="727"/>
        <source>Copy</source>
        <translation>Kopiuj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="730"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Kopiuj (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Kopiuj zaznaczone Obiekty i umieść w Schowku&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="483"/>
        <location filename="../src/mainwindow.ui" line="736"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="745"/>
        <source>Paste</source>
        <translation>Wklej</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="754"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="759"/>
        <location filename="../src/mainwindow.ui" line="762"/>
        <source>Select All</source>
        <translation>Zaznacz Wszystkie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="765"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="566"/>
        <source>Edit Document</source>
        <translation>Edytuj Dokument</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="575"/>
        <source>Alt+1</source>
        <translation>Alt+1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1136"/>
        <source>Link</source>
        <translation>Link</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1006"/>
        <location filename="../src/mainwindow.ui" line="1009"/>
        <source>Highlight Text</source>
        <translation>Wyróżniony Tekst</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="991"/>
        <source>Add Sticky Note</source>
        <translation>Dodaj Notatkę Sticky</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1018"/>
        <location filename="../src/mainwindow.ui" line="1021"/>
        <source>Strikeout Text</source>
        <translation>Przekreślony Tekst</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1030"/>
        <location filename="../src/mainwindow.ui" line="1033"/>
        <source>Underline Text</source>
        <translation>Podreślony Tekst</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="273"/>
        <source>Select Text</source>
        <translation>Zaznacz Tekst</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="649"/>
        <source>Alt+3</source>
        <translation>Alt+3</translation>
    </message>
    <message>
        <source>Ctrl+Shift+S</source>
        <translation type="vanished">Ctrl+Shift+S</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1242"/>
        <source>HTML</source>
        <translation>HTML</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="778"/>
        <location filename="../src/mainwindow.ui" line="781"/>
        <source>Find</source>
        <translation>Znajdź</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="789"/>
        <location filename="../src/mainwindow.ui" line="792"/>
        <source>Find Next</source>
        <translation>Znajdź Następne</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="926"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Rotate Pages</source>
        <translation>Obróć Strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="907"/>
        <location filename="../src/mainwindow.ui" line="910"/>
        <source>Move Pages</source>
        <translation>Przenieś Strony</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="261"/>
        <source>Alt+4</source>
        <translation>Alt+4</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1235"/>
        <source>Open failed</source>
        <translation>Błąd otwierania</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1236"/>
        <source>Cannot open file :
</source>
        <translation>Nie można otworzyć pliku:
</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="38"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="269"/>
        <source>Empty recent files list</source>
        <translation>Wyczyść listę ostatnich plików</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="66"/>
        <source>Prev/Next</source>
        <translation>Poprzedni/Następny</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="89"/>
        <source>Edit Tools</source>
        <translation>Edytuj Narzędzia</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="145"/>
        <source>Page :</source>
        <translation>Strona:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="294"/>
        <source>Open a PDF file</source>
        <translation>Owórz plik PDF</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="355"/>
        <location filename="../src/mainwindow.cpp" line="2704"/>
        <location filename="../src/mainwindow.cpp" line="2761"/>
        <source>untitled</source>
        <translation>bez nazwy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="374"/>
        <source>PDF Files (*.pdf)</source>
        <translation>Pliki PDF (*.pdf)</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="35"/>
        <location filename="../src/mainwindow.cpp" line="2063"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="266"/>
        <source>Recent Files</source>
        <translation>Ostatnie Pliki</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="188"/>
        <location filename="../src/mainwindow.cpp" line="244"/>
        <source>There was an error opening the document !</source>
        <translation>Wystąpił błąd podczas otwierania dokumentu!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="315"/>
        <source>Saving in XPS is temporarily not supported.
Choose PDF file name for saving.</source>
        <translation>Zapisywanie XPS jest tymczasowo nieobsługiwane.
Wybierz nazwę pliku PDF do zapisu.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="451"/>
        <source>Export completed</source>
        <translation>Eksportowanie zakończone</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1409"/>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation>Dokument %s został zmodyfikowany.
Chcesz zapisać zmiany?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1416"/>
        <source>Close Without Saving</source>
        <translation>Nie Zapisuj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1417"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2713"/>
        <location filename="../src/mainwindow.cpp" line="2734"/>
        <location filename="../src/mainwindow.cpp" line="2737"/>
        <location filename="../src/mainwindow.cpp" line="2770"/>
        <location filename="../src/mainwindow.cpp" line="2790"/>
        <location filename="../src/mainwindow.cpp" line="2793"/>
        <source>FDF Files (*.fdf)</source>
        <translation>Pliki FDF (*.fdf)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="284"/>
        <source>The unregistered version will insert a watermark</source>
        <translation>Niezarejestrowana wersja umieści znak wodny</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1512"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Pojawił się błąd podczas weryfikacji podpisu!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="331"/>
        <location filename="../src/mainwindow.cpp" line="388"/>
        <source>Save failed</source>
        <translation>Błąd zapisu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="41"/>
        <source>Ctrl+Shift++</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="42"/>
        <source>Ctrl+Shift+-</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="332"/>
        <location filename="../src/mainwindow.cpp" line="389"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Nie można zapisać pliku:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="332"/>
        <location filename="../src/mainwindow.cpp" line="389"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>
Plik może być tylko do odczytu lub używany przez inną aplikację.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_update.cpp" line="32"/>
        <source>Your version already has the last update!</source>
        <translation>Twoja wersja ma najnowszą aktualizację!</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_update.cpp" line="40"/>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation>Nowa Wersja Jest Dostępna!
Chcesz Pobrać Teraz?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="254"/>
        <location filename="../src/mainwindow.cpp" line="257"/>
        <location filename="../src/mainwindow.cpp" line="2734"/>
        <location filename="../src/mainwindow.cpp" line="2737"/>
        <location filename="../src/mainwindow.cpp" line="2790"/>
        <location filename="../src/mainwindow.cpp" line="2793"/>
        <source>Open File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="254"/>
        <location filename="../src/mainwindow.cpp" line="257"/>
        <source>All Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps)</source>
        <translation>Wszystkie Pliki (*.pdf *.xps);;Pliki PDF (*.pdf);;Pliki XPS (*.xps)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="657"/>
        <location filename="../src/mainwindow.ui" line="660"/>
        <location filename="../src/mainwindow.ui" line="1330"/>
        <source>Object Inspector</source>
        <translation>Inspektor Obiektu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow_tool_bars.cpp" line="419"/>
        <source>Toolbars</source>
        <translation>Paski Narzędzi</translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="75"/>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="131"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="351"/>
        <source>Zoom</source>
        <translation>Powiększenie</translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="14"/>
        <source>Move Pages</source>
        <translation>Przenieś Strony</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="26"/>
        <source>Page Range</source>
        <translation>Zakres Stron</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="32"/>
        <source>Pages</source>
        <translation>Strony</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Przykład: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="78"/>
        <source>Current Page</source>
        <translation>Bieżąca Strona</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="88"/>
        <source>Pages from</source>
        <translation>Od strony</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="114"/>
        <source>to:</source>
        <translation>do:</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="140"/>
        <source>Destination</source>
        <translation>Przeznaczenie</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="152"/>
        <source>To:</source>
        <translation>Do:</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="162"/>
        <source>Page</source>
        <translation>Strona</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="211"/>
        <source>First</source>
        <translation>Pierwsza</translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="218"/>
        <source>Last</source>
        <translation>Ostatnia</translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <location filename="../src/NewPageDialog.ui" line="20"/>
        <source>Page Size</source>
        <translation>Rozmiar Strony</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="191"/>
        <source>Width</source>
        <translation>Szerokość</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="228"/>
        <source>Height</source>
        <translation>Wysokość</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="30"/>
        <source>A0</source>
        <translation>A0</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="35"/>
        <source>A1</source>
        <translation>A1</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="40"/>
        <source>A2</source>
        <translation>A2</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="45"/>
        <source>A3</source>
        <translation>A3</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="50"/>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="55"/>
        <source>A5</source>
        <translation>A5</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="60"/>
        <source>A6</source>
        <translation>A6</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="65"/>
        <source>A7</source>
        <translation>A7</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="70"/>
        <source>A8</source>
        <translation>A8</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="75"/>
        <source>A9</source>
        <translation>A9</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="80"/>
        <source>A10</source>
        <translation>A10</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="85"/>
        <source>Letter</source>
        <translation>Koperta</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="90"/>
        <source>Tabloid</source>
        <translation>Tabloid</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="95"/>
        <source>B0</source>
        <translation>B0</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="100"/>
        <source>B1</source>
        <translation>B1</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="105"/>
        <source>B2</source>
        <translation>B2</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="110"/>
        <source>B3</source>
        <translation>B3</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="115"/>
        <source>B4</source>
        <translation>B4</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="120"/>
        <source>B5</source>
        <translation>B5</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="125"/>
        <source>Statement</source>
        <translation>Deklaracja</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="130"/>
        <source>Executive</source>
        <translation>Executive</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="135"/>
        <source>Folio</source>
        <translation>Folio</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="140"/>
        <source>Quarto</source>
        <translation>Quarto</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="145"/>
        <source>Note</source>
        <translation>Notatka</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="150"/>
        <source>ANSI C</source>
        <translation>ANSI C</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="155"/>
        <source>ANSI D</source>
        <translation>ANSI D</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="160"/>
        <source>ANSI E</source>
        <translation>ANSI E</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="165"/>
        <source>ANSI F</source>
        <translation>ANSI F</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="170"/>
        <source>Custom page size</source>
        <translation>Niestandardowy rozmiar strony</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="215"/>
        <source>Portrait</source>
        <translation>Pionowo</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="220"/>
        <source>Landscape</source>
        <translation>Poziomo</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="264"/>
        <source>Units</source>
        <translation>Jednostki</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="272"/>
        <source>points</source>
        <translation>piksele</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="277"/>
        <source>inch</source>
        <translation>cale</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="282"/>
        <source>millimeter</source>
        <translation>milimetry</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="293"/>
        <source>Contents Size</source>
        <translation>Rozmiar Zawartości</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="305"/>
        <source>Left margin</source>
        <translation>Lewy margines</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="345"/>
        <source>Top margin</source>
        <translation>Górny margines</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="325"/>
        <source>Right margin</source>
        <translation>Prawy margines</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="365"/>
        <source>Bottom margin</source>
        <translation>Dolny margines</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="388"/>
        <source>Position</source>
        <translation>Pozycja</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="394"/>
        <source>Before current page</source>
        <translation>Przed bieżącą stroną</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="411"/>
        <source>After current page</source>
        <translation>Po bieżącej stronie</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="418"/>
        <source>After last page</source>
        <translation>Po ostatniej stronie</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="404"/>
        <source>Before first page</source>
        <translation>Przed pierwszą stroną</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="428"/>
        <source>Number of pages</source>
        <translation>Liczba stron</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="454"/>
        <source>Page(s)</source>
        <translation>Strona(y)</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="434"/>
        <source>Create</source>
        <translation>Utwórz</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.cpp" line="142"/>
        <source> px</source>
        <translation>px</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.cpp" line="166"/>
        <source> in</source>
        <translation>&quot;</translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.cpp" line="188"/>
        <source> mm</source>
        <translation>mm</translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="60"/>
        <source>No Properties
There is no object selections.</source>
        <translation>Brak Właściwości
Nie wybrano obiektu.</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="308"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2710"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2929"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1617"/>
        <source>Text</source>
        <translation>Tekst</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="142"/>
        <source>Property</source>
        <translation>Właściwość</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="147"/>
        <source>Value</source>
        <translation>Wartość</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="443"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="653"/>
        <source>Add</source>
        <translation>Dodaj</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="453"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2392"/>
        <source>Actions</source>
        <translation>Akcje</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="475"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1681"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1715"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1787"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1843"/>
        <source>Edit</source>
        <translation>Edytuj</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="485"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="676"/>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="541"/>
        <source>Up Label</source>
        <translation>Górna Etykieta</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="548"/>
        <source>Behavior</source>
        <translation>Zachowanie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="562"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1108"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1270"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1425"/>
        <source>None</source>
        <translation>Brak</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="567"/>
        <source>Push</source>
        <translation>Wciśnięcie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="572"/>
        <source>Outline</source>
        <translation>Kontur</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="577"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1113"/>
        <source>Invert</source>
        <translation>Odwrócenie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="585"/>
        <source>Down Label</source>
        <translation>Dolna Etykieta</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="595"/>
        <source>RollOver Label</source>
        <translation>Etykieta Najechania</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="631"/>
        <source>Item</source>
        <translation>Element</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="660"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="981"/>
        <source>Export Value</source>
        <translation>Eksportuj Wartość</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="705"/>
        <source>Up</source>
        <translation>W Górę</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="718"/>
        <source>Down</source>
        <translation>W Dół</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="725"/>
        <source>Sort Items</source>
        <translation>Sortuj Elementy</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="732"/>
        <source>Commit selected value immediately</source>
        <translation>Przydziel zaznaczoną wartość natychmiast</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="739"/>
        <source>Multiple selection</source>
        <translation>Wybór wielokrotny</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="746"/>
        <source>Allow user to enter custom text</source>
        <translation>Pozwól na wpisanie niestandardowego tekstu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="779"/>
        <source>Password</source>
        <translation>Hasło</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="786"/>
        <source>Scrollable</source>
        <translation>Przewijalny</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="793"/>
        <source>Check spelling</source>
        <translation>Sprawdzanie pisowni</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="800"/>
        <source>Limit to</source>
        <translation>Ogranicz do</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="814"/>
        <source>chars</source>
        <translation>znaków</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="821"/>
        <source>Split into</source>
        <translation>Podziel na</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="835"/>
        <source>Allow Rich Text formatting</source>
        <translation>Zezwól na Formatowanie Tekstu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="845"/>
        <source>Multi-line</source>
        <translation>Wiele linii</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="852"/>
        <source>cells</source>
        <translation>komórki</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="860"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2167"/>
        <source>Left</source>
        <translation>Lewa</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="865"/>
        <source>Center</source>
        <translation>Wyśrodkuj</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="870"/>
        <source>Right</source>
        <translation>Do Prawej</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="878"/>
        <source>Default Value</source>
        <translation>Domyślna Wartość</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="885"/>
        <source>Alignment</source>
        <translation>Wyrównanie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="924"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2278"/>
        <source>Style</source>
        <translation>Styl</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="935"/>
        <source>Check</source>
        <translation>Ptaszek</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="940"/>
        <source>Circle</source>
        <translation>Koło</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="945"/>
        <source>Cross</source>
        <translation>Krzyżyk</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="950"/>
        <source>Diamond</source>
        <translation>Diament</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="955"/>
        <source>Square</source>
        <translation>Kwadrat</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="960"/>
        <source>Star</source>
        <translation>Gwiazda</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1004"/>
        <source>Checked by Default</source>
        <translation>Domyślnie Zaznaczone</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1050"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2700"/>
        <source>Line Thickness</source>
        <translation>Grubość Linii</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1064"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2650"/>
        <source>Border Color</source>
        <translation>Kolor Ramki</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1071"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2693"/>
        <source>Line Style</source>
        <translation>Styl Linii</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1079"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2665"/>
        <source>Solid</source>
        <translation>Pełna</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1084"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2670"/>
        <source>Dashed</source>
        <translation>Przerywana</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1089"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2685"/>
        <source>Underline</source>
        <translation>Podkreślona</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1097"/>
        <source>Highlight</source>
        <translation>Wyróżnienie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1118"/>
        <source>OutLine</source>
        <translation>Kontur</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1123"/>
        <source>Insert</source>
        <translation>Wciśnięcie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1157"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Podpis.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Brak dostępnych opcji&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1216"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2411"/>
        <source>Format</source>
        <translation>Formatowanie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1256"/>
        <source>Format category</source>
        <translation>Kategoria formatowania</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1275"/>
        <source>Number</source>
        <translation>Numer</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1280"/>
        <source>Percentage</source>
        <translation>Procent</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1285"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1290"/>
        <source>Time</source>
        <translation>Czas</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1295"/>
        <source>Special</source>
        <translation>Specjalna</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1300"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1455"/>
        <source>Custom</source>
        <translation>Niestandardowa</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1319"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1324"/>
        <source>1</source>
        <translation>1</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1329"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1334"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1339"/>
        <source>4</source>
        <translation>4</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1344"/>
        <source>5</source>
        <translation>5</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1349"/>
        <source>6</source>
        <translation>6</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1354"/>
        <source>7</source>
        <translation>7</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1359"/>
        <source>8</source>
        <translation>8</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1364"/>
        <source>9</source>
        <translation>9</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1369"/>
        <source>10</source>
        <translation>10</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1378"/>
        <source>1,234.56</source>
        <translation>1,234.56</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1383"/>
        <source>1234.56</source>
        <translation>1234.56</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1388"/>
        <source>1.234,56</source>
        <translation>1.234,56</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1393"/>
        <source>1234,56</source>
        <translation>1234,56</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1407"/>
        <source>Currency Symbol</source>
        <translation>Symbol Waluty</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1430"/>
        <source>Dollar ($)</source>
        <translation>Dolar ($)</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1435"/>
        <source>Euro (€)</source>
        <translation>Euro (€)</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1440"/>
        <source>Pound (£)</source>
        <translation>Funt (£)</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1445"/>
        <source>Yen (¥)</source>
        <translation>Jen (¥)</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1450"/>
        <source>Ruble (Руб)</source>
        <translation>Rubel (Руб)</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1476"/>
        <source>Show parentheses</source>
        <translation>Pokaż nawiasy</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1496"/>
        <source>Decimal Places</source>
        <translation>Miejsca Dziesiętne</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1503"/>
        <source>Separation Style</source>
        <translation>Styl Separatora</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1510"/>
        <source>Use red text</source>
        <translation>Użyj czerwonego tekstu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1527"/>
        <source>Date Options</source>
        <translation>Opcje Daty</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1582"/>
        <source>Time Options</source>
        <translation>Opcje Czasu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1596"/>
        <source>Special Options</source>
        <translation>Opcje Specjalne</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1654"/>
        <source>Format Script</source>
        <translation>Skrypt Formatowania</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1688"/>
        <source>KeyStroke Script</source>
        <translation>Skrypt Naciśnięcia Klawisza</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1739"/>
        <source>Validate</source>
        <translation>Weryfikacja</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1760"/>
        <source>Validation Script</source>
        <translation>Skrypt Weryfikacji</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1795"/>
        <source>Calculate</source>
        <translation>Kalkulacja</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1816"/>
        <source>Calculation Script</source>
        <translation>Skrypt Kalkulowania</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1945"/>
        <source>Full text</source>
        <translation>Pełny tekst</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1950"/>
        <source>Stroke Text</source>
        <translation>Obramowany Tekst</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1955"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2490"/>
        <source>Full and Stroke</source>
        <translation>Pełny i Obramowany</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1960"/>
        <source>Invisible</source>
        <translation>Niewidoczny</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1974"/>
        <source>Full Color</source>
        <translation>Pełny Kolor</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2000"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2558"/>
        <source>Line Width</source>
        <translation>Szerokość Linii</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2029"/>
        <source>Character spacing</source>
        <translation>Odstępy między znakami</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2036"/>
        <source>Word spacing</source>
        <translation>Odstępy między wyrazami</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2070"/>
        <source>F</source>
        <translation>F</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2096"/>
        <source>D</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2106"/>
        <source>E</source>
        <translation>E</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2116"/>
        <source>A</source>
        <translation>A</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2126"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2136"/>
        <source>B</source>
        <translation>B</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2187"/>
        <source>Top</source>
        <translation>Góra</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2675"/>
        <source>Beveled</source>
        <translation>Wypukła</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2680"/>
        <source>Inset</source>
        <translation>Wklęsła</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2735"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2799"/>
        <source>ToolTip</source>
        <translation>Etykietka Narzędzia</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2815"/>
        <source>Orientation</source>
        <translation>Orientacja</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2823"/>
        <source>0 Degrees</source>
        <translation>0 Stopni</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2828"/>
        <source>90 Degrees</source>
        <translation>90 Stopni</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2833"/>
        <source>180 Degrees</source>
        <translation>180 Stopni</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2838"/>
        <source>270 Degrees</source>
        <translation>270 Stopni</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2859"/>
        <source>Read Only</source>
        <translation>Tylko do Odczytu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2874"/>
        <source>Visible</source>
        <translation>Widoczne</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2879"/>
        <source>Hidden</source>
        <translation>Ukryte</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2884"/>
        <source>Visible but doesn&apos;t print</source>
        <translation>Widoczne, bez drukowania</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2889"/>
        <source>Hidden but printable</source>
        <translation>Ukryte, z drukowaniem</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2897"/>
        <source>Required</source>
        <translation>Wymagane</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2907"/>
        <source>Locked</source>
        <translation>Zablokowane</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2936"/>
        <source>Subject</source>
        <translation type="unfinished">Temat</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2984"/>
        <source>Author</source>
        <translation type="unfinished">Autor</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1880"/>
        <source>Font Family</source>
        <translation>Rodzina Czcionek</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1909"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2722"/>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1925"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2460"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="3004"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2204"/>
        <source>Coordinates</source>
        <translation>Współrzędne</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2212"/>
        <source>Absolute</source>
        <translation>Bezwględne</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2217"/>
        <source>Relative</source>
        <translation>Względne</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2237"/>
        <source>Geometry</source>
        <translation>Geometria</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2259"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2764"/>
        <source>Font</source>
        <translation>Czcionka</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2297"/>
        <source>Matrix</source>
        <translation>Matryca</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2316"/>
        <source>Cliping Path</source>
        <translation>Ścieżka Podcinania</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2335"/>
        <source>General</source>
        <translation>Ogólne</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2354"/>
        <source>Appearance</source>
        <translation>Wygląd</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2373"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2430"/>
        <source>Options</source>
        <translation>Opcje</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2480"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2498"/>
        <source>Full</source>
        <translation>Pełny</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2485"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2533"/>
        <source>Stroke</source>
        <translation>Obramowany</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2523"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2545"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2751"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2961"/>
        <source>Color</source>
        <translation>Kolor</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2625"/>
        <source>Borders and Colors</source>
        <translation>Obramowania i Kolory</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2632"/>
        <source>Thin</source>
        <translation>Cienka</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2637"/>
        <source>Medium</source>
        <translation>Zwykła</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2642"/>
        <source>Thick</source>
        <translation>Gruba</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2657"/>
        <source>Fill Color</source>
        <translation>Kolor Wypełnienia</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1987"/>
        <source>Stroke Color</source>
        <translation>Kolor Obramowania</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2013"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2510"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2571"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2974"/>
        <source>Opacity</source>
        <translation>Widoczność</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1203"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1210"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1223"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1230"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1272"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Zmień kolor wypełnienia&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1278"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Zmień kolor obramowania&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1640"/>
        <source>Image</source>
        <translation>Obraz</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1680"/>
        <source>Shading</source>
        <translation>Cieniowanie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1702"/>
        <source>Image Form</source>
        <translation>Formularz Obrazu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2177"/>
        <source>Width</source>
        <translation>Szerokość</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2197"/>
        <source>Height</source>
        <translation>Wysokość</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1660"/>
        <source>Path</source>
        <translation>Ścieżka</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2866"/>
        <source>Form Field</source>
        <translation>Pole Formularza</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2789"/>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1215"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1260"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Zmień rodzinę czcionek&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2606"/>
        <source>Remove</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="399"/>
        <source>Goto a Page View</source>
        <translation>Idź do Widoku Strony</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="331"/>
        <source>Add an Action</source>
        <translation>Dodaj Akcję</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="337"/>
        <source>Trigger</source>
        <translation>Wyzwalacz</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="345"/>
        <source>Mouse Up</source>
        <translation>Kliknięcie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="350"/>
        <source>Mouse Down</source>
        <translation>Kliknięcie 2</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="355"/>
        <source>Mouse Enter</source>
        <translation>Najechanie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="360"/>
        <source>Mouse Exit</source>
        <translation>Opuszczenie</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="365"/>
        <source>On Receive Focus</source>
        <translation>Otrzymanie Fokusu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="370"/>
        <source>On Lose Focus</source>
        <translation>Opuszczenie Fokusu</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="391"/>
        <source>Action</source>
        <translation>Akcja</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="404"/>
        <source>Open/execute a File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="409"/>
        <source>Open a web link</source>
        <translation>Otwórz link</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="414"/>
        <source>Reset form</source>
        <translation>Zresetuj formularz</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="419"/>
        <source>Show/Hide fields</source>
        <translation>Pokaż/Ukryj pola</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="424"/>
        <source>Submit a form</source>
        <translation>Prześlij formularz</translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="429"/>
        <source>Run a JavaScript</source>
        <translation>Uruchom JavaScript</translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="14"/>
        <source>Page Layout</source>
        <translation>Układ Strony</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="96"/>
        <source>Contents Size</source>
        <translation>Rozmiar Zawartości</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="108"/>
        <source>Left margin</source>
        <translation>Lewy margines</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="122"/>
        <source>Top margin</source>
        <translation>Górny margines</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="136"/>
        <source>Right margin</source>
        <translation>Prawy margines</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="150"/>
        <source>Bottom margin</source>
        <translation>Dolny margines</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="53"/>
        <source>Page Size</source>
        <translation>Rozmiar Strony</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="59"/>
        <source>Width</source>
        <translation>Szerokość</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.cpp" line="236"/>
        <source> px</source>
        <translation>px</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.cpp" line="260"/>
        <source> in</source>
        <translation>&quot;</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.cpp" line="282"/>
        <source> mm</source>
        <translation>mm</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="76"/>
        <source>Height</source>
        <translation>Wysokość</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="167"/>
        <source>Units</source>
        <translation>Jednostki</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="178"/>
        <source>points</source>
        <translation>piksele</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="183"/>
        <source>inch</source>
        <translation>cale</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="188"/>
        <source>millimeter</source>
        <translation>milimetry</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="196"/>
        <source>Page Range</source>
        <translation>Zares Stron</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="219"/>
        <source>Pages from</source>
        <translation>Od strony</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="209"/>
        <source>Current Page</source>
        <translation>Bieżąca Strona</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="202"/>
        <source>All Pages</source>
        <translation>Wszystkie Strony</translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="241"/>
        <source>to:</source>
        <translation>do:</translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <location filename="../src/passwordopendialog.ui" line="14"/>
        <source>Enter Password</source>
        <translation>Wpisz Hasło</translation>
    </message>
    <message>
        <location filename="../src/passwordopendialog.ui" line="66"/>
        <source>Password:</source>
        <translation>Hasło:</translation>
    </message>
    <message>
        <location filename="../src/passwordopendialog.ui" line="56"/>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation>Dokument jest chroniony. Proszę wpisać Hasło Otwarcia Dokumentu</translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <location filename="../src/docpage/texteditor/plaintextedit.cpp" line="227"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation>Czcionka nie zawiera tych znaków.
Spróbuj wybrać inną czcionkę.</translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="14"/>
        <source>Print Preview</source>
        <translation>Podgląd Drukowania</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="32"/>
        <source>Printer</source>
        <translation>Drukarka</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="47"/>
        <source>Properties</source>
        <translation>Właściwości</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="88"/>
        <source>72</source>
        <translation type="unfinished">72</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="93"/>
        <source>150</source>
        <translation type="unfinished">150</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="98"/>
        <source>300</source>
        <translation type="unfinished">300</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="103"/>
        <source>600</source>
        <translation type="unfinished">600</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="108"/>
        <source>900</source>
        <translation type="unfinished">900</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="113"/>
        <source>1200</source>
        <translation type="unfinished">1200</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="127"/>
        <source>DPI</source>
        <translation type="unfinished">DPI</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="251"/>
        <source>Antialiasing</source>
        <translation>Antyaliasing</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="258"/>
        <source>Center</source>
        <translation>Wyśrodkuj</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="265"/>
        <source>Print as Grayscale</source>
        <translation>Drukuj w Skali Szarości</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="272"/>
        <source>Aspect Ratio</source>
        <translation>Wpółczynnik Proporcji</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="279"/>
        <source>Ignore aspect ratio</source>
        <translation>Ignoruj wpółczynnik proporcji</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="284"/>
        <source>Keep aspect ratio</source>
        <translation>Zachowaj wpółczynnik proporcji</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="289"/>
        <source>Keep aspect ratio by expanding</source>
        <translation>Zachowaj wpółczynnik proporcji rozciągając</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="303"/>
        <source>Orientation</source>
        <translation>Orientacja</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="309"/>
        <source>Portrait</source>
        <translation>Pionowa</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="316"/>
        <source>Landscape</source>
        <translation>Pozioma</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="359"/>
        <source>Page</source>
        <translation>Strona</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="369"/>
        <source>of:</source>
        <translation>z:</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="80"/>
        <source>Resolution</source>
        <translation>Rozdzielczość</translation>
    </message>
    <message>
        <source>Low</source>
        <translation type="vanished">Niska</translation>
    </message>
    <message>
        <source>Normal</source>
        <translation type="vanished">Normalna</translation>
    </message>
    <message>
        <source>High</source>
        <translation type="vanished">Wysoka</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="143"/>
        <source>Page Range</source>
        <translation>Zakres Stron</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="149"/>
        <source>All Pages</source>
        <translation>Wszystkie Strony</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="159"/>
        <source>Pages from</source>
        <translation>Od strony</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="166"/>
        <source>Current Page</source>
        <translation>Bieżąca Strona</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="189"/>
        <source>to:</source>
        <translation>do:</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="221"/>
        <source>Number of copies</source>
        <translation>Liczba kopii</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="235"/>
        <source>Collate</source>
        <translation>Sortuj</translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.cpp" line="67"/>
        <source>of </source>
        <translation>z </translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.cpp" line="97"/>
        <source>Print</source>
        <translation>Drukuj</translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Location</source>
        <translation>Lokalizacja</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="34"/>
        <source>Insert</source>
        <translation>Wstaw</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="35"/>
        <source>Delete</source>
        <translation>Usuń</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="36"/>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="415"/>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="435"/>
        <source>Save As...</source>
        <translation>Zapisz Jako...</translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="98"/>
        <source>Page </source>
        <translation>Strona </translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="102"/>
        <source>Attachment Tab</source>
        <translation>Karta Załącznika</translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="17"/>
        <source>Add Bookmark</source>
        <translation>Dodaj Zakładkę</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="18"/>
        <source>Delete Bookmark</source>
        <translation>Usuń Zakładkę</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="19"/>
        <source>Bookmark Properties</source>
        <translation>Właściwości Zakładki</translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="20"/>
        <source>Set Destination</source>
        <translation>Ustaw Przeznaczenie</translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <location filename="../src/document/qdoctab.cpp" line="73"/>
        <source>untitled</source>
        <translation>bez nazwy</translation>
    </message>
    <message>
        <location filename="../src/document/qdoctab.cpp" line="544"/>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation>Schowek nie zawiera żadnych danych</translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="370"/>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation>Zażądano połączenie HTTPS, ale obługa SSL nie jest wkompilowana</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="1579"/>
        <location filename="../src/qhttp/qhttp.cpp" line="2375"/>
        <source>Unknown error</source>
        <translation>Nieznany błąd</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="1830"/>
        <source>Request aborted</source>
        <translation>Żądanie przerwane</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2386"/>
        <source>No server set to connect to</source>
        <translation>Brak serwera do połączenia</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2550"/>
        <source>Wrong content length</source>
        <translation>Zła długość treści</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2554"/>
        <source>Server closed connection unexpectedly</source>
        <translation>Serwer nieoczekiwanie zamknął połączenie</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2609"/>
        <source>Connection refused (or timed out)</source>
        <translation>Połączenie odrzucone (lub przekroczono limit czasu)</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2612"/>
        <source>Host %1 not found</source>
        <translation>Host %1 nie znaleziony</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2632"/>
        <source>HTTP request failed</source>
        <translation>Żądanie HTTP nie powiodło się</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2726"/>
        <source>Invalid HTTP response header</source>
        <translation>Nieprawidłowy nagłówek odpowiedzi HTTP</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2770"/>
        <source>Unknown authentication method</source>
        <translation>Nieznana metoda uwierzytelniania</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2780"/>
        <source>Proxy authentication required</source>
        <translation>Wymagane uwierzytelnienie proxy</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2784"/>
        <source>Authentication required</source>
        <translation>Wymagana autoryzacja</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2867"/>
        <location filename="../src/qhttp/qhttp.cpp" line="2915"/>
        <source>Invalid HTTP chunked body</source>
        <translation>Nieprawidłowa treść fragmentaryczna HTTP</translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2953"/>
        <source>Error writing response to device</source>
        <translation>Błąd zapisu odpowiedzi dla urządzenia</translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <location filename="../src/document/qpdfdocument.cpp" line="974"/>
        <source>Error!</source>
        <translation>Błąd!</translation>
    </message>
    <message>
        <location filename="../src/document/qpdfdocument.cpp" line="1379"/>
        <source>There was a problem with your form submission.</source>
        <translation>Pojawił się problem z przesłaniem formularza.</translation>
    </message>
    <message>
        <location filename="../src/document/qpdfdocument.cpp" line="1381"/>
        <source>Your form was successfully submitted!</source>
        <translation>Twój formularz został pomyślnie przesłany!</translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="70"/>
        <source>Pages</source>
        <translation>Strony</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="75"/>
        <source>Enlarge Page Thumbnails</source>
        <translation>Powiększ Miniatury Stron</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="78"/>
        <source>Reduce Page Thumbnails</source>
        <translation>Powiększ Miniatury Stron</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="83"/>
        <source>Delete Pages</source>
        <translation>Usuń Strony</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="96"/>
        <source>Bookmarks</source>
        <translation>Zakładki</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="109"/>
        <source>Attachment</source>
        <translation>Załącznik</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="116"/>
        <source>Search</source>
        <translation>Szukaj</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="131"/>
        <source>Object Inspector</source>
        <translation>Inspektor Obiektu</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="352"/>
        <source>This document contains interactive form fields</source>
        <translation>Dokument zawiera interaktywne pola formularza</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="353"/>
        <source>Highlight Fields</source>
        <translation>Wyróżnione Pola</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="371"/>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation>Dokument jest chroniony. Nie posiadasz uprawneń do edytowania dokumentu</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="372"/>
        <source>Change</source>
        <translation>Zmień</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="699"/>
        <source>There was an error printing the document</source>
        <translation>Wystąpił błąd podczas drukowania dokumentu</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="1090"/>
        <source>Insert Blank Pages</source>
        <translation>Wstaw Puste Strony</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="1795"/>
        <source>Do you want to open?</source>
        <translation>Chcesz otworzyć?</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="2390"/>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation>Na pewno chcesz przypisać przeznaczenie zaznaczonej zakładki do bieżącej lokalizacji?</translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="2448"/>
        <source>untitled</source>
        <translation>bez nazwy</translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="131"/>
        <source>More...</source>
        <translation>Więcej...</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="263"/>
        <source>User color %1</source>
        <translation>Kolor użytkownika %1</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="314"/>
        <source>User Color 99</source>
        <translation>Kolor użytkownika 99</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="328"/>
        <source>Black</source>
        <translation>Czarny</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="329"/>
        <source>White</source>
        <translation>Biały</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="330"/>
        <source>Red</source>
        <translation>Czerwony</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="331"/>
        <source>Dark red</source>
        <translation>Ciemnoczerwony</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="332"/>
        <source>Green</source>
        <translation>Zielony</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="333"/>
        <source>Dark green</source>
        <translation>Ciemnozielony</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="334"/>
        <source>Blue</source>
        <translation>Niebieski</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="335"/>
        <source>Dark blue</source>
        <translation>Ciemnoniebieski</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="336"/>
        <source>Cyan</source>
        <translation>Turkusowy</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="337"/>
        <source>Dark cyan</source>
        <translation>Ciemnoturkusowy</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="338"/>
        <source>Magenta</source>
        <translation>Amarantowy</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="339"/>
        <source>Dark magenta</source>
        <translation>Ciemnoamarantowy</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="340"/>
        <source>Yellow</source>
        <translation>Żółty</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="341"/>
        <source>Dark yellow</source>
        <translation>Ciemnożółty</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="342"/>
        <source>Gray</source>
        <translation>Szary</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="343"/>
        <source>Dark gray</source>
        <translation>Ciemnoszary</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="344"/>
        <source>Light gray</source>
        <translation>Jasnoszary</translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="346"/>
        <source>Transparent</source>
        <translation>Przezroczysty</translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <location filename="../src/regdialog.ui" line="14"/>
        <source>Registration Info</source>
        <translation>Informacja o Rejestracji</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="330"/>
        <source>Ok</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="148"/>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation>Po zakończeniu składania zamówienia, automatycznie otrzymasz kod Rejestracyjny na e-mail.</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="119"/>
        <source>Buy Online</source>
        <translation>Kup Online</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="39"/>
        <location filename="../src/regdialog.ui" line="242"/>
        <source>Registration Code</source>
        <translation>Kod Rejestracji</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="49"/>
        <location filename="../src/regdialog.ui" line="256"/>
        <source>Activate</source>
        <translation>Aktywuj</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="72"/>
        <source>Offline Activation</source>
        <translation>Aktywacja Offline</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="170"/>
        <source>Registered version</source>
        <translation>Zarejestrowana wersja</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="177"/>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation>Jeśli chcesz zarejestrować tę licencję na innym PC
kliknij przycisk &quot;Deaktywuj&quot;.

Następnie zarejestruj ją gdzie potrzebujesz.</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="203"/>
        <source>Deactivate</source>
        <translation>Deaktywuj</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="276"/>
        <source>Back</source>
        <translation>Powrót</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="249"/>
        <source>Activation Code</source>
        <translation>Kod Aktywacyjny</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="296"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Proszę wysłać klucz ID i kod Rejestracyjny na: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Po otrzymaniu kodu, wpisz go w pole &amp;quot;Kod aktywacyjny&amp;quot;&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="283"/>
        <source>ID</source>
        <translation>ID</translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="14"/>
        <source>Rotate</source>
        <translation>Obróć</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="20"/>
        <source>Page Range</source>
        <translation>Zakres Stron</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="26"/>
        <source>Pages</source>
        <translation>Strony</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="52"/>
        <source>Sample: 1,6-8,12</source>
        <translation>Przykład: 1,6-8,12</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="72"/>
        <source>Current Page</source>
        <translation>Bieżąca Strona</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="82"/>
        <source>Pages from</source>
        <translation>Od strony</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="108"/>
        <source>to:</source>
        <translation>do:</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="134"/>
        <source>Direction</source>
        <translation>Kierunek</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="141"/>
        <source>Clockwise 90 degrees</source>
        <translation>Zgodnie z zegarem 90 stopni</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="146"/>
        <source>180 degrees</source>
        <translation>180 Stopni</translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="151"/>
        <source>Counterclockwise 90 degrees</source>
        <translation>Przeciwnie do zegara 90 stopni</translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="14"/>
        <source>Export to Image</source>
        <translation>Eksportuj do Obrazu</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="20"/>
        <source>File Name</source>
        <translation>Nazwa Pliku</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="29"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="39"/>
        <source>Page Range</source>
        <translation>Zakres Stron</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="51"/>
        <source>All Pages</source>
        <translation>Wszystkie Strony</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="67"/>
        <source>Pages from</source>
        <translation>Od strony</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="84"/>
        <source>to:</source>
        <translation>do:</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="107"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="148"/>
        <location filename="../src/SaveImageDialog.ui" line="217"/>
        <source>JPEG</source>
        <translation>JPEG</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="113"/>
        <source>BMP</source>
        <translation>BMP</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="120"/>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="158"/>
        <source>TIFF</source>
        <translation>TIFF</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="127"/>
        <source>JPEG Quality</source>
        <translation>Jakość JPEG</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="197"/>
        <source>LZW</source>
        <translation>LZW</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="202"/>
        <source>ZIP</source>
        <translation>ZIP</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="207"/>
        <source>CCITT FAX 3</source>
        <translation>CCITT FAX 3</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="212"/>
        <source>CCITT FAX 4</source>
        <translation>CCITT FAX 4</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="134"/>
        <source>TIFF Compression</source>
        <translation>Kompresja TIFF</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="141"/>
        <source>Transparent</source>
        <translation>Przezroczysty</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="225"/>
        <source>MultiPage</source>
        <translation>Wiele Stron</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="235"/>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="241"/>
        <source>Width</source>
        <translation>Szerokość</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="248"/>
        <source>Height</source>
        <translation>Wysokość</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="342"/>
        <source>72</source>
        <translation>72</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="347"/>
        <source>96</source>
        <translation>96</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="352"/>
        <source>120</source>
        <translation>120</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="357"/>
        <source>150</source>
        <translation>150</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="362"/>
        <source>200</source>
        <translation>200</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="367"/>
        <source>240</source>
        <translation>240</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="372"/>
        <source>300</source>
        <translation>300</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="377"/>
        <source>400</source>
        <translation>400</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="382"/>
        <source>500</source>
        <translation>500</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="387"/>
        <source>600</source>
        <translation>600</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="398"/>
        <source>Antialiasing</source>
        <translation>Antyaliasing</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="255"/>
        <source>DPI</source>
        <translation>DPI</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="13"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="14"/>
        <source>Export</source>
        <translation>Eksportuj</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="88"/>
        <source>Can&apos;t save to the file:</source>
        <translation>Nie można zapisać do pliku:</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="88"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation>Plik może być tylko do odczytu lub używany przez inną aplikację.</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="421"/>
        <source>Save As TIFF Image</source>
        <translation>Zapisz Jako Obraz TIFF</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="421"/>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation>Pliki TIFF (*.tif *.tiff)</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="440"/>
        <source>Save As Image</source>
        <translation>Zapisz Jako Obraz</translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="440"/>
        <source>All Files (*)</source>
        <translation>Wszystkie Pliki (*)</translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <location filename="../src/leftTab/search/searchformtab.ui" line="14"/>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.ui" line="20"/>
        <source>Search</source>
        <translation>Szukaj</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.ui" line="46"/>
        <source>0 result</source>
        <translation>brak wyników</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="13"/>
        <source>Case Sensitive</source>
        <translation>Uwzględnij Wielkość Liter</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="17"/>
        <source>Include Comments</source>
        <translation>Zawierać komentarze</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="53"/>
        <source> result</source>
        <translation> wynik</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="55"/>
        <source> result(s)</source>
        <translation> wynik(i)</translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="57"/>
        <source> results</source>
        <translation>wyników</translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <location filename="../src/SecurityDialog.ui" line="14"/>
        <source>Security PDF</source>
        <translation>Zabezpieczony PDF</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="36"/>
        <source>Required a password to open the document</source>
        <translation>Wymagane hasło, aby otworzyć dokument</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="51"/>
        <source>Document Open Password</source>
        <translation>Hasło Otwarcia Dokumentu</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="71"/>
        <location filename="../src/SecurityDialog.ui" line="132"/>
        <source>Password Confirm</source>
        <translation>Potwierdzenie Hasła</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="94"/>
        <source>Permissions</source>
        <translation>Uprawnienia</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="122"/>
        <source>Commenting</source>
        <translation>Komentowanie</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="142"/>
        <source>Modifying document</source>
        <translation>Modyfikowanie dokumentu</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="155"/>
        <source>Content copying for accessibility</source>
        <translation>Kopiowanie treści dla ułatwienia dostępu</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="168"/>
        <source>Printing the document</source>
        <translation>Drukowanie dokumentu</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="181"/>
        <source>Extract the content of the document</source>
        <translation>Wyodrębnij treść dokumentu</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="194"/>
        <source>Print a high resolution version of the document</source>
        <translation>Drukuj wysokiej jakości wersję dokumentu</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="207"/>
        <source>Fill in existing form or signature fields</source>
        <translation>Wypełnij isniejące pola formularzy i podpisów</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="223"/>
        <source>Permissions Password</source>
        <translation>Hasło Uprawnień</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="233"/>
        <source>Manage Pages and bookmarks</source>
        <translation>Zarządzaj Stronami i zakładkami</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.cpp" line="84"/>
        <source>Document Open password does not match.</source>
        <translation>Hasła Otwarcia Dokumentu nie pasują.</translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.cpp" line="96"/>
        <source>Document Permission password does not match.</source>
        <translation>Hasła Uprawnień Dokumentu nie pasują.</translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="14"/>
        <source>Signature Properties</source>
        <translation>Właściwości Podpisu</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="52"/>
        <location filename="../src/signature/SignatureDialog.cpp" line="20"/>
        <source>Signature is VALID</source>
        <translation>Podpis jest PRAWIDŁOWY</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="72"/>
        <source>Details</source>
        <translation>Szczegóły</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="129"/>
        <source>Signed by:</source>
        <translation>Podpisany przez:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="78"/>
        <source>Reason:</source>
        <translation>Powód:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="92"/>
        <source>Date:</source>
        <translation>Data:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="115"/>
        <source>Location:</source>
        <translation>Lokalizacja:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="169"/>
        <source>Validation Summary</source>
        <translation>Podsumowanie Weryfikacji</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="185"/>
        <source>Signer&apos;s Contact Information:</source>
        <translation>Informacje Kontaktowe Podpisującego:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="224"/>
        <source>Sing As</source>
        <translation>Podpisz Jako</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="367"/>
        <source>Show Image</source>
        <translation>Pokaż Obraz</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="376"/>
        <source>Stretch Image</source>
        <translation>Rozciągnij Obraz</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="396"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="406"/>
        <source>Show Text</source>
        <translation>Pokaż Tekst</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="136"/>
        <location filename="../src/signature/SignatureDialog.ui" line="244"/>
        <source>Info</source>
        <translation>Informacja</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="254"/>
        <source>Text For Signing</source>
        <translation>Tekst Do Podpisu</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="266"/>
        <source>Location</source>
        <translation>Lokalizacja</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="282"/>
        <source>Reason</source>
        <translation>Powód</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="299"/>
        <source>Lock document after signing</source>
        <translation>Zablokuj dokument po podpisaniu</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="325"/>
        <source>Signature Preview</source>
        <translation>Podgląd Podpisu</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="39"/>
        <source>I have reviewed this document</source>
        <translation>Przejrzałem ten dokument</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="40"/>
        <source>I am approving this document</source>
        <translation>Zatwierdzam ten dokument</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="41"/>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation>Potwierdzam dokładność i integralność tego dokumentu</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="42"/>
        <source>I agree to specified parts of this document</source>
        <translation>Zgadzam się na określone części tego dokumentu</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="17"/>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation>Dokument został zmieniony lub uszkodzony od czasu zastosowania podpisu.</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="18"/>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation>Dokument nie został zmieniony od czasu zastosowania podpisu.</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="19"/>
        <source>Signature is INVALID</source>
        <translation>Podpis jest NIEPRAWIDŁOWY</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="21"/>
        <source>Signature validity is UNKNOWN</source>
        <translation>Ważność podpisu jest NIEZNANA</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="22"/>
        <source>This certificate is not trusted</source>
        <translation>Certyfikat jest niezaufany</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="23"/>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation>Tożsamość podpisującego jest nieznana, ponieważ nie znajduje się na liście zaufanych tożsamości i żadne jej nadrzędne certyfikaty nie są zaufane.</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="24"/>
        <source>Error during signature verification.</source>
        <translation>Błąd podczas weryfikacji podpisu.</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="25"/>
        <source>Details: The signature byte range is invalid</source>
        <translation>Szczegóły: Zakres bajtów podpisu jest nieprawidłowy</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="26"/>
        <source>I am the author of this document</source>
        <translation>Jestem autorem tego dokumentu</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="84"/>
        <source>Open Image</source>
        <translation>Otwórz Obraz</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="84"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation>Pliki Obrazu (*.tif *.png *.jpg *.jpeg *.bmp)</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="344"/>
        <source>Open File</source>
        <translation>Otwórz Plik</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="344"/>
        <source>p12 Files (*.p12)</source>
        <translation>Pliki p12 (*.p12)</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="329"/>
        <source>A error occurred during the signature verification!</source>
        <translation>Pojawił się błąd podczas weryfikacji sygnatury!</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="169"/>
        <source>Browse...</source>
        <translation>Przeglądaj...</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="246"/>
        <source>A password is required to open certificate:</source>
        <translation>Hasło jest wymagane, aby otworzyć certyfikat:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="133"/>
        <source>Sign</source>
        <translation>Podpisz</translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="14"/>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="34"/>
        <source>Info</source>
        <translation>Informacja</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="40"/>
        <source>Issuer</source>
        <translation>Wydawca</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="46"/>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="132"/>
        <source>Common Name (CN)</source>
        <translation>Powszechna Nazwa (PN)</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="60"/>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="139"/>
        <source>Organization (O)</source>
        <translation>Organizacja (O)</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="74"/>
        <source>Organizational Unit (OU)</source>
        <translation>Jednostka Organizacyjna (JO)</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="88"/>
        <source>Serial Number</source>
        <translation>Numer Seryjny</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="102"/>
        <source>Algorithm</source>
        <translation>Algorytm</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="119"/>
        <source>Subject</source>
        <translation>Temat</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="153"/>
        <source>Email</source>
        <translation>E-mail</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="166"/>
        <source>Validity</source>
        <translation>Ważność</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="172"/>
        <source>Not Before</source>
        <translation>Nie Przed</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="179"/>
        <source>Not After</source>
        <translation>Nie Po</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="209"/>
        <source>SHA-1:</source>
        <translation>SHA-1:</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="229"/>
        <source>MD5</source>
        <translation>MD5</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="278"/>
        <source>Add to Trusted Identities</source>
        <translation>Dodaj do Zaufanych Tożsamości</translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="286"/>
        <source>Data</source>
        <translation>Dane</translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <location filename="../src/forms/StickyNoteDlg.ui" line="17"/>
        <source>Form</source>
        <translation>Formularz</translation>
    </message>
</context>
</TS>
