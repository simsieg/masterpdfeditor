<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../src/aboutdialog.ui" line="14"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/aboutdialog.ui" line="83"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarksDialogProp</name>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="14"/>
        <source>Bookmark Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="24"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="48"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="83"/>
        <source>Set current position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="93"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="112"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="126"/>
        <source>Plain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="131"/>
        <source>Italic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="136"/>
        <source>Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="141"/>
        <source>Italic &amp; Bold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="162"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="69"/>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="176"/>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="276"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="323"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="310"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="182"/>
        <source>Add an Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="188"/>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="217"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="196"/>
        <source>Mouse Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="60"/>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="225"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="230"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="235"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="240"/>
        <source>Reset form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="245"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="250"/>
        <source>Submit a form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="255"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.ui" line="263"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="64"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="206"/>
        <source>Do you want to set the current position?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/BookmarksDialogProp.cpp" line="208"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DialogDeletePages</name>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="14"/>
        <source>Delete Page(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="26"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="32"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="78"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="88"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="114"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DeletePagesDlg.ui" line="140"/>
        <source>The removed page(s) cannot be recovered with undo operation.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DocPage</name>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="14"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage.cpp" line="15"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DocPageBase</name>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="62"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="63"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="64"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="65"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="66"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="67"/>
        <source>Edit text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="68"/>
        <source>Signature options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="69"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="70"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="71"/>
        <source>Set Fit to Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="1324"/>
        <source>Open Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="1324"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/docpage_base.cpp" line="1357"/>
        <source>ERORR Load Image !</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionForm</name>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="14"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="49"/>
        <source>Java script editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="80"/>
        <source>Goto a page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="99"/>
        <location filename="../src/forms/EditActionForm.ui" line="154"/>
        <location filename="../src/forms/EditActionForm.ui" line="243"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="272"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="236"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="92"/>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="279"/>
        <source>Zoom (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="319"/>
        <location filename="../src/forms/EditActionForm.cpp" line="153"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="325"/>
        <source>Edit a file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="450"/>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="362"/>
        <location filename="../src/forms/EditActionForm.ui" line="368"/>
        <location filename="../src/forms/EditActionForm.ui" line="517"/>
        <source>Select Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="411"/>
        <location filename="../src/forms/EditActionForm.ui" line="543"/>
        <source>Deselect All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="437"/>
        <source>Hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="398"/>
        <location filename="../src/forms/EditActionForm.ui" line="523"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="86"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="157"/>
        <location filename="../src/forms/EditActionForm.ui" line="246"/>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="229"/>
        <source>Zoom Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="181"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="186"/>
        <source>Inherit Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="191"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="196"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="201"/>
        <source>FitV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="206"/>
        <source>FitR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="211"/>
        <source>FitB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="216"/>
        <source>FitBH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="221"/>
        <source>FitBV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="335"/>
        <location filename="../src/forms/EditActionForm.ui" line="608"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="464"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="470"/>
        <source>FDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="480"/>
        <source>HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="487"/>
        <source>XFDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="494"/>
        <source>PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="556"/>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="563"/>
        <source>Local file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="568"/>
        <source>E-mail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="573"/>
        <source>FTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="578"/>
        <source>HTTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="621"/>
        <source>Use anonymous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="628"/>
        <source>Need user name and password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="638"/>
        <source>User name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.ui" line="661"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="112"/>
        <location filename="../src/forms/EditActionForm.cpp" line="126"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="114"/>
        <location filename="../src/forms/EditActionForm.cpp" line="128"/>
        <source>All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="154"/>
        <source>Enter a file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="161"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="163"/>
        <source>Enter a web site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="214"/>
        <source>Show/Hide Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="218"/>
        <source>Select Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionForm.cpp" line="247"/>
        <source>Reset Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditActionSmallForm</name>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="14"/>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="116"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="27"/>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="99"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="36"/>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="100"/>
        <source>Enter a file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="49"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="76"/>
        <source>Goto a page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="82"/>
        <source>Page Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="89"/>
        <source>Zoom Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="96"/>
        <source>Zoom (%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="103"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="110"/>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="134"/>
        <source>XYZ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="139"/>
        <source>Fit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="144"/>
        <source>FitH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="149"/>
        <source>FitV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="154"/>
        <source>FitR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="159"/>
        <source>FitB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="164"/>
        <source>FitBH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="169"/>
        <source>FitBV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="177"/>
        <location filename="../src/forms/EditActionSmallForm.ui" line="193"/>
        <location filename="../src/forms/EditActionSmallForm.ui" line="209"/>
        <source>auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.ui" line="196"/>
        <location filename="../src/forms/EditActionSmallForm.ui" line="212"/>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="107"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="108"/>
        <source>Enter a web site:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="115"/>
        <source>Named Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="164"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/EditActionSmallForm.cpp" line="166"/>
        <source>All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportPageDialog</name>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="14"/>
        <source>Extract Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="26"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="54"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="70"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="82"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="98"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="115"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="138"/>
        <source>Extract pages as a single file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.ui" line="145"/>
        <source>Export Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="10"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="36"/>
        <source>Export Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="76"/>
        <source>Export Pages </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="109"/>
        <source>Save As PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="111"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="141"/>
        <location filename="../src/ExportPageDialog.cpp" line="168"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ExportPageDialog.cpp" line="141"/>
        <location filename="../src/ExportPageDialog.cpp" line="168"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileSettings</name>
    <message>
        <location filename="../src/FileSettings.ui" line="14"/>
        <source>Document Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="37"/>
        <source>Document Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="43"/>
        <source>PDF Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="49"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="59"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="69"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="99"/>
        <source>Keywords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="79"/>
        <source>Creator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="89"/>
        <source>Producer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="113"/>
        <source>Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="225"/>
        <source>Printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="212"/>
        <source>Print a high resolution version of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="290"/>
        <source>Modifying document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="238"/>
        <source>Fill in existing form or signature fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="303"/>
        <source>Manage Pages and bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="145"/>
        <source>No Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="150"/>
        <source>Password Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="158"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="184"/>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="199"/>
        <source>Extract the content of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="251"/>
        <source>Content copying for accessibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="277"/>
        <source>Commenting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="320"/>
        <source>Initial View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="342"/>
        <source>Page Mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="350"/>
        <source>Page Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="355"/>
        <source>Bookmarks Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="360"/>
        <source>Pages Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="375"/>
        <source>Attachments Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="417"/>
        <source>Run JavaScript on Document Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="442"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="449"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="456"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="370"/>
        <source>Layers Panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="365"/>
        <source>Full Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="396"/>
        <source>Open to Page:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="410"/>
        <source>of :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="483"/>
        <source>Fonts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.ui" line="499"/>
        <source>Fonts used in this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.cpp" line="420"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.cpp" line="421"/>
        <source>The document is protected. Please enter a permissions password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FileSettings.cpp" line="438"/>
        <source>Incorrect password. Please input the owner password.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImportPageDialog</name>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="14"/>
        <source>Insert Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="26"/>
        <source>Before page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="78"/>
        <source>After page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="178"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="184"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="194"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="220"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="230"/>
        <source>Import Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="130"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="165"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="145"/>
        <location filename="../src/ImportPageDialog.cpp" line="181"/>
        <source>Total pages :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="20"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="107"/>
        <source>After last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.ui" line="58"/>
        <source>Before first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="10"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="105"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="105"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="135"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="136"/>
        <source>The file is protected. Please enter a Document Open Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/ImportPageDialog.cpp" line="174"/>
        <source>Error read: This PDF is protected.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JavaScriptEditDialog</name>
    <message>
        <location filename="../src/forms/javascripteditdialog.ui" line="14"/>
        <source>Java Script Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/javascripteditdialog.ui" line="20"/>
        <source>Function Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/forms/javascripteditdialog.ui" line="32"/>
        <source>Java Script</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainOptionsDialog</name>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="250"/>
        <source> ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="567"/>
        <source>Smooth text and images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="266"/>
        <source>Time before a move or resize starts:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="279"/>
        <source>Select item by hovering the mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="46"/>
        <source>Saving Documents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="86"/>
        <source>Create backup file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="72"/>
        <source>Choice destination for &quot;Save As&quot; documents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="59"/>
        <source>Last used folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="64"/>
        <source>Original documents folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="195"/>
        <source>Required field highlight color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="181"/>
        <source>Highlight color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="318"/>
        <source>Default font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="673"/>
        <source>Built-in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="659"/>
        <source>Please choose the interface language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="623"/>
        <location filename="../src/mainoptionsdialog.ui" line="694"/>
        <source>It&apos;s required to restart the program so the changes take effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="760"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="765"/>
        <source>Weekly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="770"/>
        <source>Monthly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="746"/>
        <source>Check for Updates Automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="79"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="379"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="330"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="17"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="96"/>
        <source>History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="108"/>
        <source>Restore last session when application start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="115"/>
        <source>Restore last view settings when reopening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="125"/>
        <source>Enable JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="188"/>
        <source> Always hide document message bar </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="438"/>
        <source>Default Layout and Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="444"/>
        <source>Default page layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="462"/>
        <location filename="../src/mainoptionsdialog.ui" line="539"/>
        <source>Automatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="544"/>
        <source>Single Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="549"/>
        <source>Facing Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="451"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="467"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="472"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="477"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="482"/>
        <source>25%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="487"/>
        <source>50%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="492"/>
        <source>75%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="497"/>
        <source>100%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="502"/>
        <source>125%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="507"/>
        <source>150%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="512"/>
        <source>200%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="517"/>
        <source>300%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="522"/>
        <source>400%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="527"/>
        <source>600%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="421"/>
        <location filename="../src/mainoptionsdialog.ui" line="573"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="580"/>
        <source>Bitmap Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="587"/>
        <source>Vector Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="409"/>
        <source>Replace Document Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="428"/>
        <source>Page Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="557"/>
        <source> Always show Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="610"/>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="616"/>
        <source>Fusion Dark Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="835"/>
        <source>toolBar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="877"/>
        <location filename="../src/mainoptionsdialog.ui" line="880"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="892"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="904"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="916"/>
        <source>Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="928"/>
        <source>Editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.ui" line="940"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="293"/>
        <source>Select directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="584"/>
        <source>Arabic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="585"/>
        <source>Armenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="586"/>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="587"/>
        <source>Catalan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="588"/>
        <source>Chinese-Simplified</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="589"/>
        <source>Chinese-Traditional</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="590"/>
        <source>Czech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="591"/>
        <source>Danish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="592"/>
        <source>Dutch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="593"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="594"/>
        <source>Estonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="595"/>
        <source>Finnish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="596"/>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="597"/>
        <source>Galician</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="598"/>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="599"/>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="600"/>
        <source>Hebrew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="601"/>
        <source>Hungarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="602"/>
        <source>Irish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="603"/>
        <source>Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="604"/>
        <source>Japanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="605"/>
        <source>Korean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="606"/>
        <source>Latvian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="607"/>
        <source>Lithuanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="608"/>
        <source>Norwegian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="609"/>
        <source>Norwegian-Nynorsk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="610"/>
        <source>Polish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="611"/>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="612"/>
        <source>Portuguese-Brazilian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="613"/>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="614"/>
        <source>Russian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="615"/>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="616"/>
        <source>Slovak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="617"/>
        <source>Slovenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="618"/>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="619"/>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="620"/>
        <source>Thai</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="621"/>
        <source>Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="622"/>
        <source>Ukrainian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="623"/>
        <source>Valencian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainoptionsdialog.cpp" line="624"/>
        <source>Vietnamese</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="36"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="46"/>
        <source>Export to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="135"/>
        <location filename="../src/mainwindow.ui" line="1297"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="308"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="139"/>
        <source>Align Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="67"/>
        <location filename="../src/mainwindow.ui" line="1289"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="332"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="163"/>
        <source>Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="93"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="191"/>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="112"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="178"/>
        <location filename="../src/mainwindow.ui" line="1313"/>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="101"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="398"/>
        <source>Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="103"/>
        <location filename="../src/mainwindow.ui" line="1305"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="366"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="672"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="678"/>
        <location filename="../src/mainwindow.cpp" line="1701"/>
        <source>Create a new blank PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="681"/>
        <source>Ctrl+N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="217"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="292"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="220"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Open File (Ctrl+O)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Open a PDF or XPS file&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="232"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="255"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hand tool (Alt+4)&lt;/span&gt;&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="279"/>
        <source>Select text for copying and pasting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="282"/>
        <source>Alt+5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="316"/>
        <source>PgUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="331"/>
        <source>PgDown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="398"/>
        <source>Ctrl+H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="445"/>
        <location filename="../src/mainwindow.cpp" line="1415"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="448"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save (Ctrl+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="457"/>
        <source>Save the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="460"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="469"/>
        <location filename="../src/mainwindow.cpp" line="374"/>
        <location filename="../src/mainwindow.cpp" line="2713"/>
        <location filename="../src/mainwindow.cpp" line="2770"/>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="472"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Save As PDF(Ctrl+Shift+S)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Save the document with a new name&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="480"/>
        <source>Save the document with a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="492"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="495"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Print (Ctrl+P)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Print the document&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="498"/>
        <source>Print the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="501"/>
        <source>Ctrl+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="506"/>
        <location filename="../src/mainwindow.ui" line="509"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="512"/>
        <source>Ctrl+W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="517"/>
        <location filename="../src/mainwindow.ui" line="520"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="569"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Edit Document (Alt+1)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select and edit text, images, annotations, form fields ...&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="572"/>
        <source>Select and edit text, images, annotations, form fields ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="590"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text Object(Alt+2)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for editing&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="593"/>
        <source>Select text for editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="596"/>
        <source>Alt+2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="605"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="608"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Ubuntu&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;Delete Object(s) (Del)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt; font-weight:600;&quot;&gt;&lt;br /&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Delete the currently selected object(s)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="617"/>
        <source>Delete the currently selected object(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="675"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;New (Ctrl+N)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Create a new blank PDF&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="700"/>
        <source>Ctrl+Shift+P</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="715"/>
        <source>Cut the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="733"/>
        <source>Copy the selection Object(s) and place on the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="751"/>
        <source>Paste from the Clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="784"/>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="807"/>
        <source>Undo the last action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="825"/>
        <source>Redo the previously undone action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="843"/>
        <source>Send to Back selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="852"/>
        <source>Bring to Front</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="855"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Bring To Front&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Bring to Front selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="858"/>
        <source>Bring to Front selected object.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="921"/>
        <source>Ctrl+Shift+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="932"/>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="937"/>
        <location filename="../src/mainwindow.ui" line="940"/>
        <source>Extract Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="945"/>
        <location filename="../src/mainwindow.ui" line="948"/>
        <source>Insert Pages...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="968"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Properties (Ctrl+D)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Open window with document properties&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="976"/>
        <source>Open window with document properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="994"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sticky Note&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Click the page to add a note at that position&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="997"/>
        <source>Click the page to add a note at that position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1042"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1045"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Text (Ctrl+T)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new text to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1053"/>
        <source>Insert new text to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1056"/>
        <source>Ctrl+T</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1065"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1068"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Image (Ctrl+I)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new image to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1076"/>
        <source>Insert new image to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1079"/>
        <source>Ctrl+I</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1139"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt; font-weight:600;&quot;&gt;Insert Link (Ctrl+L)&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;Insert new link to current page&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1147"/>
        <source>Insert new link to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1333"/>
        <location filename="../src/mainwindow.ui" line="1336"/>
        <source>Open Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1341"/>
        <location filename="../src/mainwindow.ui" line="1344"/>
        <source>Crop Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1347"/>
        <source>Ctrl+K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1356"/>
        <location filename="../src/mainwindow.ui" line="1359"/>
        <source>Rotate 90 degrees Clockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1368"/>
        <location filename="../src/mainwindow.ui" line="1371"/>
        <location filename="../src/mainwindow.ui" line="1374"/>
        <source>Rotate 90 degrees Counterclockwise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1379"/>
        <source>Export Form Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1384"/>
        <source>Import Form Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1389"/>
        <source>Export Comments Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1394"/>
        <source>Import Comments Data...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="837"/>
        <source>Send to Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="840"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Send to Back&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Send to Back selected object.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="620"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1273"/>
        <source>Statusbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="295"/>
        <location filename="../src/mainwindow.ui" line="298"/>
        <source>First Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="310"/>
        <location filename="../src/mainwindow.ui" line="313"/>
        <source>Previous Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="325"/>
        <location filename="../src/mainwindow.ui" line="328"/>
        <source>Next Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="336"/>
        <location filename="../src/mainwindow.ui" line="339"/>
        <source>Last Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="631"/>
        <source>Alt+Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1174"/>
        <location filename="../src/mainwindow.ui" line="1177"/>
        <source>Check box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1159"/>
        <location filename="../src/mainwindow.ui" line="1162"/>
        <source>Edit Box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1186"/>
        <location filename="../src/mainwindow.ui" line="1189"/>
        <source>Radio button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1210"/>
        <location filename="../src/mainwindow.ui" line="1213"/>
        <source>List box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1198"/>
        <location filename="../src/mainwindow.ui" line="1201"/>
        <source>Combo box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1281"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="284"/>
        <source>Main</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1234"/>
        <location filename="../src/mainwindow.ui" line="1237"/>
        <source>Signature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="748"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Paste (Ctrl+V)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Paste from the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="770"/>
        <location filename="../src/mainwindow.ui" line="773"/>
        <source>Set Fit to Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1088"/>
        <location filename="../src/mainwindow.ui" line="1091"/>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1100"/>
        <location filename="../src/mainwindow.ui" line="1103"/>
        <source>Rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1112"/>
        <location filename="../src/mainwindow.ui" line="1115"/>
        <source>Ellipse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="694"/>
        <location filename="../src/mainwindow.ui" line="697"/>
        <source>Print Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="867"/>
        <location filename="../src/mainwindow.ui" line="870"/>
        <source>Align Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="879"/>
        <location filename="../src/mainwindow.ui" line="882"/>
        <source>Align Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="891"/>
        <location filename="../src/mainwindow.ui" line="894"/>
        <source>Align Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="957"/>
        <location filename="../src/mainwindow.ui" line="960"/>
        <source>Align Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="551"/>
        <location filename="../src/mainwindow.ui" line="554"/>
        <source>Reduce Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="543"/>
        <location filename="../src/mainwindow.ui" line="546"/>
        <source>Enlarge Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="686"/>
        <location filename="../src/mainwindow.ui" line="689"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="899"/>
        <location filename="../src/mainwindow.ui" line="902"/>
        <source>Insert Blank Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="965"/>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="982"/>
        <source>Ctrl+D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1150"/>
        <source>Ctrl+L</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1165"/>
        <source>Ctrl+E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1252"/>
        <source>Home page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1257"/>
        <source>Register...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1262"/>
        <source>Check for Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="801"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="804"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Undo (Ctrl+Z)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Undo the last action&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="810"/>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1124"/>
        <location filename="../src/mainwindow.ui" line="1127"/>
        <source>Pencil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1222"/>
        <location filename="../src/mainwindow.ui" line="1225"/>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="351"/>
        <location filename="../src/mainwindow.ui" line="354"/>
        <source>Zoom In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="357"/>
        <source>Ctrl++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="378"/>
        <location filename="../src/mainwindow.ui" line="381"/>
        <source>Zoom Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="384"/>
        <source>Ctrl+-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="366"/>
        <location filename="../src/mainwindow.ui" line="369"/>
        <source>Actual Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="287"/>
        <location filename="../src/mainwindow.ui" line="290"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1247"/>
        <source>Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="392"/>
        <location filename="../src/mainwindow.ui" line="395"/>
        <source>Highlight Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="252"/>
        <location filename="../src/mainwindow.ui" line="258"/>
        <source>Hand Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="587"/>
        <source>Edit Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="915"/>
        <location filename="../src/mainwindow.ui" line="918"/>
        <source>Page layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="819"/>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="822"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Redo (Ctrl+Y)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Redo the previously undone action.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="828"/>
        <source>Ctrl+Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="709"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <source>Master PDF Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <location filename="../src/mainwindow.ui" line="1321"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="382"/>
        <source>Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="237"/>
        <location filename="../src/mainwindow.ui" line="240"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="276"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Select Text (Alt+5)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Select text for copying and pasting&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="301"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="403"/>
        <location filename="../src/mainwindow.ui" line="406"/>
        <source>Reset Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="418"/>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Fit Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="433"/>
        <location filename="../src/mainwindow.ui" line="436"/>
        <source>Fit Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="523"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="535"/>
        <location filename="../src/mainwindow.ui" line="538"/>
        <source>Facing Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="625"/>
        <location filename="../src/mainwindow.ui" line="628"/>
        <source>Delete Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="643"/>
        <location filename="../src/mainwindow.ui" line="646"/>
        <source>Edit Forms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="663"/>
        <source>Ctrl+F11</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="712"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Cut (Ctrl+X)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Cut the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="718"/>
        <source>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="727"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="730"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Copy (Ctrl+C)&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Copy the selection Object(s) and place on the Clipboard&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="483"/>
        <location filename="../src/mainwindow.ui" line="736"/>
        <source>Ctrl+C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="745"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="754"/>
        <source>Ctrl+V</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="759"/>
        <location filename="../src/mainwindow.ui" line="762"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="765"/>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="566"/>
        <source>Edit Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="575"/>
        <source>Alt+1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1136"/>
        <source>Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1006"/>
        <location filename="../src/mainwindow.ui" line="1009"/>
        <source>Highlight Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="991"/>
        <source>Add Sticky Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1018"/>
        <location filename="../src/mainwindow.ui" line="1021"/>
        <source>Strikeout Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1030"/>
        <location filename="../src/mainwindow.ui" line="1033"/>
        <source>Underline Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="273"/>
        <source>Select Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="649"/>
        <source>Alt+3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="1242"/>
        <source>HTML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="778"/>
        <location filename="../src/mainwindow.ui" line="781"/>
        <source>Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="789"/>
        <location filename="../src/mainwindow.ui" line="792"/>
        <source>Find Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="926"/>
        <location filename="../src/mainwindow.ui" line="929"/>
        <source>Rotate Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="907"/>
        <location filename="../src/mainwindow.ui" line="910"/>
        <source>Move Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="261"/>
        <source>Alt+4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1235"/>
        <source>Open failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1236"/>
        <source>Cannot open file :
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="38"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="269"/>
        <source>Empty recent files list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="66"/>
        <source>Prev/Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="89"/>
        <source>Edit Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="145"/>
        <source>Page :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="229"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="294"/>
        <source>Open a PDF file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="355"/>
        <location filename="../src/mainwindow.cpp" line="2704"/>
        <location filename="../src/mainwindow.cpp" line="2761"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="374"/>
        <source>PDF Files (*.pdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="35"/>
        <location filename="../src/mainwindow.cpp" line="2063"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="266"/>
        <source>Recent Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="188"/>
        <location filename="../src/mainwindow.cpp" line="244"/>
        <source>There was an error opening the document !</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="315"/>
        <source>Saving in XPS is temporarily not supported.
Choose PDF file name for saving.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="451"/>
        <source>Export completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1409"/>
        <source>The document %s has been modified. 
Do you want to save your changes?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1416"/>
        <source>Close Without Saving</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1417"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2713"/>
        <location filename="../src/mainwindow.cpp" line="2734"/>
        <location filename="../src/mainwindow.cpp" line="2737"/>
        <location filename="../src/mainwindow.cpp" line="2770"/>
        <location filename="../src/mainwindow.cpp" line="2790"/>
        <location filename="../src/mainwindow.cpp" line="2793"/>
        <source>FDF Files (*.fdf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="284"/>
        <source>The unregistered version will insert a watermark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1512"/>
        <source>A error occurred during the signature verification!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="331"/>
        <location filename="../src/mainwindow.cpp" line="388"/>
        <source>Save failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="41"/>
        <source>Ctrl+Shift++</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="42"/>
        <source>Ctrl+Shift+-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="332"/>
        <location filename="../src/mainwindow.cpp" line="389"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="332"/>
        <location filename="../src/mainwindow.cpp" line="389"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow_update.cpp" line="32"/>
        <source>Your version already has the last update!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow_update.cpp" line="40"/>
        <source>New Version Is Available !
Do you want to Download Now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="254"/>
        <location filename="../src/mainwindow.cpp" line="257"/>
        <location filename="../src/mainwindow.cpp" line="2734"/>
        <location filename="../src/mainwindow.cpp" line="2737"/>
        <location filename="../src/mainwindow.cpp" line="2790"/>
        <location filename="../src/mainwindow.cpp" line="2793"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="254"/>
        <location filename="../src/mainwindow.cpp" line="257"/>
        <source>All Files (*.pdf *.xps);;PDF Files (*.pdf);;XPS Files (*.xps)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="657"/>
        <location filename="../src/mainwindow.ui" line="660"/>
        <location filename="../src/mainwindow.ui" line="1330"/>
        <source>Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mainwindow_tool_bars.cpp" line="419"/>
        <source>Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="75"/>
        <location filename="../src/mac/mainwindow_mac_tool_bars.cpp" line="131"/>
        <location filename="../src/mainwindow_tool_bars.cpp" line="351"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MovePagesDialog</name>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="14"/>
        <source>Move Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="26"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="32"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="58"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="78"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="88"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="114"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="140"/>
        <source>Destination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="152"/>
        <source>To:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="162"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="211"/>
        <source>First</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MovePagesDialog.ui" line="218"/>
        <source>Last</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NewPageDialog</name>
    <message>
        <location filename="../src/NewPageDialog.ui" line="20"/>
        <source>Page Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="191"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="228"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="30"/>
        <source>A0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="35"/>
        <source>A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="40"/>
        <source>A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="45"/>
        <source>A3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="50"/>
        <source>A4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="55"/>
        <source>A5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="60"/>
        <source>A6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="65"/>
        <source>A7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="70"/>
        <source>A8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="75"/>
        <source>A9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="80"/>
        <source>A10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="85"/>
        <source>Letter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="90"/>
        <source>Tabloid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="95"/>
        <source>B0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="100"/>
        <source>B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="105"/>
        <source>B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="110"/>
        <source>B3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="115"/>
        <source>B4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="120"/>
        <source>B5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="125"/>
        <source>Statement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="130"/>
        <source>Executive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="135"/>
        <source>Folio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="140"/>
        <source>Quarto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="145"/>
        <source>Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="150"/>
        <source>ANSI C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="155"/>
        <source>ANSI D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="160"/>
        <source>ANSI E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="165"/>
        <source>ANSI F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="170"/>
        <source>Custom page size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="215"/>
        <source>Portrait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="220"/>
        <source>Landscape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="264"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="272"/>
        <source>points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="277"/>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="282"/>
        <source>millimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="293"/>
        <source>Contents Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="305"/>
        <source>Left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="345"/>
        <source>Top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="325"/>
        <source>Right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="365"/>
        <source>Bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="388"/>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="394"/>
        <source>Before current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="411"/>
        <source>After current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="418"/>
        <source>After last page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="404"/>
        <source>Before first page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="428"/>
        <source>Number of pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="454"/>
        <source>Page(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.ui" line="434"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.cpp" line="142"/>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.cpp" line="166"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/NewPageDialog.cpp" line="188"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ObjectInspector</name>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="60"/>
        <source>No Properties
There is no object selections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="308"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2710"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2929"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1617"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="142"/>
        <source>Property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="147"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="443"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="653"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="453"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2392"/>
        <source>Actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="475"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1681"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1715"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1787"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1843"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="485"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="676"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="541"/>
        <source>Up Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="548"/>
        <source>Behavior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="562"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1108"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1270"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1425"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="567"/>
        <source>Push</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="572"/>
        <source>Outline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="577"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1113"/>
        <source>Invert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="585"/>
        <source>Down Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="595"/>
        <source>RollOver Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="631"/>
        <source>Item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="660"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="981"/>
        <source>Export Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="705"/>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="718"/>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="725"/>
        <source>Sort Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="732"/>
        <source>Commit selected value immediately</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="739"/>
        <source>Multiple selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="746"/>
        <source>Allow user to enter custom text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="779"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="786"/>
        <source>Scrollable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="793"/>
        <source>Check spelling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="800"/>
        <source>Limit to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="814"/>
        <source>chars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="821"/>
        <source>Split into</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="835"/>
        <source>Allow Rich Text formatting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="845"/>
        <source>Multi-line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="852"/>
        <source>cells</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="860"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2167"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="865"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="870"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="878"/>
        <source>Default Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="885"/>
        <source>Alignment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="924"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2278"/>
        <source>Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="935"/>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="940"/>
        <source>Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="945"/>
        <source>Cross</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="950"/>
        <source>Diamond</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="955"/>
        <source>Square</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="960"/>
        <source>Star</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1004"/>
        <source>Checked by Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1050"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2700"/>
        <source>Line Thickness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1064"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2650"/>
        <source>Border Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1071"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2693"/>
        <source>Line Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1079"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2665"/>
        <source>Solid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1084"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2670"/>
        <source>Dashed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1089"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2685"/>
        <source>Underline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1097"/>
        <source>Highlight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1118"/>
        <source>OutLine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1123"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1157"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;Signature.&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:10pt;&quot;&gt;No available options&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1216"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2411"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1256"/>
        <source>Format category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1275"/>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1280"/>
        <source>Percentage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1285"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1290"/>
        <source>Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1295"/>
        <source>Special</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1300"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1455"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1319"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1324"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1329"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1334"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1339"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1344"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1349"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1354"/>
        <source>7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1359"/>
        <source>8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1364"/>
        <source>9</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1369"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1378"/>
        <source>1,234.56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1383"/>
        <source>1234.56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1388"/>
        <source>1.234,56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1393"/>
        <source>1234,56</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1407"/>
        <source>Currency Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1430"/>
        <source>Dollar ($)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1435"/>
        <source>Euro (€)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1440"/>
        <source>Pound (£)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1445"/>
        <source>Yen (¥)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1450"/>
        <source>Ruble (Руб)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1476"/>
        <source>Show parentheses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1496"/>
        <source>Decimal Places</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1503"/>
        <source>Separation Style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1510"/>
        <source>Use red text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1527"/>
        <source>Date Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1582"/>
        <source>Time Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1596"/>
        <source>Special Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1654"/>
        <source>Format Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1688"/>
        <source>KeyStroke Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1739"/>
        <source>Validate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1760"/>
        <source>Validation Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1795"/>
        <source>Calculate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1816"/>
        <source>Calculation Script</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1945"/>
        <source>Full text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1950"/>
        <source>Stroke Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1955"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2490"/>
        <source>Full and Stroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1960"/>
        <source>Invisible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1974"/>
        <source>Full Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2000"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2558"/>
        <source>Line Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2029"/>
        <source>Character spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2036"/>
        <source>Word spacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2070"/>
        <source>F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2096"/>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2106"/>
        <source>E</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2116"/>
        <source>A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2126"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2136"/>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2187"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2675"/>
        <source>Beveled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2680"/>
        <source>Inset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2735"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2799"/>
        <source>ToolTip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2815"/>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2823"/>
        <source>0 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2828"/>
        <source>90 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2833"/>
        <source>180 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2838"/>
        <source>270 Degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2859"/>
        <source>Read Only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2874"/>
        <source>Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2879"/>
        <source>Hidden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2884"/>
        <source>Visible but doesn&apos;t print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2889"/>
        <source>Hidden but printable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2897"/>
        <source>Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2907"/>
        <source>Locked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2936"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2984"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1880"/>
        <source>Font Family</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1909"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2722"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1925"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2460"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="3004"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2204"/>
        <source>Coordinates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2212"/>
        <source>Absolute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2217"/>
        <source>Relative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2237"/>
        <source>Geometry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2259"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2764"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2297"/>
        <source>Matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2316"/>
        <source>Cliping Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2335"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2354"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2373"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2430"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2480"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2498"/>
        <source>Full</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2485"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2533"/>
        <source>Stroke</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2523"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2545"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2751"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2961"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2625"/>
        <source>Borders and Colors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2632"/>
        <source>Thin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2637"/>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2642"/>
        <source>Thick</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2657"/>
        <source>Fill Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="1987"/>
        <source>Stroke Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2013"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2510"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2571"/>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2974"/>
        <source>Opacity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1203"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1210"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1223"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1230"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1272"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the fill color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1278"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font Stroke color&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the stroke color&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1640"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1680"/>
        <source>Shading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1702"/>
        <source>Image Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2177"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2197"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1660"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2866"/>
        <source>Form Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2789"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1215"/>
        <location filename="../src/objectinspector/ObjectInspector.cpp" line="1260"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Font family&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Change the font family&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="2606"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="399"/>
        <source>Goto a Page View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="331"/>
        <source>Add an Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="337"/>
        <source>Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="345"/>
        <source>Mouse Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="350"/>
        <source>Mouse Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="355"/>
        <source>Mouse Enter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="360"/>
        <source>Mouse Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="365"/>
        <source>On Receive Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="370"/>
        <source>On Lose Focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="391"/>
        <source>Action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="404"/>
        <source>Open/execute a File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="409"/>
        <source>Open a web link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="414"/>
        <source>Reset form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="419"/>
        <source>Show/Hide fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="424"/>
        <source>Submit a form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/objectinspector/ObjectInspector.ui" line="429"/>
        <source>Run a JavaScript</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PageLayoutDialog</name>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="14"/>
        <source>Page Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="96"/>
        <source>Contents Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="108"/>
        <source>Left margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="122"/>
        <source>Top margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="136"/>
        <source>Right margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="150"/>
        <source>Bottom margin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="53"/>
        <source>Page Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="59"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.cpp" line="236"/>
        <source> px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.cpp" line="260"/>
        <source> in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.cpp" line="282"/>
        <source> mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="76"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="167"/>
        <source>Units</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="178"/>
        <source>points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="183"/>
        <source>inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="188"/>
        <source>millimeter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="196"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="219"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="209"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="202"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/PageLayoutDialog.ui" line="241"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordOpenDialog</name>
    <message>
        <location filename="../src/passwordopendialog.ui" line="14"/>
        <source>Enter Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/passwordopendialog.ui" line="66"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/passwordopendialog.ui" line="56"/>
        <source>The file is protected. Please enter a Document Open Password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlainTextEdit</name>
    <message>
        <location filename="../src/docpage/texteditor/plaintextedit.cpp" line="227"/>
        <source>This font doesn&apos;t contain these characters.
Try choosing another font.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrintDialog</name>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="14"/>
        <source>Print Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="32"/>
        <source>Printer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="47"/>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="88"/>
        <source>72</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="93"/>
        <source>150</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="98"/>
        <source>300</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="103"/>
        <source>600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="108"/>
        <source>900</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="113"/>
        <source>1200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="127"/>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="251"/>
        <source>Antialiasing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="258"/>
        <source>Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="265"/>
        <source>Print as Grayscale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="272"/>
        <source>Aspect Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="279"/>
        <source>Ignore aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="284"/>
        <source>Keep aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="289"/>
        <source>Keep aspect ratio by expanding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="303"/>
        <source>Orientation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="309"/>
        <source>Portrait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="316"/>
        <source>Landscape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="359"/>
        <source>Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="369"/>
        <source>of:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="80"/>
        <source>Resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="143"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="149"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="159"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="166"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="189"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="221"/>
        <source>Number of copies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.ui" line="235"/>
        <source>Collate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.cpp" line="67"/>
        <source>of </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/printdialog/printdialog.cpp" line="97"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QAttachment</name>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="19"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="34"/>
        <source>Insert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="35"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="36"/>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="415"/>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="435"/>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="98"/>
        <source>Page </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/attachment/qattachment.cpp" line="102"/>
        <source>Attachment Tab</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QBookmarksTree</name>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="17"/>
        <source>Add Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="18"/>
        <source>Delete Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="19"/>
        <source>Bookmark Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/bookmark/qbookmarks.cpp" line="20"/>
        <source>Set Destination</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QDocTab</name>
    <message>
        <location filename="../src/document/qdoctab.cpp" line="73"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/document/qdoctab.cpp" line="544"/>
        <source>The clipboard doesn&apos;t contain an data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QHttp</name>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="370"/>
        <source>HTTPS connection requested but SSL support not compiled in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="1579"/>
        <location filename="../src/qhttp/qhttp.cpp" line="2375"/>
        <source>Unknown error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="1830"/>
        <source>Request aborted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2386"/>
        <source>No server set to connect to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2550"/>
        <source>Wrong content length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2554"/>
        <source>Server closed connection unexpectedly</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2609"/>
        <source>Connection refused (or timed out)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2612"/>
        <source>Host %1 not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2632"/>
        <source>HTTP request failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2726"/>
        <source>Invalid HTTP response header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2770"/>
        <source>Unknown authentication method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2780"/>
        <source>Proxy authentication required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2784"/>
        <source>Authentication required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2867"/>
        <location filename="../src/qhttp/qhttp.cpp" line="2915"/>
        <source>Invalid HTTP chunked body</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qhttp/qhttp.cpp" line="2953"/>
        <source>Error writing response to device</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPDFDocument</name>
    <message>
        <location filename="../src/document/qpdfdocument.cpp" line="974"/>
        <source>Error!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/document/qpdfdocument.cpp" line="1379"/>
        <source>There was a problem with your form submission.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/document/qpdfdocument.cpp" line="1381"/>
        <source>Your form was successfully submitted!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QTabPage</name>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="70"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="75"/>
        <source>Enlarge Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="78"/>
        <source>Reduce Page Thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="83"/>
        <source>Delete Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="96"/>
        <source>Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="109"/>
        <source>Attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="116"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="131"/>
        <source>Object Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="352"/>
        <source>This document contains interactive form fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="353"/>
        <source>Highlight Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="371"/>
        <source>This document is protected. You do not have permissions to edit this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="372"/>
        <source>Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="699"/>
        <source>There was an error printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="1090"/>
        <source>Insert Blank Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="1795"/>
        <source>Do you want to open?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="2390"/>
        <source>Are you sure you want to set the destination of the selected bookmark to the current location?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/docpage/qtabpage.cpp" line="2448"/>
        <source>untitled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtColorComboBox</name>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="131"/>
        <source>More...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="263"/>
        <source>User color %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="314"/>
        <source>User Color 99</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="328"/>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="329"/>
        <source>White</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="330"/>
        <source>Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="331"/>
        <source>Dark red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="332"/>
        <source>Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="333"/>
        <source>Dark green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="334"/>
        <source>Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="335"/>
        <source>Dark blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="336"/>
        <source>Cyan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="337"/>
        <source>Dark cyan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="338"/>
        <source>Magenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="339"/>
        <source>Dark magenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="340"/>
        <source>Yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="341"/>
        <source>Dark yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="342"/>
        <source>Gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="343"/>
        <source>Dark gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="344"/>
        <source>Light gray</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/widgets/qtcolorcombobox.cpp" line="346"/>
        <source>Transparent</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RegDialog</name>
    <message>
        <location filename="../src/regdialog.ui" line="14"/>
        <source>Registration Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="330"/>
        <source>Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="148"/>
        <source>After your order has been completed, 
you will automatically 
receive your Registration code via e-mail.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="119"/>
        <source>Buy Online</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="39"/>
        <location filename="../src/regdialog.ui" line="242"/>
        <source>Registration Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="49"/>
        <location filename="../src/regdialog.ui" line="256"/>
        <source>Activate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="72"/>
        <source>Offline Activation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="170"/>
        <source>Registered version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="177"/>
        <source>If you want to register that license on another PC 
click &quot;Deactivate&quot; button. 

Then register it where you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="203"/>
        <source>Deactivate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="276"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="249"/>
        <source>Activation Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="296"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Please send the ID key and Registration code to: &lt;/p&gt;&lt;p&gt;&lt;a href=&quot;mailto: support@code-industry.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;support@code-industry.net&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;p&gt;Once you receive your code enter it into &amp;quot;Activation code&amp;quot; field&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/regdialog.ui" line="283"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RotatePagesDlg</name>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="14"/>
        <source>Rotate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="20"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="26"/>
        <source>Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="52"/>
        <source>Sample: 1,6-8,12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="72"/>
        <source>Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="82"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="108"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="134"/>
        <source>Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="141"/>
        <source>Clockwise 90 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="146"/>
        <source>180 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/RotatePagesDlg.ui" line="151"/>
        <source>Counterclockwise 90 degrees</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SaveImageDialog</name>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="14"/>
        <source>Export to Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="20"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="29"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="39"/>
        <source>Page Range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="51"/>
        <source>All Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="67"/>
        <source>Pages from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="84"/>
        <source>to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="107"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="148"/>
        <location filename="../src/SaveImageDialog.ui" line="217"/>
        <source>JPEG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="113"/>
        <source>BMP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="120"/>
        <source>PNG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="158"/>
        <source>TIFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="127"/>
        <source>JPEG Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="197"/>
        <source>LZW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="202"/>
        <source>ZIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="207"/>
        <source>CCITT FAX 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="212"/>
        <source>CCITT FAX 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="134"/>
        <source>TIFF Compression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="141"/>
        <source>Transparent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="225"/>
        <source>MultiPage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="235"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="241"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="248"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="342"/>
        <source>72</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="347"/>
        <source>96</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="352"/>
        <source>120</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="357"/>
        <source>150</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="362"/>
        <source>200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="367"/>
        <source>240</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="372"/>
        <source>300</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="377"/>
        <source>400</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="382"/>
        <source>500</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="387"/>
        <source>600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="398"/>
        <source>Antialiasing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.ui" line="255"/>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="13"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="14"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="88"/>
        <source>Can&apos;t save to the file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="88"/>
        <source>
The file may be read-only or used by another application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="421"/>
        <source>Save As TIFF Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="421"/>
        <source>TIFF Files (*.tif *.tiff)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="440"/>
        <source>Save As Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SaveImageDialog.cpp" line="440"/>
        <source>All Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchFormTab</name>
    <message>
        <location filename="../src/leftTab/search/searchformtab.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.ui" line="20"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.ui" line="46"/>
        <source>0 result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="13"/>
        <source>Case Sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="17"/>
        <source>Include Comments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="53"/>
        <source> result</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="55"/>
        <source> result(s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/leftTab/search/searchformtab.cpp" line="57"/>
        <source> results</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SecurityDialog</name>
    <message>
        <location filename="../src/SecurityDialog.ui" line="14"/>
        <source>Security PDF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="36"/>
        <source>Required a password to open the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="51"/>
        <source>Document Open Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="71"/>
        <location filename="../src/SecurityDialog.ui" line="132"/>
        <source>Password Confirm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="94"/>
        <source>Permissions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="122"/>
        <source>Commenting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="142"/>
        <source>Modifying document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="155"/>
        <source>Content copying for accessibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="168"/>
        <source>Printing the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="181"/>
        <source>Extract the content of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="194"/>
        <source>Print a high resolution version of the document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="207"/>
        <source>Fill in existing form or signature fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="223"/>
        <source>Permissions Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.ui" line="233"/>
        <source>Manage Pages and bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.cpp" line="84"/>
        <source>Document Open password does not match.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SecurityDialog.cpp" line="96"/>
        <source>Document Permission password does not match.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignatureDialog</name>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="14"/>
        <source>Signature Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="52"/>
        <location filename="../src/signature/SignatureDialog.cpp" line="20"/>
        <source>Signature is VALID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="72"/>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="129"/>
        <source>Signed by:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="78"/>
        <source>Reason:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="92"/>
        <source>Date:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="115"/>
        <source>Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="169"/>
        <source>Validation Summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="185"/>
        <source>Signer&apos;s Contact Information:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="224"/>
        <source>Sing As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="367"/>
        <source>Show Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="376"/>
        <source>Stretch Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="396"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="406"/>
        <source>Show Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="136"/>
        <location filename="../src/signature/SignatureDialog.ui" line="244"/>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="254"/>
        <source>Text For Signing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="266"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="282"/>
        <source>Reason</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="299"/>
        <source>Lock document after signing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.ui" line="325"/>
        <source>Signature Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="39"/>
        <source>I have reviewed this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="40"/>
        <source>I am approving this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="41"/>
        <source>I attest to the accuracy and integrity of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="42"/>
        <source>I agree to specified parts of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="17"/>
        <source>The document has been altered or corrupted since the signatures was applied.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="18"/>
        <source>Document has not been changed since the signatures was applied.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="19"/>
        <source>Signature is INVALID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="21"/>
        <source>Signature validity is UNKNOWN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="22"/>
        <source>This certificate is not trusted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="23"/>
        <source>The signers identity is unknown because it has not been include in your list of trusted identities and none of its parent certificates is trust identities.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="24"/>
        <source>Error during signature verification.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="25"/>
        <source>Details: The signature byte range is invalid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="26"/>
        <source>I am the author of this document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="84"/>
        <source>Open Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="84"/>
        <source>Image Files (*.tif *.png *.jpg *.jpeg *.bmp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="344"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="344"/>
        <source>p12 Files (*.p12)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="329"/>
        <source>A error occurred during the signature verification!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="169"/>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="246"/>
        <source>A password is required to open certificate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureDialog.cpp" line="133"/>
        <source>Sign</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SignatureInfoDialog</name>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="14"/>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="34"/>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="40"/>
        <source>Issuer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="46"/>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="132"/>
        <source>Common Name (CN)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="60"/>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="139"/>
        <source>Organization (O)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="74"/>
        <source>Organizational Unit (OU)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="88"/>
        <source>Serial Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="102"/>
        <source>Algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="119"/>
        <source>Subject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="153"/>
        <source>Email</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="166"/>
        <source>Validity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="172"/>
        <source>Not Before</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="179"/>
        <source>Not After</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="209"/>
        <source>SHA-1:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="229"/>
        <source>MD5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="278"/>
        <source>Add to Trusted Identities</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/signature/SignatureInfoDialog.ui" line="286"/>
        <source>Data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StickyNoteDlg</name>
    <message>
        <location filename="../src/forms/StickyNoteDlg.ui" line="17"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
